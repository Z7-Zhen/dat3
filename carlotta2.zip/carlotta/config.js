import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'
import moment from 'moment-timezone'
import { group } from 'console'
import PhoneNumber from 'awesome-phonenumber'

/*============= WAKTU =============*/
let wibh = moment.tz('Asia/Jakarta').format('HH')
let wibm = moment.tz('Asia/Jakarta').format('mm')
let wibs = moment.tz('Asia/Jakarta').format('ss')
let wktuwib = `${wibh} H ${wibm} M ${wibs} S`

let d = new Date(new Date + 3600000)
let locale = 'id'
let weton = ['Pahing', 'Pon', 'Wage', 'Kliwon', 'Legi'][Math.floor(d / 84600000) % 5]
let week = d.toLocaleDateString(locale, { weekday: 'long' })
let date = d.toLocaleDateString(locale, {
  day: 'numeric',
  month: 'long',
  year: 'numeric'
})
const more = String.fromCharCode(8206)
const readMore = more.repeat(4001)

// Owner
global.owner = [
['31616482629', 'Renza', true],
]
global.mods = ['']
global.prems = []
// Info
global.nomorwa = '9999999'
global.packname = '© xxxxx '
global.author = 'By xxxx'
global.waktuSholat = {
     subuh: '04:39',
     dhuhur: '11:54',
     ashar: '15:12',
     maghrib: '17:53',
     isya: '19:23',
}

global.namebot = 'xxxx'
global.botNumber = 'xxxx'
global.Renza = 'xxxx'
global.pairing = 'xxxxxxxx'
global.wm = 'xxxxx '
global.ig = 'https://instagram.com/bokep'
global.stickpack = 'xxxx'
global.stickauth = 'By xxxx'
global.fotonya = 'https://files.catbox.moe/m8vdmg.jpg'
global.fotonya2 = 'https://files.catbox.moe/m8vdmg.jpg'
global.thumbmenu = 'https://files.catbox.moe/m8vdmg.jpg'
global.tfitur = 'https://files.catbox.moe/m8vdmg.jpg'
global.premv2 = 'https://files.catbox.moe/m8vdmg.jpg'
global.yae22 = 'https://files.catbox.moe/m8vdmg.jpg'
// Link Sosmed
global.sesiId = '19RUq6mJA4En2cfdPXjnl8t4YBSSCIWCiQK4YMsnrIg'
global.sig = 'https://instagram.com/zaa0jaa'
global.syt = 'Ga Punya Yete'
global.sgh = 'Ga Ada Github'
global.sgc = 'https://chat.whatsapp.com/LEZDFM0Kzas873aOUhkteN'
global.myweb = 'Gaadaa'
global.nisajpg = 'https://files.catbox.moe/m8vdmg.jpg'
global.bio = 'Ga adaa'

// Panel

global.domain = 'https://srvpbxpvnihh.rullzhosting.my.id' // Domain Web
global.apikey = 'ptla_DY3a7uiHpnyDCxHDsBPr9POz8xqW0VLKVstKW0vVw20' // Key PTLA
global.capikey = 'ptlc_bZ2p67LZCoOjT7ZayYpI1bnOjz6hQ3ruGp9zlqwvN1x' // Key PTLC
global.nestid = "5" // Isi id nest
global.egg = '15'
global.loc = '1'

// Donasi
global.pgopay = '081219896962'
global.pdana = '081219896962'
// Info Wait
global.wait = '_W a i t i n g..._'
global.eror = 'Terjadi kesalahan, mohon segera lapor kepada owner, agar cepat di perbaiki.'
global.multiplier = 69
global.diskonprem = 'true'
global.diskoncash = 'true'
global.payprem = 'open'
global.paycash = 'open'
global.listdiskon = 'bulanin'
global.flok = {
	"key": {
        "participant": '0@s.whatsapp.net',
            "remoteJid": "status@broadcast",
		    "fromMe": false,
		    "id": "Halo"
                        },
       "message": {
                    "locationMessage": {
                    "name": `Owen Skyler`,
                    "jpegThumbnail": ''
                          }
                        }
                      }
global.rpg = {
  emoticon(string) {
    string = string.toLowerCase()
    let emot = {
      agility: '🤸‍♂️',
      arc: '🏹',
      armor: '🥼',
      bank: '🏦',
      bibitanggur: '🍇',
      bibitapel: '🍎',
      bibitjeruk: '🍊',
      bibitmangga: '🥭',
      bibitpisang: '🍌',
      bow: '🏹',
      bull: '🐃',
      cat: '🐈',
      chicken: '🐓',
      common: '📦',
      cow: '🐄',
      crystal: '🔮',
      darkcrystal: '♠️',
      diamond: '💎',
      dog: '🐕',
      dragon: '🐉',
      elephant: '🐘',
      emerald: '💚',
      exp: '✉️',
      fishingrod: '🎣',
      fox: '🦊',
      gems: '🍀',
      giraffe: '🦒',
      gold: '👑',
      health: '❤️',
      horse: '🐎',
      intelligence: '🧠',
      iron: '⛓️',
      keygold: '🔑',
      keyiron: '🗝️',
      knife: '🔪',
      legendary: '🗃️',
      level: '🧬',
      limit: '🌌',
      lion: '🦁',
      magicwand: '⚕️',
      mana: '🪄',
      money: '💵',
      mythic: '🗳️',
      pet: '🎁',
      petFood: '🍖',
      pickaxe: '⛏️',
      pointxp: '📧',
      potion: '🥤',
      rock: '🪨',
      snake: '🐍',
      stamina: '⚡',
      strength: '🦹‍♀️',
      string: '🕸️',
      superior: '💼',
      sword: '⚔️',
      tiger: '🐅',
      trash: '🗑',
      uncommon: '🎁',
      upgrader: '🧰',
      wood: '🪵'
    }
    let results = Object.keys(emot).map(v => [v, new RegExp(v, 'gi')]).filter(v => v[1].test(string))
    if (!results.length) return ''
    else return emot[results[0][0]]
  }
}

// =========== KONFIGURASI UNTUK AYANE AI ==========

// Status default AI Ayane (true = on, false = off)
global.deline = false; 

// Notifikasi jika API key habis
global.exhaustedNotifSent = false; 

// Fungsi untuk mereset status notifikasi (akan dipanggil oleh plugin apikey)
global.resetApiKeyStatus = () => {
    console.log("Mereset status API key dan memuat ulang.");
    global.exhaustedNotifSent = false;
    // Jika ada fungsi untuk reload key, bisa ditambahkan di sini
};

// =================================================

let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
  unwatchFile(file)
  console.log(chalk.redBright("Update 'config.js'"))
  import(`${file}?update=${Date.now()}`)
})
