// feloai.js
import fetch from "node-fetch"

let handler = async (m, { text }) => {
  if (!text) throw `⚠️ Gunakan perintah:\n.feloai <pertanyaan / prompt>`
  try {
    let res = await fetch(`https://api.nekolabs.my.id/ai/feloai?text=${encodeURIComponent(text)}`)
    let json = await res.json()

    if (!json.status || !json.result?.text) throw '❌ API tidak balikin jawaban'

    let reply = `🤖 *FeloAI Jawab:*\n${json.result.text}`

    // tambahin sumber kalau ada
    if (json.result.sources && json.result.sources.length) {
      reply += `\n\n🔎 *Sources:*`
      for (let s of json.result.sources) {
        reply += `\n${s.index}. ${s.title} → ${s.url}`
      }
    }

    await m.reply(reply)
  } catch (e) {
    console.error('Error feloai:', e)
    m.reply('❌ Gagal ambil jawaban, coba lagi nanti.')
  }
}

handler.help = ['feloai <teks>']
handler.tags = ['ai']
handler.command = /^feloai$/i
handler.limit = true
handler.register = true

export default handler