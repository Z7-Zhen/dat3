import fs from 'fs'

const groupBackupTarget = '120363420541635241@g.us' // ID grup tujuan backup

let autoDbInterval = null
let isAutoDbActive = false

const getCurrentDate = () => {
  const now = new Date()
  return now.toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })
}

const formatBytes = (bytes) => {
  const sizes = ['Bytes', 'KB', 'MB', 'GB']
  if (bytes === 0) return '0 Byte'
  const i = Math.floor(Math.log(bytes) / Math.log(1024))
  return (bytes / Math.pow(1024, i)).toFixed(2) + ' ' + sizes[i]
}

async function sendDatabase(conn) {
  try {
    const file = './database.json'
    const sesi = fs.readFileSync(file)
    const stats = fs.statSync(file)

    const caption = `📦 *Backup Database*\n` +
      `📅 Tanggal: ${getCurrentDate()}\n` +
      `📁 Ukuran: ${formatBytes(stats.size)}\n` +
      `⚙️ Status Auto-backup: ${isAutoDbActive ? '✅ Aktif' : '❌ Nonaktif'}`

    await conn.sendMessage(groupBackupTarget, {
      document: sesi,
      mimetype: 'application/json',
      fileName: 'database.json',
      caption
    })
    console.log(`[AUTO-BACKUP] Berhasil kirim database ke grup.`)
  } catch (e) {
    console.error('❌ Gagal mengirim database ke grup:', e)
  }
}

const startAutoBackup = (conn) => {
  if (autoDbInterval) clearInterval(autoDbInterval)
  autoDbInterval = setInterval(() => sendDatabase(conn), 60 * 60 * 1000) // setiap 1 jam
}

const stopAutoBackup = () => {
  clearInterval(autoDbInterval)
  autoDbInterval = null
}

let handler = async (m, { conn, args, command }) => {
  if (command === 'autodb') {
    if (!args[0]) {
      return m.reply(`Contoh: .autodb on/off\nStatus saat ini: ${isAutoDbActive ? '✅ Aktif' : '❌ Nonaktif'}`)
    }

    if (args[0].toLowerCase() === 'on') {
      if (isAutoDbActive) return m.reply('✅ Auto-backup sudah aktif.')
      isAutoDbActive = true
      startAutoBackup(conn)
      m.reply('✅ Auto-backup database setiap 1 jam diaktifkan.')
    } else if (args[0].toLowerCase() === 'off') {
      if (!isAutoDbActive) return m.reply('❌ Auto-backup sudah nonaktif.')
      isAutoDbActive = false
      stopAutoBackup()
      m.reply('❌ Auto-backup database dinonaktifkan.')
    } else {
      m.reply('Gunakan perintah: .autodb on / .autodb off')
    }
  }

  if (command === 'getdb') {
    m.reply('📤 Tunggu sebentar, sedang mengirim file database...')
    const file = './database.json'
    const sesi = fs.readFileSync(file)
    const stats = fs.statSync(file)

    const caption = `📦 *Database Manual*\n` +
      `📅 Tanggal: ${getCurrentDate()}\n` +
      `📁 Ukuran: ${formatBytes(stats.size)}\n` +
      `⚙️ Status Auto-backup: ${isAutoDbActive ? '✅ Aktif' : '❌ Nonaktif'}`

    await conn.sendMessage(m.chat, {
      document: sesi,
      mimetype: 'application/json',
      fileName: 'database.json',
      caption
    }, { quoted: m })
  }
}

handler.help = ['getdb', 'autodb on/off']
handler.tags = ['owner']
handler.command = /^getdb|autodb$/i
handler.owner = true

export default handler