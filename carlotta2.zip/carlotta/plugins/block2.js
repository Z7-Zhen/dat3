let handler = async (m, { conn, isOwner }) => {
    
  if (m.isGroup) {
    if (m.users) {
      await conn.updateBlockStatus(m.users, "block");
      m.reply(`Sukses block user`);
    } else {
      m.reply(
        "Silakan reply pesan atau tag atau input nomer yang mau di block"
      );
    }
  } else if (!m.isGroup) {
    if (q) {
      var woke =
        q.replace(new RegExp("[()+-/ +/]", "gi"), "") + `@s.whatsapp.net`;
      if (woke.startsWith("08")) return m.reply("Awali nomer dengan 62");
      if (!woke.startsWith("62"))
        return m.reply(
          "Silakan reply pesan atau tag atau input nomer yang mau di block"
        );
      await conn.updateBlockStatus(woke, "block");
    } else if (!q) {
      m.reply("Masukan nomer yang ingin di block");
    }
    m.reply(`Berhasil Block user ${woke.split("@")[0]}`);
  }
};
handler.help = ["user"];
handler.tags = ["owner"];
handler.command = /^(block2)$/i;
handler.owner = true;
handler.group = false;

export default handler;