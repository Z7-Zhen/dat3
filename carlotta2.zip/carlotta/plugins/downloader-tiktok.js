import axios from "axios";
import { proto, generateWAMessageFromContent, generateWAMessageContent } from "@adiwajshing/baileys";

let handler = async (m, { conn, text, usedPrefix, command }) => {
  const quotedMini = {
    key: { participant: "0@s.whatsapp.net", remoteJid: "0@s.whatsapp.net", fromMe: false, id: "Renza" },
    message: { conversation: m.text || `${usedPrefix + command}` }
  };

  if (!text) {
    return conn.reply(
      m.chat,
      `Link TikTok mana?\nContoh: ${usedPrefix + command} https://vt.tiktok.com/xxxxxx/`,
      quotedMini
    );
  }

  await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

  try {
    const api = `https://api.deline.web.id/downloader/tiktok?url=${encodeURIComponent(text)}`;
    const { data } = await axios.get(api, { timeout: 60000 });

    if (!data?.result) throw new Error("Response kosong dari API kamu");

    const { type, download, music, author: meta, title, region } = data.result;

    const caption =
`✨ *TIKTOK DOWNLOADER* ✨

🔗 *Link:* ${text}
🎵 *Title:* ${title || "Tanpa judul"}
✍️ *Author:* ${meta?.unique_id || meta?.nickname || "Unknown"}
🌎 *Region:* ${region || "Unknown"}`.trim();

    if (type === "image" && Array.isArray(download)) {
      const cards = [];
      for (let i = 0; i < download.length; i++) {
        const { imageMessage } = await generateWAMessageContent(
          { image: { url: download[i] } },
          { upload: conn.waUploadToServer }
        );
        cards.push({
          header: proto.Message.InteractiveMessage.Header.fromObject({
            hasMediaAttachment: true,
            imageMessage
          }),
          body: proto.Message.InteractiveMessage.Body.fromObject({ text: "" }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({})
        });
      }

      const msg = generateWAMessageFromContent(
        m.chat,
        {
          viewOnceMessage: {
            message: {
              messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
              interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body: proto.Message.InteractiveMessage.Body.fromObject({ text: caption }),
                carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({ cards })
              })
            }
          }
        },
        { quoted: quotedMini }
      );

      await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } else if (type === "video" && typeof download === "string") {
      await conn.sendFile(m.chat, download, "tiktok.mp4", caption, quotedMini);
      if (music) {
        try {
          await conn.sendMessage(
            m.chat,
            { audio: { url: music }, mimetype: "audio/mpeg", ptt: false,
              contextInfo: { forwardingScore: 999, isForwarded: true } },
            { quoted: quotedMini }
          );
        } catch {}
      }
    } else {
      await conn.reply(m.chat, "Format tidak dikenali. Coba link lain ya 😿", quotedMini);
    }

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

  } catch (e) {
    console.error("TT error:", e?.response?.status || e.message);
    await conn.reply(m.chat, "❌ Gagal. Coba lagi ya.", quotedMini);
  }
};

handler.help = ["tiktok <link>"];
handler.tags = ["downloader"];
handler.command = /^(tiktok|tiktokdl|tt)$/i;
handler.limit = 3;
handler.register = true;

export default handler;