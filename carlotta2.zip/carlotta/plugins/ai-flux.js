import axios from "axios";

const handler = async (m, { conn, args }) => {
  if (!args.length)
    return m.reply(
      `promptnya mana om?\nEX: .flux An anime girl with silver hair and red eyes, standing under a glowing street lamp at night, cinematic style`
    );

  m.reply(wait);

  const prompt = args.join(" ");
  const result = await generateFluxImage(prompt);

  if (result.success) {
    await conn.sendMessage(
      m.chat,
      {
        image: { url: result.imageUrl },
        caption: `🖼️ *Flux AI Generator*\n\n🎨 Prompt: ${prompt}`,
      },
      { quoted: flok }
    );
  } else {
    m.reply(`${result.message}`);
  }
};

handler.help = ["flux"].map((a) => a + " <prompt>");
handler.tags = ["ai"];
handler.command = ["flux"];
handler.register = true;
handler.limit = true;

export default handler;

async function generateFluxImage(prompt) {
  try {
    const response = await axios.post(
      "https://fluxai.pro/api/tools/fast",
      { prompt },
      {
        headers: {
          "Content-Type": "application/json",
          "User-Agent":
            "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
          Referer: "https://fluxai.pro/image-generator",
        },
      }
    );

    if (response.data?.ok && response.data?.data?.imageUrl) {
      return { success: true, imageUrl: response.data.data.imageUrl };
    } else {
      return { success: false, message: "Gagal mendapatkan gambar dari FluxAI" };
    }
  } catch (error) {
    return {
      success: false,
      message: "Terjadi kesalahan",
      error: error.response ? error.response.data : error.message,
    };
  }
}