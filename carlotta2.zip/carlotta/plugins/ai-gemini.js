import fs from 'fs'
import axios from 'axios'
import path from 'path'

const SESSION_FILE_PATH = './src/geminisessions.json'
const SESSION_TIMEOUT = 60 * 60 * 1000
const MAX_HISTORY = 500
const GEMINI_API_KEY = "AIzaSyCURDo-PO29UjszVzZ89-1Ly2XlTGtqZZQ"

if (!fs.existsSync(SESSION_FILE_PATH)) {
  fs.writeFileSync(SESSION_FILE_PATH, JSON.stringify({}, null, 2))
}

let userSessions = {}
try {
  userSessions = JSON.parse(fs.readFileSync(SESSION_FILE_PATH, 'utf8'))
} catch {
  userSessions = {}
}

const saveSessions = () => {
  fs.writeFileSync(SESSION_FILE_PATH, JSON.stringify(userSessions, null, 2))
}

const extMap = {
  javascript: 'js', typescript: 'ts', html: 'html', css: 'css', json: 'json',
  python: 'py', bash: 'sh', shell: 'sh', sh: 'sh', java: 'java', c: 'c',
  cpp: 'cpp', php: 'php', ruby: 'rb', go: 'go', rust: 'rs', xml: 'xml', sql: 'sql'
}

const extractCodeBlocks = (text) => {
  const regex = /```(\w+)\n([\s\S]+?)```/g
  let match, blocks = []
  let count = 1
  while ((match = regex.exec(text)) !== null) {
    const lang = match[1].toLowerCase()
    const ext = extMap[lang] || lang
    const code = match[2]
    const filename = `Code_V${count}.${ext}`
    const filepath = path.join('./tmp', filename)
    blocks.push({ filename, filepath, code })
    count++
  }
  return blocks
}

const delay = ms => new Promise(resolve => setTimeout(resolve, ms))

let gemini = async (m, { text, usedPrefix, command, conn }) => {
  const userId = m.sender
  const now = Date.now()

  if (!userSessions[userId] || typeof userSessions[userId] !== 'object') {
    userSessions[userId] = { history: [], updated_at: now }
  }

  if (!Array.isArray(userSessions[userId].history)) {
    userSessions[userId].history = []
  }

  if (typeof userSessions[userId].updated_at !== 'number') {
    userSessions[userId].updated_at = now
  }

  if (now - userSessions[userId].updated_at > SESSION_TIMEOUT || userSessions[userId].history.length >= MAX_HISTORY) {
    userSessions[userId] = { history: [], updated_at: now }
  }

  if (!text) throw `${usedPrefix + command} <pertanyaan>`

  userSessions[userId].history.push({ role: "user", content: text })
  conn.sendMessage(m.chat, { react: { text: '☕', key: m.key } })

  try {
    const url = `https://generativelanguage.googleapis.com/v1/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`
    const data = {
      contents: userSessions[userId].history.map(msg => ({
        role: msg.role,
        parts: [{ text: msg.content }]
      }))
    }

    const response = await axios.post(url, data)
    const aiText = response.data?.candidates?.[0]?.content?.parts?.[0]?.text || "Maaf, aku gak bisa jawab itu."

    userSessions[userId].history.push({ role: "assistant", content: aiText })
    userSessions[userId].updated_at = now
    saveSessions()

    await conn.sendMessage(m.chat, {
      text: aiText.replace(/\*\*/g, '*'),
      contextInfo: {
        forwardingScore: 99999999,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: '120363418731043391@newsletter',
          serverMessageId: null,
          newsletterName: `© ${global.namebot} || ${global.author}`
        }
      }
    }, { quoted: m })

    const codeBlocks = extractCodeBlocks(aiText)
    if (codeBlocks.length > 0) {
      if (!fs.existsSync('./tmp')) fs.mkdirSync('./tmp')
      conn.pendingCodeSend = conn.pendingCodeSend || {}
      conn.pendingCodeSend[m.sender] = codeBlocks
      for (let block of codeBlocks) {
        fs.writeFileSync(block.filepath, block.code)
      }

      let optionText = `Ditemukan ${codeBlocks.length} blok kode.\n\nKetik:\n- *1* ➜ untuk kirim teks kode\n- *2* ➜ untuk kirim dokumen`
      if (codeBlocks.length > 3) {
        optionText += `\n- *3* ➜ untuk gabung semua kode jadi 1 file`
      }
      optionText += `\n\n(Berlaku 30 detik)`

      await conn.sendMessage(m.chat, { text: optionText }, { quoted: m })

      setTimeout(() => {
        if (conn.pendingCodeSend && conn.pendingCodeSend[m.sender]) {
          for (let block of conn.pendingCodeSend[m.sender]) {
            if (fs.existsSync(block.filepath)) fs.unlinkSync(block.filepath)
          }
          delete conn.pendingCodeSend[m.sender]
        }
      }, 30000)
    }

    await conn.sendMessage(m.chat, { react: { text: '', key: m.key } })
  } catch {
    m.reply('❌ Terjadi kesalahan saat menghubungi Gemini. Coba lagi nanti.')
  }
}

gemini.before = async (m, { conn }) => {
  conn.pendingCodeSend = conn.pendingCodeSend || {}
  if (conn.pendingCodeSend[m.sender]) {
    const reply = m.text.trim()
    const blocks = conn.pendingCodeSend[m.sender]

    if (reply === '1') {
      for (let block of blocks) {
        await conn.sendMessage(m.chat, { text: block.code }, { quoted: m })
        await delay(500)
      }
      delete conn.pendingCodeSend[m.sender]
      return !0
    } else if (reply === '2') {
      for (let block of blocks) {
        try {
          const buffer = await fs.promises.readFile(block.filepath)
          const preview = block.code.trim().slice(0, 150) + (block.code.trim().length > 150 ? '...' : '')
          await conn.sendMessage(m.chat, {
            document: buffer,
            mimetype: 'application/octet-stream',
            fileName: block.filename,
            caption: preview
          }, { quoted: m })
          await delay(1000)
          fs.unlinkSync(block.filepath)
        } catch {}
      }
      delete conn.pendingCodeSend[m.sender]
      return !0
    } else if (reply === '3' && blocks.length > 3) {
      const mergedCode = blocks.map(b => b.code).join('\n\n')
      const filename = 'Code_Merged.txt'
      const filepath = './tmp/' + filename
      fs.writeFileSync(filepath, mergedCode)
      const preview = mergedCode.slice(0, 150) + (mergedCode.length > 150 ? '...' : '')
      const buffer = await fs.promises.readFile(filepath)
      await conn.sendMessage(m.chat, {
        document: buffer,
        mimetype: 'application/octet-stream',
        fileName: filename,
        caption: preview
      }, { quoted: m })
      fs.unlinkSync(filepath)
      for (let block of blocks) {
        if (fs.existsSync(block.filepath)) fs.unlinkSync(block.filepath)
      }
      delete conn.pendingCodeSend[m.sender]
      return !0
    }
  }
}

gemini.help = ['gemini']
gemini.tags = ['ai']
gemini.command = /^(gemini)$/i
gemini.limit = 3
gemini.register = true

export default gemini