let handler = async (m, { conn }) => {
    conn.tebakbendera = conn.tebakbendera || {}
    let id = m.chat

    // Pastikan game aktif
    if (!(id in conn.tebakbendera)) throw false

    const jawaban = (conn.tebakbendera[id][1]?.name || '').trim()
    const clue = jawaban.replace(/[AIUEOaiueo]/ig, '_')

    conn.reply(
        m.chat,
        '```' + clue + '```',
        conn.tebakbendera[id][0] // quoted ke pesan soal
    )
}

handler.command = /^hben$/i

export default handler
