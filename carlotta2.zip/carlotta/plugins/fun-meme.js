import fetch from 'node-fetch'

let handler = async (m, { conn }) => {
  try {
    let img = await fetch(`https://api-faa.my.id/faa/meme`).then(res => res.buffer())
    await conn.sendFile(m.chat, img, 'meme.jpg', wm, m)
  } catch (e) {
    throw `Error: ${e.message || e}`
  }
}

handler.command = /^(meme)$/i
handler.tags = ['fun']
handler.help = ['meme']
handler.limit = true
handler.register = true

export default handler