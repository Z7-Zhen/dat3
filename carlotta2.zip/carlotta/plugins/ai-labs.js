// plugins/ai-labs.js
// Commands:
//   .aiimg <prompt>   → generate image
//   .aivideo <prompt> → generate video

import axios from 'axios'
import chalk from 'chalk'

// ==========================
//  Core client (aiLabs)
// ==========================
const aiLabs = {
  api: {
    base: 'https://text2pet.zdex.top',
    endpoints: {
      images: '/images',
      videos: '/videos',
      videosBatch: '/videos/batch',
    },
  },

  headers: {
    'user-agent': 'NB Android/1.0.0',
    'accept-encoding': 'gzip',
    'content-type': 'application/json',
    authorization: '',
  },

  state: { token: null },

  setup: {
    cipher: 'hbMcgZLlzvghRlLbPcTbCpfcQKM0PcU0zhPcTlOFMxBZ1oLmruzlVp9remPgi0QWP0QW',
    shiftValue: 3,
    dec(text, shift) {
      return [...text].map(c =>
        /[a-z]/.test(c)
          ? String.fromCharCode((c.charCodeAt(0) - 97 - shift + 26) % 26 + 97)
          : /[A-Z]/.test(c)
          ? String.fromCharCode((c.charCodeAt(0) - 65 - shift + 26) % 26 + 65)
          : c
      ).join('')
    },
    async decrypt() {
      if (aiLabs.state.token) return aiLabs.state.token
      const decrypted = aiLabs.setup.dec(aiLabs.setup.cipher, aiLabs.setup.shiftValue)
      aiLabs.state.token = decrypted
      aiLabs.headers.authorization = decrypted
      return decrypted
    },
  },

  deviceId() {
    return Array.from({ length: 16 }, () =>
      Math.floor(Math.random() * 16).toString(16)
    ).join('')
  },

  async text2img(prompt) {
    if (!prompt?.trim()) {
      return { success: false, code: 400, result: { error: 'Prompt kosong.' } }
    }
    await aiLabs.setup.decrypt()
    try {
      const url = aiLabs.api.base + aiLabs.api.endpoints.images
      const res = await axios.post(url, { prompt }, { headers: aiLabs.headers })
      const { code, data, prompt: echoed } = res.data || {}
      if (code !== 0 || !data) {
        console.log(chalk.yellow('Generate image gagal'))
        return { success: false, code: res.status ?? 500, result: { error: 'Gagal generate image' } }
      }
      console.log(chalk.green('Image OK'))
      return { success: true, code: res.status ?? 200, result: { url: data, prompt: echoed || prompt } }
    } catch (err) {
      return { success: false, code: err?.response?.status || 500, result: { error: err?.message || 'Error generate image' } }
    }
  },

  async videoStart({ prompt, isPremium = 1 }) {
    await aiLabs.setup.decrypt()
    const payload = {
      deviceID: aiLabs.deviceId(),
      isPremium,
      prompt,
      used: [],
      versionCode: 6,
    }
    try {
      const url = aiLabs.api.base + aiLabs.api.endpoints.videos
      const res = await axios.post(url, payload, { headers: aiLabs.headers })
      const { code, key } = res.data || {}
      if (code !== 0 || !key || typeof key !== 'string') {
        return { success: false, code: res.status ?? 500, result: { error: 'Gagal ambil key video' } }
      }
      return { success: true, code: res.status ?? 200, result: { key } }
    } catch (err) {
      return { success: false, code: err?.response?.status || 500, result: { error: err?.message || 'Start video error' } }
    }
  },

  async videoPoll(key, onProgress) {
    await aiLabs.setup.decrypt()
    const payload = { keys: [key] }
    const url = aiLabs.api.base + aiLabs.api.endpoints.videosBatch
    const maxAttempts = 100
    const waitMs = 2000
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        const res = await axios.post(url, payload, { headers: aiLabs.headers, timeout: 15000 })
        const { code, datas } = res.data || {}
        if (code === 0 && Array.isArray(datas) && datas.length) {
          const data = datas[0]
          if (data?.url && String(data.url).trim() !== '') {
            onProgress?.(100)
            return {
              success: true,
              code: res.status ?? 200,
              result: {
                url: String(data.url).trim(),
                safe: String(data.safe) === 'true',
                key: data.key,
                video_id: data.video_id,
                progress: '100%',
              },
            }
          }
          const p = Number.parseFloat(data?.progress || 0) || Math.round((attempt / maxAttempts) * 100)
          onProgress?.(Math.max(0, Math.min(100, Math.round(p))))
        }
        await new Promise(r => setTimeout(r, waitMs))
      } catch (err) {
        const retry = ['ECONNRESET', 'ECONNABORTED', 'ETIMEDOUT'].includes(err?.code)
        if (!retry) {
          return { success: false, code: err?.response?.status || 500, result: { error: err?.message || 'Polling error' } }
        }
        await new Promise(r => setTimeout(r, waitMs))
      }
    }
    return { success: false, code: 504, result: { error: 'Waktu habis nunggu video' } }
  },
}

// ==========================
//  Utils
// ==========================
const isCleanPrompt = (s) => /^[a-zA-Z0-9\s.,!?'"-]+$/.test(s)
const cdMs = 10_000

// ==========================
//  Handler
// ==========================
let handler = async (m, { conn, text, command, usedPrefix }) => {
  const user = global.db?.data?.users?.[m.sender]
  const now = Date.now()

  if (!text?.trim()) {
    return m.reply(
      [
        `*Contoh:*`,
        `${usedPrefix}aiimg neon cyberpunk city at night`,
        `${usedPrefix}aivideo dragon flying across mountains, cinematic`,
      ].join('\n')
    )
  }

  if (!isCleanPrompt(text)) {
    return m.reply('❌ Prompt mengandung karakter aneh. Gunakan huruf/angka/tanda baca umum.')
  }

  // Cooldown per user
  if (user) {
    const left = (user.lastAiGen || 0) + cdMs - now
    if (left > 0) return m.reply(`⏳ Coba lagi ${Math.ceil(left / 1000)} detik lagi.`)
  }

  const isImage = /^(aiimg)$/i.test(command)
  const isVideo = /^(aivideo)$/i.test(command)
  if (!isImage && !isVideo) return m.reply('❌ Command tidak dikenal. Pakai .aiimg atau .aivideo')

  try {
    if (isImage) {
      await m.reply('📡 Connect ke server AI (image)...')
      const res = await aiLabs.text2img(text)
      if (!res.success) throw new Error(res.result?.error || 'Gagal generate image')
      const url = res.result.url
      try {
        await conn.sendFile(m.chat, url, 'ai-image.jpg', `✅ Berhasil.\nPrompt: ${res.result.prompt}`, m)
      } catch {
        await conn.sendMessage(m.chat, { image: { url }, caption: `✅ Berhasil.\nPrompt: ${res.result.prompt}` }, { quoted: m })
      }
    } else {
      await m.reply('📡 Connect ke server AI (video)...')
      const start = await aiLabs.videoStart({ prompt: text, isPremium: 1 })
      if (!start.success) throw new Error(start.result?.error || 'Gagal mulai generate video')

      await m.reply('⏳ Video lagi diproses... bakal diupdate progresnya.')
      let last = -1
      const poll = await aiLabs.videoPoll(start.result.key, async (p) => {
        if (p >= last + 10) {
          last = p
          await conn.sendMessage(m.chat, { text: `⚡ Progress: ${p}%` }, { quoted: m })
        }
      })
      if (!poll.success) throw new Error(poll.result?.error || 'Video gagal dibuat')

      const vurl = poll.result.url
      try {
        await conn.sendMessage(m.chat, { video: { url: vurl }, caption: '✅ Berhasil. Nih videonya.' }, { quoted: m })
      } catch {
        await conn.sendMessage(m.chat, { text: `✅ Berhasil. Link video: ${vurl}` }, { quoted: m })
      }
    }

    if (user) user.lastAiGen = now
  } catch (e) {
    console.error('ai-labs error:', e?.message || e)
    return m.reply(`❌ ${e?.message || 'Terjadi kesalahan saat generate.'}`)
  }
}

// ==========================
//  Metadata plugin
// ==========================
handler.help = ['aiimg <prompt>', 'aivideo <prompt>']
handler.tags = ['ai']
handler.command = /^(aiimg|aivideo)$/i
handler.register = true
handler.limit = true

export default handler