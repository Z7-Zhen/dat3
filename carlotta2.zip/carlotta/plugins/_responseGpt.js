import { chatGpt } from '../scraper/nuy-chatGpt.js';

async function chat(text) {
   try {
  let { data } = await chatGpt(text)
  let pesan = data.pesan
  if (pesan) {
    let ipah = {
       mess: pesan
       }
       return ipah;
    } else {
   console.log('eror')
       }
    } catch(error) {
    return error
    }
}

export { chat }