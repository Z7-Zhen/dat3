import similarity from 'similarity'
const threshold = 0.72

export async function before(m) {
    let id = 'asahotak-' + m.chat
    if (
        !m.quoted ||
        !m.text ||
        !/Ketik.*hotak/i.test(m.quoted.text) ||
        /.*hotak/i.test(m.text)
    ) return !0

    this.game = this.game || {}
    if (!(id in this.game)) return m.reply('pertanyaan itu telah berakhir')

    const soalMsg = this.game[id][0]
    const quotedId = m.quoted?.id || m.quoted?.key?.id
    const soalId   = soalMsg?.key?.id || soalMsg?.id
    if (!quotedId || quotedId !== soalId) return !0

    let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(m.text)
    if (isSurrender) {
        clearTimeout(this.game[id][3])
        delete this.game[id]
        return m.reply('*Yah Menyerah :( !*', null, { quoted: soalMsg })
    }

    let json = JSON.parse(JSON.stringify(this.game[id][1]))
    const jawaban = json.jawaban.toLowerCase().trim()
    const userAns = m.text.toLowerCase().trim()

    if (userAns === jawaban) {
        global.db.data.users[m.sender].exp += this.game[id][2]
        m.reply(`*Benar!*\n+${this.game[id][2]} XP`, null, { quoted: soalMsg })
        clearTimeout(this.game[id][3])
        delete this.game[id]
    } else if (similarity(userAns, jawaban) >= threshold) {
        m.reply(`*Dikit Lagi!*`, null, { quoted: soalMsg })
    } else {
        m.reply(`*Salah!*`, null, { quoted: soalMsg })
    }

    return !0
}

export const exp = 0
