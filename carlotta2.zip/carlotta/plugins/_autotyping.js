import fs from "fs"

const isNumber = x => typeof x === 'number' && !Number.isNaN(x)
const delayFn = ms => isNumber(ms) ? new Promise(res => setTimeout(res, ms)) : Promise.resolve()

const DB_PATH = "./database/autotyping.json"
const loadDB = () => {
  const db = fs.existsSync(DB_PATH) ? JSON.parse(fs.readFileSync(DB_PATH)) : {}
  if (!db.autotyping) db.autotyping = { enabled: false, delay: 1000 }
  return db
}

let handler = m => m

handler.before = async function (m, { conn }) {
  try {
    if (!m) return true
    if (m.isBaileys && m.fromMe) return true

    const text = m.text || (m.message?.conversation) || ""
    if (!text) return true

    const prefixRegex = global?.prefix instanceof RegExp
      ? global.prefix
      : new RegExp('^[!/#.$]') // fallback sederhana

    if (!prefixRegex.test(text)) return true

    const db = loadDB()
    if (!db.autotyping?.enabled) return true

    const typingDelay = isNumber(db.autotyping.delay) ? db.autotyping.delay : 1000

    await this.readMessages?.([m.key]).catch(() => {})
    await this.sendPresenceUpdate?.('composing', m.chat).catch(() => {})
    await delayFn(typingDelay)
    await this.sendPresenceUpdate?.('paused', m.chat).catch(() => {})
  } catch (e) {
    console.error('[AUTO-TYPING ERROR]:', e)
  }
  return true
}

export default handler