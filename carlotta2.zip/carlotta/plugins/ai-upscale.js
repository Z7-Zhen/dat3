import axios from 'axios'
import FormData from 'form-data'
import { writeFileSync, unlinkSync, createReadStream } from 'fs'

let handler = async (m, { conn, usedPrefix, command, args }) => {
    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || q.mediaType || ''
    
    if (!mime) throw `⤷ Kirim atau reply gambar dengan caption: ${usedPrefix + command} 2`
    if (!/image\/(jpe?g|png)/.test(mime)) throw `⤷ Format ${mime} tidak didukung`

    const scaleRatio = parseInt(args[0])
    if (![2, 4].includes(scaleRatio)) {
        throw `⤷ Upscale hanya mendukung 2x atau 4x\nEX: ${usedPrefix + command} 2`
    }

    await m.reply(wait)

    const filename = `./tmp/${Date.now()}_upscale.jpg`

    try {
        const buffer = await q.download?.()
        writeFileSync(filename, buffer)

        const result = await upscale(filename, scaleRatio)

        if (!result.success || !result.downloadUrls?.length) throw '⤷ Tidak ada hasil dari server'

        const downloadUrl = result.downloadUrls[0]

        await conn.sendFile(m.chat, downloadUrl, 'upscaled.jpg', `
• ͙✧*:・ﾟ✧ ᴜᴘsᴄᴀʟᴇ ʀᴇsᴜʟᴛ ✧・ﾟ✧*:・ﾟ•
⤷ Size     : ${result.filesize}
⤷ Ratio    : ${scaleRatio}x
⤷ Status   : Success ✓
        `.trim(), flok)

    } catch (e) {
        console.error(e)
        m.reply(`✘ Upscale gagal: ${e.message || e}`)
    } finally {
        try { unlinkSync(filename) } catch {}
    }
}

handler.command = /^upscale$/i
handler.tags = ['ai']
handler.help = ['upscale [2|4]'].map(v => v + ' <reply image>')
handler.register = true
handler.premium = true

export default handler

async function upscale(imagePath, scaleRatio = 2, maxRetries = 30, retryDelay = 2000) {
    const upload = async () => {
        const data = new FormData()
        data.append('myfile', createReadStream(imagePath))
        data.append('scaleRadio', scaleRatio.toString())

        const config = {
            method: 'POST',
            url: 'https://get1.imglarger.com/api/UpscalerNew/UploadNew',
            headers: {
                ...data.getHeaders(),
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36',
                'Accept': 'application/json, text/plain, */*',
                'origin': 'https://imgupscaler.com',
                'referer': 'https://imgupscaler.com/'
            },
            data
        }

        const response = await axios.request(config)
        return response.data
    }

    const checkStatus = async (code) => {
        const config = {
            method: 'POST',
            url: 'https://get1.imglarger.com/api/UpscalerNew/CheckStatusNew',
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36',
                'Accept': 'application/json, text/plain, */*',
                'origin': 'https://imgupscaler.com',
                'referer': 'https://imgupscaler.com/'
            },
            data: JSON.stringify({ code, scaleRadio: scaleRatio })
        }

        const response = await axios.request(config)
        return response.data
    }

    const uploadResult = await upload()
    if (uploadResult.code !== 200) throw new Error(`Upload gagal: ${uploadResult.msg}`)

    const code = uploadResult.data.code

    for (let i = 0; i < maxRetries; i++) {
        const status = await checkStatus(code)
        if (status.code === 200 && status.data.status === 'success') {
            return {
                success: true,
                downloadUrls: status.data.downloadUrls,
                filesize: status.data.filesize,
                originalFilename: status.data.originalfilename,
                code: code
            }
        }

        if (status.data.status === 'error') throw new Error('⤷ Proses gagal di server')

        await new Promise(resolve => setTimeout(resolve, retryDelay))
    }

    throw new Error('⤷ Timeout: hasil tidak tersedia setelah beberapa percobaan')
}