let handler = async (m, { conn, text }) => {
  function no(number) {
    return number.replace(/\s/g, '').replace(/([@+-])/g, '')
  }

  text = no(text)
  let number = ''
  let user = ''
  let orang = ''

  if (text) {
    number = isNaN(text) ? text.split`@`[1] : text
    user = number + '@s.whatsapp.net'
    orang = "Orang yang kamu tag"
  } else if (m.quoted && m.quoted.sender) {
    user = m.quoted.sender
    orang = "Orang yang kamu balas"
  } else {
    user = m.sender
    orang = "Kamu"
  }

  const numLength = (number || '').length
  if (numLength > 15 || (numLength < 9 && numLength > 0)) {
    return conn.reply(m.chat, `Maaf, nomor yang kamu masukkan tidak valid!`, m)
  }

  if (!global.db.data.users[user]) {
    return m.reply("Target tidak terdaftar di dalam database!")
  }

  const targetSahabat = global.db.data.users[user].sahabat || ''

  if (targetSahabat && !global.db.data.users[targetSahabat]) {
    return m.reply("Sahabat target tidak ditemukan di database!")
  }

  if (!targetSahabat) {
    return conn.reply(m.chat,
      `${orang} belum memiliki sahabat dan tidak sedang mengajak siapapun.\n\n*Ketik .bersahabat @user untuk menjadi sahabat selamanya 💕*`,
      m
    )
  }

  if (global.db.data.users[targetSahabat].sahabat !== user) {
    return conn.reply(
      m.chat,
      `${orang} sedang menunggu jawaban dari @${targetSahabat.split('@')[0]} karena belum diterima atau ditolak.`,
      m,
      {
        contextInfo: {
          mentionedJid: [targetSahabat]
        }
      }
    )
  }

  return conn.reply(
    m.chat,
    `${orang} sedang menjalani persahabatan dengan @${targetSahabat.split('@')[0]} 🫂`,
    m,
    {
      contextInfo: {
        mentionedJid: [targetSahabat]
      }
    }
  )
}

handler.help = ['ceksahabat']
handler.tags = ['fun']
handler.command = /^ceksahabat$/i

handler.limit = true
export default handler