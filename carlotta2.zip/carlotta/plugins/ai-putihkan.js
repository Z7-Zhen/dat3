import gemini from 'btch-gemini'
import axios from 'axios'
import FormData from 'form-data'

async function uploadTemp(buffer) {
  const form = new FormData()
  form.append('reqtype', 'fileupload')
  form.append('fileToUpload', buffer, { filename: 'image.jpg' })

  const { data } = await axios.post('https://catbox.moe/user/api.php', form, {
    headers: form.getHeaders()
  })

  return data.trim()
}

let handler = async (m, { conn }) => {
  const q = m.quoted ? m.quoted : m
  const mime = (q.msg || q).mimetype || ''
  if (!/image\/(jpe?g|png)/.test(mime)) {
    return m.reply('📸 Reply gambar yang ingin diubah jadi putih (jpg/jpeg/png).')
  }

  m.reply(' Sedang memproses pemutihan...')

  try {
    let imgData = await q.download()
    if (typeof imgData.read === 'function') {
      imgData = Buffer.concat(await (async (stream) => {
        const chunks = []
        for await (const chunk of stream) chunks.push(chunk)
        return chunks
      })(imgData))
    }

    const uploadedUrl = await uploadTemp(imgData)

    // Prompt tetap untuk hijab
    const prompt = 'Convert the skin tone to a bright, fair, porcelain-like white complexion with soft, smooth texture and natural lighting. Maintain all other features exactly: facial structure, expression, eye and hair details, clothing, background, and overall scene composition. No changes except the skin tone. Do not overexpose or blur the skin—preserve realistic detail and shading.'

    const resultBuffer = await gemini.gemini_imgedit(prompt, uploadedUrl)

    await conn.sendMessage(m.chat, {
      image: resultBuffer,
      caption: '*✅ Selesai! Sudah di-putihkan cantik 💖*'
    }, { quoted: m })

  } catch (err) {
    console.error(err)
    m.reply('❌ Gagal mengedit gambar. Coba lagi nanti.')
  }
}

handler.command = ['putihkan']
handler.help = ['putihkan']
handler.tags = ['ai']
handler.premium = false
handler.limit = true

export default handler