let handler = async (m, { conn }) => {
  const isOwner = m.sender.includes('31616482629')
  let result = isOwner
    ? 'Gay Level : 0%\n\nLU PALING NORMAL SEDUNIA, OWNER GANTENG 😎'
    : pickRandom(global.gay)
  conn.reply(m.chat, `“${result}”`, m)
}

handler.help = ['gaycek']
handler.tags = ['fun']
handler.command = /^(gaycek|cekgay)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null
handler.limit = true

export default handler

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}

global.gay = [
  'Gay Level : 70%\n\nHebatnya kegayan lu',
  'Gay Level : 71%\n\nHebatnya kegayan lu',
  'Gay Level : 77%\n\nGak akan Salah Lagi dah gaynya lu',
  'Gay Level : 83%\n\nDijamin gay nya!',
  'Gay Level : 89%\n\nGay Banget!',
  'Gay Level : 94%\n\nTOBAT WOEE,, GAY LU UDH MELEWATI BATAS!😂',
  'Gay Level : 100%\n\nLU ORANG TERGAY YANG PERNAH ADA!!!',
  'Gay Level : 100%\n\nLU ORANG TERGAY YANG PERNAH ADA!!!',
  'Gay Level : 100%\n\nLU ORANG TERGAY YANG PERNAH ADA!!!',
  'Gay Level : 100%\n\nLU ORANG TERGAY YANG PERNAH ADA!!!',
]