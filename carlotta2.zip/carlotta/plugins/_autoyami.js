import axios from 'axios';
import { characterAi } from '../scraper/nuy-characterAi.js';

let handler = m => m;

handler.before = async (m, { isOwner, conn, text}) => {
    let chat = global.db.data.chats[m.chat];
    if (chat.autoRyo && !chat.isBanned) {
        if (!isOwner) return;
        if (/^.*false|disnable|(turn)?off|0/i.test(m.text)) return;
        if (!m.text) return;
        if (!m.quoted || !m.quoted.fromMe) return;
        try {
        let user = global.db.data.users[m.sender]
        let result = await characterAi(m.text, user.sessionId)
        let message = result.text

        //const { success, result } = response.data;

        if (message.split('').length > 1) {
            m.reply(message)
        } else {
            return m.reply(`Ada masalah dalam mengambil jawaban.`);
        }
    } catch (error) {
        console.error(error);
        return m.reply(`Terjadi kesalahan dalam komunikasi dengan server.`);
    }
    }
    return true;
}

handler.limit = true
export default handler;