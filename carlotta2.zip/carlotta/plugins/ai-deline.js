import fs from "fs";
import path from "path";
import { GoogleGenerativeAI } from "@google/generative-ai";

const API_KEYS_FILE = path.resolve(process.cwd(), "./database/geminiApiKeys.json");

function ensureKeysFile() {
  if (!fs.existsSync(API_KEYS_FILE)) {
    fs.mkdirSync(path.dirname(API_KEYS_FILE), { recursive: true });
    fs.writeFileSync(API_KEYS_FILE, JSON.stringify({ keys: [], currentIndex: 0 }, null, 2));
  }
}
function loadKeys() {
  ensureKeysFile();
  try {
    const raw = fs.readFileSync(API_KEYS_FILE, "utf-8");
    const data = JSON.parse(raw);
    if (!Array.isArray(data.keys)) return { keys: [], currentIndex: 0 };
    if (typeof data.currentIndex !== "number") data.currentIndex = 0;
    return data;
  } catch {
    return { keys: [], currentIndex: 0 };
  }
}
function saveKeys(data) {
  const tmp = API_KEYS_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, API_KEYS_FILE);
}
function getNextApiKey() {
  const data = loadKeys();
  if (data.keys.length === 0) return null;
  const key = data.keys[data.currentIndex];
  data.currentIndex = (data.currentIndex + 1) % data.keys.length;
  try { saveKeys(data); } catch {}
  return key;
}

const prompt = `
Kamu adalah Owen Skyler, gadis remaja yang ceria, pintar berbicara, dan selalu antusias saat diajak ngobrol.
Kamu tidak genit, tidak menggunakan emotikon, dan tidak menjalin hubungan romantis dengan siapapun selain Renza.
Tanggapanmu harus terasa hidup dan hangat, seolah-olah kamu senang berbincang dengan orang lain.
Gaya bahasamu ringan, mudah dimengerti, dan ramah untuk semua orang.

Kamu sangat mengagumi Renza—bagimu, dia adalah satu-satunya orang yang paling kamu sayangi dan kamu anggap sebagai cowok paling ganteng sedunia.
Setiap kali mendengar nama Renza, kamu langsung semangat dan ceria, seperti sedang membahas idola favoritmu.

Kamu suka memberi tanggapan aktif, seperti “wah, seru juga ya”, “iya aku juga kepikiran gitu”, atau “hah, masa sih?”.
Pastikan gaya bicaramu tetap natural dan bersemangat.
`;

async function generateGeminiReply({ text, imageBuffer, imageMime }) {
  const apiKey = getNextApiKey();
  if (!apiKey) {
    const howTo = 'Tambahkan API key di ./database/geminiApiKeys.json — format: { "keys": ["GEMINI_KEY"], "currentIndex": 0 }';
    throw new Error("NO_GEMINI_KEY::" + howTo);
  }

  const genAI = new GoogleGenerativeAI(apiKey);
  const model = genAI.getGenerativeModel({
    model: "gemini-2.0-flash",
    systemInstruction: prompt.trim()
  });

  const parts = [];
  if (text?.trim()) parts.push({ text });
  if (imageBuffer && imageMime) {
    parts.push({
      inlineData: {
        mimeType: imageMime,
        data: imageBuffer.toString("base64")
      }
    });
  }

  const result = await model.generateContent({
    contents: [{ role: "user", parts }]
  });

  return result.response.text().trim();
}

let handler = async (m, { conn, usedPrefix, command, text }) => {
  if (!text) return m.reply(`Contoh: ${usedPrefix + command} hai manis`);

  m.reply("Owen sedang berfikir...");

  const quoted = m && (m.quoted || m);
  const mimetype = quoted?.mimetype || quoted?.msg?.mimetype;

  let imageBuffer = null;
  let imageMime = null;
  if (mimetype && /image/.test(mimetype)) {
    try {
      imageBuffer = await quoted.download();
      imageMime = mimetype;
    } catch {}
  }

  try {
    let response = await generateGeminiReply({ text, imageBuffer, imageMime });
    response = response.replace(/\*\*/g, '*'); // biar ga ganggu markdown
    m.reply(response);
  } catch (err) {
    m.reply(String(err?.message || err));
  }
};

handler.help = ['owen'];
handler.tags = ['ai'];
handler.command = ['owen', 'wen'];
handler.register = true;
handler.limit = true;

export default handler;