let handler = async (m, { conn }) => {
  let users = global.db.data.users
  let sudahPasangan = []
  let nembak = []
  let pasanganDitampilkan = new Set()

  for (let id in users) {
    let user = users[id]
    let pasangan = user.pasangan

    if (!pasangan || !users[pasangan]) continue
    if (pasangan === id) continue // skip pacaran sama diri sendiri

    if (users[pasangan].pasangan === id) {
      let pasanganKey = [id, pasangan].sort().join('-')
      if (!pasanganDitampilkan.has(pasanganKey)) {
        sudahPasangan.push(`❤️ @${id.split('@')[0]} ❤️ @${pasangan.split('@')[0]}`)
        pasanganDitampilkan.add(pasanganKey)
      }
    } else {
      nembak.push(`💌 @${id.split('@')[0]} ➡️ @${pasangan.split('@')[0]}`)
    }
  }

  let teks = `*📋 STATUS HUBUNGAN PARA PENGGUNA:*\n\n`
  teks += `👩‍❤️‍👨 *Sudah Pacaran:*\n${sudahPasangan.length ? sudahPasangan.join('\n') : 'Tidak ada'}\n\n`
  teks += `💌 *Menembak Tapi Belum Diterima:*\n${nembak.length ? nembak.join('\n') : 'Tidak ada'}`

  let mentioned = [...sudahPasangan, ...nembak].flatMap(str =>
    str.match(/@(\d+)/g)?.map(n => n.replace('@', '') + '@s.whatsapp.net') || []
  )

  conn.reply(m.chat, teks, m, {
    contextInfo: { mentionedJid: mentioned }
  })
}

handler.help = ['listpacar']
handler.tags = ['fun']
handler.command = /^(listpacar|daftarpacar|cekpasangan|ceksemua)$/i
handler.register = true

handler.limit = true
export default handler