import fetch from "node-fetch"

let handler = async (m, { conn, participants }) => {
  let users = participants.map(u => u.id).filter(v => v !== m.sender)
  if (users.length < 3) return m.reply("👀 User di grup kurang dari 3 buat ranking tolol...")

  let acak = users.sort(() => 0.5 - Math.random()).slice(0, 3)
  let teks = `
╭─❏ *𝖳 𝖮 𝖯  𝖭 𝖨 𝖦 𝖠* ❏─╮
🌸 1. @${acak[0].split("@")[0]} (hitam banged kek 🐒)
🍡 2. @${acak[1].split("@")[0]} (hitam premium 🐢)
🍼 3. @${acak[2].split("@")[0]} (hitam nya ga medok 🐤)
╰─────────────────╯

✨ Niga of the day detected 💅🏻
`

  await conn.sendMessage(m.chat, { text: teks, mentions: acak }, { quoted: m })
}

handler.help = ["topniga"]
handler.tags = ["fun"]
handler.command = /^topniga$/i
handler.register = true

export default handler