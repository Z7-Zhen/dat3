// cekiq.js
let handler = async (m, { conn, text }) => {
  let who = m.mentionedJid?.[0]
    ? "@" + m.mentionedJid[0].split("@")[0]
    : text
      ? text
      : "Kamu"

  let iq = Math.floor(Math.random() * 141) + 40 

  let desc
  if (iq < 70) desc = "⌗ 𝒐𝒕𝒘 𝒃𝒆𝒈𝒐 ₊˚⊹♡"
  else if (iq < 90) desc = "꒰⑅ᵕ༚ᵕ꒱ Normal² aja ✨"
  else if (iq < 110) desc = "🌷 𝒏𝒐𝒓𝒎𝒂𝒍, 𝒔𝒐 𝒄𝒖𝒕𝒆!"
  else if (iq < 130) desc = "🧸 𝒄𝒆𝒓𝒅𝒂𝒔 𝒃𝒂𝒏𝒈𝒆𝒕!"
  else if (iq < 150) desc = "🌙 𝒑𝒊𝒏𝒕𝒂𝒓 𝒃𝒂𝒏𝒈𝒆𝒕 ˚｡⋆୨୧˚"
  else desc = "💫 𝒋𝒆𝒏𝒊𝒖𝒔 𝒈𝒊𝒍𝒂 ꒰ঌ♡໒꒱"

  let hasil = `｡･:*:･ﾟ★,｡･:*:･ﾟ☆\n  🌸 *ＣＥＫ ＩＱ* 🌸\nNama: ${who}\nIQ: ${iq}\nKeterangan: ${desc}\n｡･:*:･ﾟ★,｡･:*:･ﾟ☆`

  await conn.sendMessage(
    m.chat,
    { text: hasil, mentions: m.mentionedJid },
    { quoted: m }
  )
}

handler.help = ["cekiq [@tag/nama]"]
handler.tags = ["fun"]
handler.command = /^cekiq$/i

export default handler