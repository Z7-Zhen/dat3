export async function all(m) {
    if (!m.isGroup) return;

    let chats = global.db.data.chats[m.chat];
    if (!chats) global.db.data.chats[m.chat] = {};
    chats = global.db.data.chats[m.chat];

    if (!chats.expired) return;

    if (Date.now() > chats.expired) {
        await this.reply(m.chat, '⏳ Masa sewa grup ini telah habis!\nAku pamit ya, byebye 👋');
        await this.groupLeave(m.chat);
        chats.expired = null;
    }
}