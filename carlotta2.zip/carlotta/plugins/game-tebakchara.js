import fetch from 'node-fetch'
let timeout = 120000
let poin = 4999

let handler = async (m, { conn, command, usedPrefix }) => {
  conn.tebakchara = conn.tebakchara || {}
  const id = m.chat

  if (id in conn.tebakchara) {
    return conn.reply(m.chat, '❗Masih Ada Soal Yang Belum Terjawab', conn.tebakchara[id][0])
  }

  const res = await fetch('https://api.jikan.moe/v4/characters')
  const { data } = await res.json()
  const json = data[Math.floor(Math.random() * data.length)]
  const img = json?.images?.jpg?.image_url || json?.images?.webp?.image_url

  const caption = `*${command.toUpperCase()}*
❓Siapakah Nama Dari Foto Diatas?

🕑 Waktu *${(timeout / 1000).toFixed(2)} Detik*

💥 Bonus: ${poin} XP
Ketik ${usedPrefix}hcha Untuk Bantuan`.trim()

  const sent = await conn.sendFile(m.chat, img, 'char.jpg', caption, m)

  conn.tebakchara[id] = [
    sent,
    json,
    poin,
    setTimeout(async () => {
      if (conn.tebakchara[id]) {
        const capTimeout = `❗Waktu Habis!
Jawabannya Adalah *${json.name}*
Kanji : ${json.name_kanji || '-'}
URL   : ${json.url}`
        await conn.sendFile(m.chat, img, 'char.jpg', capTimeout, conn.tebakchara[id][0])
        delete conn.tebakchara[id]
      }
    }, timeout)
  ]
}

handler.help = ['tebakchara']
handler.tags = ['game']
handler.command = /^tebakchara$/i
handler.group = true

export default handler

const buttons = [
  ['Bantuan', '/hcha'],
  ['Nyerah', 'menyerah']
]
