import { ttSearch } from '../scraper/nuyTtSearch.js'

let handler = async(m, { text, conn, usedPrefix, command }) => {
   m.reply(wait)
   
   let response = await ttSearch('ceramah ustad adi hidayat')
   let { result } = response;
   
   if (result) {
   let { video_id, region, title, author, nickname, play, music } = result;
   let caption = `*Mohon Di Dengarkan*
    ✧ *Wm Creator:* ${author}`
    await conn.sendFile(m.chat, play, 'zaell-ofc.mp4', caption, m);
    } else {
    m.reply(eror)
    }
}
handler.help = ['ustadzadihidayat','uah']
handler.tags = ['ceramah']
handler.command = /^(uah|ceramahuah|ustadzaihidayat)$/i

handler.limit = true
export default handler