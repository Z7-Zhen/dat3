import axios from 'axios'
import FormData from 'form-data'
import ffmpeg from 'fluent-ffmpeg'
import fs from 'fs'
import fetch from 'node-fetch'
import { v4 as uuidv4 } from 'uuid'

const handler = async (m, { conn, usedPrefix, command, isPrems }) => {
  const user = global.db.data.users[m.sender]
  if (!user.hdUses) user.hdUses = 0
  if (!user.lastReset2) user.lastReset2 = 0

  const now = Date.now()
  if (!isPrems && now - user.lastReset2 > 5 * 60 * 60 * 1000) {
    user.hdUses = 0
    user.lastReset2 = now
  }

  if (!isPrems && user.hdUses >= 10) {
    return m.reply(`*Limit HD kamu sudah habis (${user.hdUses}/10).* Tunggu 5 jam atau ketik *${usedPrefix}premium* untuk upgrade ke unlimited.`)
  }

  conn.hdr = conn.hdr || {}
  if (m.sender in conn.hdr) return m.reply("Masih ada proses kamu yang belum selesai, tunggu dulu ya~")
  conn.hdr[m.sender] = true

  const q = m.quoted || m
  const mime = (q.msg || q).mimetype || q.mediaType || ''
  if (!mime || !/^image\/(jpe?g|png)|video\/mp4/.test(mime)) {
    delete conn.hdr[m.sender]
    return m.reply(`Kirim atau balas *gambar (.jpg/.png)* atau *video (.mp4)* untuk ditingkatkan ke HD`)
  }

  const isVideo = /^video\//.test(mime)
  m.reply(isVideo ? '🎞️ Sedang meningkatkan kualitas video ke 1080p...' : '📷 Sedang meningkatkan gambar ke HD...')

  const caption = `
✨ *Enhanced Successfully!* ✨
${isVideo
    ? '🎞️ _Your video has been enhanced to Full HD (1080p) resolution._'
    : '📷 _Your image has been enhanced using AI HD technology._'}
⬆️ *Before:* Low-quality
⬇️ *After:* Full HD-enhanced quality

💡 *Enjoy your upgraded media!* 💡
🔄 *HD Enhancements Used:* ${isPrems ? 'Unlimited' : `${user.hdUses + 1}/10`}
`.trim()

  try {
    const buffer = await q.download()

    if (!isVideo) {
      const imgUrl = await uploadImageForHD(buffer)
      const apiUrl = `https://api.deline.web.id/tools/hd?url=${encodeURIComponent(imgUrl)}`
      const r = await axios.get(apiUrl, { responseType: 'arraybuffer', timeout: 180000 })
      const hdBuffer = Buffer.from(r.data)

      await conn.sendMessage(m.chat, {
        image: hdBuffer,
        mimetype: 'image/jpeg',
        caption
      }, { quoted: m })

      user.hdUses += 1
      await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
      delete conn.hdr[m.sender]

    } else {
    
      const tmpDir = '/tmp'
      if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir)

      const inputFile = `${tmpDir}/${uuidv4()}.mp4`
      const outputFile = `${tmpDir}/${uuidv4()}_1080p.mp4`
      fs.writeFileSync(inputFile, buffer)

      ffmpeg()
        .input(inputFile)
        .videoCodec('libx264')
        .outputOptions([
          "-vf", "scale=1920:-2:flags=lanczos,unsharp=5:5:1.0",
          "-crf", "22",
          "-preset", "medium",
          "-pix_fmt", "yuv420p"
        ])
        .output(outputFile)
        .on('end', async () => {
          try {
            await conn.sendMessage(m.chat, {
              video: fs.readFileSync(outputFile),
              mimetype: 'video/mp4',
              caption
            }, { quoted: m })

            user.hdUses += 1
          } catch (e) {
            m.reply('❌ Gagal mengirim video hasil.')
          } finally {
            try {
              await fs.promises.unlink(inputFile)
              await fs.promises.unlink(outputFile)
            } catch {}
            delete conn.hdr[m.sender]
          }
        })
        .on('error', async err => {
          m.reply('❌ Gagal proses video: ' + err.message)
          try {
            if (fs.existsSync(inputFile)) await fs.promises.unlink(inputFile)
            if (fs.existsSync(outputFile)) await fs.promises.unlink(outputFile)
          } catch {}
          delete conn.hdr[m.sender]
        })
        .run()
    }
  } catch (err) {
    console.error('[HD Handler Error]', err)
    m.reply('❌ Terjadi kesalahan saat proses HD.')
    delete conn.hdr[m.sender]
  }
}

handler.help = ["hd", "hdr"]
handler.tags = ["ai", "tools"]
handler.command = /^(hd|hdr)$/i
handler.register = true

export default handler

async function uploadImageForHD(buffer) {
  try {
    const url = await uploadToTelegraph(buffer)
    return url
  } catch (e) {
    const url = await uploadToUguu(buffer)
    return url
  }
}

async function uploadToTelegraph(buffer) {
  const form = new FormData()
  form.append('file', buffer, {
    filename: `image_${Date.now()}.jpg`,
    contentType: 'image/jpeg'
  })
  const res = await axios.post('https://telegra.ph/upload', form, {
    headers: form.getHeaders(),
    timeout: 120000
  })
  if (!res.data || !Array.isArray(res.data) || !res.data[0]?.src) {
    throw new Error('Telegraph response invalid')
  }
  return 'https://telegra.ph' + res.data[0].src
}

async function uploadToUguu(buffer) {
  const form = new FormData()
  form.append('files[]', buffer, {
    filename: `image_${Date.now()}.jpg`,
    contentType: 'image/jpeg'
  })
  const res = await axios.post('https://uguu.se/upload.php', form, {
    headers: form.getHeaders(),
    timeout: 120000
  })
  if (!res.data?.files?.[0]?.url) throw new Error('Uguu response invalid')
  return res.data.files[0].url
}