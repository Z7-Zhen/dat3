let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) return conn.reply(
    m.chat,
    `Contoh penggunaan:\n${usedPrefix + command} aku siapa? @6283897387848 Bukan siapa²`,
    m,
    { contextInfo: { mentionedJid: ['6283133329293@s.whatsapp.net'] } }
  )

  let cm = copy(m)
  let who

  if (text.includes('@⁨WhatsApp Business⁩')) {
    who = '0@s.whatsapp.net'
  } else if (m.isGroup && m.mentionedJid.length > 0) {
    who = cm.participant = m.mentionedJid[0]
  } else if (m.quoted) {
    who = cm.participant = m.quoted.sender
  } else if (text.match(/^\d{5,20}$/)) {
    who = text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
  } else {
    return conn.reply(
      m.chat,
      `Contoh penggunaan:\n${usedPrefix + command} aku siapa? @6283897387848 Bukan siapa²`,
      m,
      { contextInfo: { mentionedJid: ['6289662933232@s.whatsapp.net'] } }
    )
  }

  cm.key.fromMe = false
  cm.message[m.mtype] = copy(m.msg)

  let sp = '@' + who.split`@`[0]
  let [fake, ...realParts] = text.split(sp)
  let isiPesan = realParts.join(sp).trimStart()
  let namaMention = await conn.getName(who)

  conn.fakeReply(
    m.chat,
    isiPesan.replace(sp, '@' + namaMention),
    who,
    fake.trimEnd(),
    m.isGroup ? m.chat : false,
    {
      contextInfo: {
        mentionedJid: [who]
      }
    }
  )
}

handler.help = ['fitnah <teks> @user <teks>']
handler.tags = ['fun']
handler.command = /^(fitnah|fakereply)$/i

handler.limit = true
export default handler

function copy(obj) {
  return JSON.parse(JSON.stringify(obj))
}