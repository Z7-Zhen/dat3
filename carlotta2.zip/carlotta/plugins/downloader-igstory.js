/*
 • Fitur By Anomaki Team
 • Created : xyzan code
 • Instagram story video downloader via username
 • Jangan Hapus Wm
 • https://whatsapp.com/channel/0029Vaio4dYC1FuGr5kxfy2l
*/

import axios from 'axios';
const handler = async (m, {
    conn,
    args,
    usedPrefix,
    command
}) => {
    if (!args[0]) {
        return conn.reply(m.chat, `✧ Contoh penggunaan:\n${usedPrefix}${command}username\n\nContoh:\n${usedPrefix}${command} mrbeast`, m);
    }

    const username = args[0].replace(/[@.]/g, '').trim();

    try {
        await conn.reply(m.chat, '⏳ Bentar ya Owen ambil dulu', m);

        const res = await axios.get(`https://apis-anomaki.zone.id/downloader/igdl-story?username=${username}`, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Mobile Safari/537.36',
                'Referer': 'https://apis-anomaki.zone.id/'
            },
            timeout: 30000
        });

        if (!res.data?.status || !res.data?.result?.stories?.length) {
            throw new Error('gak ada story video yang ditemukan');
        }

        const story = res.data.result.stories.filter(item => item.media_type === 2);

        if (!story.length) {
            throw new Error('gak ada story video yang tersedia');
        }

        for (const [index, item] of story.entries()) {
            try {
                const judul = `✧ Instagram Story Video\n\n` +
                    `➤ Username: ${username}\n` +
                    `➤ Waktu: ${new Date(item.taken_at).toLocaleString()}\n` +
                    `➤ ${index + 1}/${story.length}`;

                await conn.sendMessage(m.chat, {
                    video: {
                        url: item.download_video_url
                    },
                    caption: judul
                }, {
                    quoted: m
                });

                if (index < story.length - 1) {
                    await new Promise(resolve => setTimeout(resolve, 2500));
                }
            } catch (er) {
                console.error(`Gagal mengirim video ${index + 1}:`, er);
            }
        }

    } catch (er) {
        console.error('Error:', er);
        let errorMessage = 'Yah gagal sensei, mungkin karna story gada atau usernamenya salah';
        if (er.response?.status === 404) {
            errorMessage = 'Username gak ditemukan';
        } else if (er.code === 'ECONNABORTED') {
            errorMessage = 'Server gak merespon';
        }
        conn.reply(m.chat, `${errorMessage}`, m);
    }
};

handler.help = ['igstory username'];
handler.tags = ['downloader'];
handler.register = true
handler.command = /^(igstory|igs|igdlstory)$/i;
handler.limit = true;

export default handler;