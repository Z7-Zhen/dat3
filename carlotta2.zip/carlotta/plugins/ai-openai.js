import axios from 'axios'

async function sendCopilotRequest(text) {
  const endpoint = `https://api.deline.web.id/ai/copilot?q=${encodeURIComponent(text)}`
  const { data } = await axios.get(endpoint) 

  if (!data?.status) {
    throw new Error(data?.error || 'API error')
  }

  return {
    conversationId: data.result?.conversationId || null,
    messageId: data.result?.messageId || null,
    text: data.result?.text || data.result?.reply || ''
  }
}

let handler = async (m, { text, conn }) => {
  if (!text) return m.reply('Masukkan pertanyaan!\nContoh: *.ai siapa presiden pertama Indonesia?*')

  try {
    await conn.sendMessage(m.chat, {
      react: {
        text: '👨‍💻',
        key: m.key
      }
    })

    const result = await sendCopilotRequest(text)
    let reply = `🧠 *Open AI:*\n${(result.text || '').trim() || '_Tidak ada jawaban_'}`

    await m.reply(reply)
  } catch (err) {
    console.error(err)
    m.reply('❌ Gagal menghubungi openai.')
  }
}

handler.command = ['ai','openai']
handler.help = ['ai <teks>']
handler.tags = ['ai']
handler.register = true
handler.limit = true

export default handler