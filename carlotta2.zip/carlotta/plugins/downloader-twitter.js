import { twitDown } from '../scraper/nuy-twitDown.js';

let handler = async(m, { args, text, conn, usedPrefix, command }) => {
  if (!text) return m.reply(`Urlnya Mana?\n\n*Contoh:* ${usedPrefix + command} https://x.com/Xxxxxxx\n> Khusus Video!`)
  
  conn.sendMessage(m.chat, { react: { text: '🦜', key: m.key }})
  let res = await twitDown(text)
  let { title, username, url_author, upload, video } = res.data
  
  if (video && title) {
     await conn.sendFile(m.chat, video, '', `\`<\\> T W I T T E R <\\>\`\n\n*- Title:* ${title}\n*- Upload:* ${upload}\n*- Username:* ${username}\n*- Url Author:* ${url_author}`, m, 0, {
      mimetype: "video/mp4",
      fileName: `nuyy.mp4`
    });
    conn.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
  } else {
    console.log('eror kak, hub owner')
   }
}
handler.tags = ['downloader']
handler.help = ['twit','twitter','x']
handler.command = /^(twit|twitter|x)$/i
handler.register = true
handler.limit = true

export default handler