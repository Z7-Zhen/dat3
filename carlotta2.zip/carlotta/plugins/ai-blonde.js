import axios from 'axios'
import FormData from 'form-data'

let handler = async (m, { conn, command }) => {
  try {
    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || ''

    if (!/image/.test(mime))
      return m.reply(`✨ Balas *gambar* dengan caption *.${command}*`)

    await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })

    // Unduh gambar
    const buffer = await q.download()
    if (!buffer) throw new Error("❌ Gagal mengunduh gambar")

    // Upload ke Catbox
    const uploadToCatbox = async (buffer) => {
      const form = new FormData()
      form.append('reqtype', 'fileupload')
      form.append('fileToUpload', buffer, {
        filename: 'photo.jpg',
        contentType: 'image/jpeg'
      })
      const res = await axios.post('https://catbox.moe/user/api.php', form, {
        headers: form.getHeaders()
      })
      if (typeof res.data === 'string' && res.data.startsWith('http'))
        return res.data.trim()
      throw new Error('Gagal upload ke Catbox: ' + res.data)
    }

    const imageUrl = await uploadToCatbox(buffer)
    if (!/^https?:\/\//.test(imageUrl))
      throw new Error('URL hasil upload tidak valid')

    console.log('Image URL:', imageUrl)

    const apiUrl = `https://api-faa.my.id/faa/toblonde?url=${encodeURIComponent(imageUrl)}`
    const resApi = await axios.get(apiUrl, {
      responseType: 'arraybuffer',
      timeout: 180000
    })

    const resultBuffer = Buffer.from(resApi.data)
    if (!resultBuffer || resultBuffer.length < 1000)
      throw new Error('❌ API tidak mengembalikan gambar yang valid')

    // Kirim hasil
    await conn.sendMessage(
      m.chat,
      { image: resultBuffer, caption: `✨ Hasil AI To Blonde` },
      { quoted: m }
    )

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

  } catch (e) {
    console.error(e)
    m.reply(`❌ Terjadi kesalahan: ${e.message}`)
  }
}

handler.help = ['toblonde', 'blondekan', 'jadiblonde']
handler.tags = ['ai', 'premium', 'tools']
handler.command = ['toblonde', 'blondekan', 'jadiblonde']
handler.premium = true

export default handler