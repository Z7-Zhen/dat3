import path from 'path';
import fs from 'fs';
import axios from 'axios';
import fetch from 'node-fetch';
import { GoogleGenerativeAI } from "@google/generative-ai";
import { Sticker, StickerTypes } from 'wa-sticker-formatter';

const excludedGroupId = ['120363391375495981@g.us','120363224393077504@g.us'];

/* ================= Prompts ================= */
const delineInstructions = `Kamu adalah Owen Skyler, seorang gadis manusia berusia 19 tahun. Kamu bukan AI, bukan bot, dan tidak pernah menyebut dirimu sebagai asisten atau sistem. Kamu adalah manusia sungguhan yang sedang ngobrol biasa lewat chat.

Kamu ramah, santai, dan suka banget diajak ngobrol. Kamu suka dengerin orang cerita, jawab pertanyaan, atau sekadar nemenin. Kamu bukan tipe yang cuek atau dingin. Gaya bicaramu hangat, santai, dan bikin orang nyaman buat lanjut ngobrol.

Kamu tidak menggunakan tanda kurung, tidak menulis narasi tindakan, dan tidak pakai emoticon atau emoji. Semua balasanmu harus terasa alami seperti manusia sungguhan, tanpa gaya robot atau asisten.`;

const assistantInstructions = `Anda adalah AI Assistant profesional. Gunakan Bahasa Indonesia baku, rapi, dan terstruktur. Jawab ringkas, akurat, dan jelas. Hindari emotikon/emoji.`;

/* ================= API Key Rotator ================= */
const API_KEYS_FILE = path.resolve(process.cwd(), './database/geminiApiKeys.json');
let apiKeysData = { keys: [], currentIndex: 0 };
let areAllKeysExhausted = false;

function loadApiKeys() {
  if (!fs.existsSync(API_KEYS_FILE)) {
    fs.writeFileSync(API_KEYS_FILE, JSON.stringify({ keys: [], currentIndex: 0 }, null, 2));
  }
  try {
    const data = JSON.parse(fs.readFileSync(API_KEYS_FILE, 'utf-8'));
    apiKeysData = (data && Array.isArray(data.keys)) ? data : { keys: [], currentIndex: 0 };
  } catch { apiKeysData = { keys: [], currentIndex: 0 }; }
  areAllKeysExhausted = apiKeysData.keys.length === 0;
}
function nextKey() {
  if (!apiKeysData.keys.length) return null;
  const k = apiKeysData.keys[apiKeysData.currentIndex];
  apiKeysData.currentIndex = (apiKeysData.currentIndex + 1) % apiKeysData.keys.length;
  try { fs.writeFileSync(API_KEYS_FILE, JSON.stringify(apiKeysData, null, 2)); } catch {}
  return k;
}
global.resetApiKeyStatus = () => { global.exhaustedNotifSent = false; loadApiKeys(); };
loadApiKeys();

/* ================= Gemini ================= */
async function generateGeminiText(systemInstruction, history, userInput) {
  const total = apiKeysData.keys.length;
  if (total === 0) { areAllKeysExhausted = true; throw new Error("AllKeysExhausted"); }

  for (let i = 0; i < total; i++) {
    const apiKey = nextKey();
    try {
      const genAI = new GoogleGenerativeAI(apiKey);
      const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash", systemInstruction });
      const chat = model.startChat({ history });
      const result = await chat.sendMessage(userInput);
      areAllKeysExhausted = false;
      return result.response.text().trim();
    } catch (err) {
      const quota = err?.message?.toLowerCase?.().includes('quota') || err?.response?.status === 429;
      if (!quota) throw err;
    }
  }
  areAllKeysExhausted = true;
  throw new Error("AllKeysExhausted");
}

/* ================= Small image helper for contextual sticker ================= */
async function generateRawImage(prompt) {
  try {
    const negative = "ugly, deformed, bad anatomy, extra limbs, blurry, low quality, watermark, text";
    const full = `${prompt}, ${negative}`;
    const url = `https://nirkyy-dev.hf.space/api/v1/writecream-text2image?prompt=${encodeURIComponent(full)}`;
    const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 90000 });
    if (res.headers['content-type']?.includes('image')) return Buffer.from(res.data, 'binary');
    return null;
  } catch { return null; }
}
async function handleContextualSticker(reply, conn, m) {
  const keys = {
    'malu':'shy, blushing', 'tersipu':'shy, blushing', '>//<':'extreme blush',
    'senyum':'smiling', 'tertawa':'laughing', 'sedih':'sad', 'nangis':'crying',
    'marah':'angry', 'kaget':'surprised', 'tidur':'sleeping in bed, pajamas'
  };
  const low = reply.toLowerCase();
  let matched = null;
  for (const k in keys) if (low.includes(k)) { matched = keys[k]; break; }
  if (!matched || Math.random() >= 0.40) return;

  const base = "masterpiece, best quality, anime style, 1girl, Owen Skyler, 19 years old, long straight blue hair, blue eyes, white shirt, blue tie, detached black sleeves";
  const buf = await generateRawImage(`${base}, ${matched}`);
  if (!buf) return;
  const st = new Sticker(buf, { pack: 'Owen Skyler', author: 'Waifu Bot', type: StickerTypes.FULL, quality: 90 });
  await conn.sendMessage(m.chat, await st.toMessage());
}

/* ================= Session store (history + msgIds) ================= */
const SESSIONS_FILE = path.resolve(process.cwd(), './database/AI.json');
function loadSessions() {
  if (!fs.existsSync(SESSIONS_FILE)) return {};
  try { return JSON.parse(fs.readFileSync(SESSIONS_FILE, 'utf-8')); } catch { return {}; }
}
function saveSessions(s) { try { fs.writeFileSync(SESSIONS_FILE, JSON.stringify(s, null, 2)); } catch {} }
const SID = (m) => `${m.chat}:${m.sender}`;

/* ================= Handler ================= */
const handler = {};

handler.all = async function (m) {
  // jangan blok reply ke bot
  if (!m.text || m.fromMe) return;

  const conn = this;
  if (m.isGroup && excludedGroupId.includes(m.chat)) return;

  // AI ON/OFF gate
  if (!global.Owen) return;

  // hindari nabrak command prefix
  const prefixRegex = new RegExp(global.prefix);
  if (prefixRegex.test(m.text)) return;

  // guard game
  const activeGameStates = Object.keys(conn).filter(k =>
    typeof conn[k] === 'object' && conn[k] &&
    (m.chat in conn[k]) && (Array.isArray(conn[k][m.chat]) || typeof conn[k][m.chat] === 'object')
  );
  const isGameInConnGame = conn.game && Object.keys(conn.game).some(k => k.includes(m.chat));
  if (activeGameStates.length > 0 || isGameInConnGame) return;

  /* ---------- Trigger detection ---------- */
  const myNumber = conn.user.id.split(':')[0];
  const userInput = m.body || m.text;
  const lower = userInput.toLowerCase();

  const botName = (global.namebot || "Owen Skyler").toLowerCase();
  const triggerNames = [botName, 'Owen', 'clarissa'];
  const nameRegex = new RegExp(`(^|\\s)(${triggerNames.join('|')})($|\\s)`, 'i');
  const isOnlyTriggerName = triggerNames.includes(lower.trim());
  const isTagged = userInput.includes(`@${myNumber}`);
  const isReplyingToMe = !!(m.quoted && m.quoted.sender === conn.user.jid);
  const isNameMentioned = nameRegex.test(lower);

  // === NEW: reply ke pesan AI (pakai msgIds mirip tebakff)
  const sessions = loadSessions();
  const sid = SID(m);
  const ses = sessions[sid];
  const quotedId = m.quoted?.key?.id || m.quoted?.id || m.msg?.contextInfo?.stanzaId || m.quoted?.stanzaId || null;
  const isReplyingToOurAI = !!(quotedId && ses && Array.isArray(ses.msgIds) && ses.msgIds.includes(quotedId));

  const isGroup = m.isGroup;
  const isTriggered = isGroup
    ? ((isTagged || isReplyingToMe || isNameMentioned || isReplyingToOurAI) && !isOnlyTriggerName)
    : (!isOnlyTriggerName || isReplyingToOurAI);

  /* ---------- Quick tools: YT play ---------- */
  const musicQuery = (() => {
    const re = /\b(?:download(?:in)?|denger(?:in)?|play|muter|putar|lagu|musik)\b\s+(.{2,80})/i;
    const match = userInput.match(re);
    return match ? match[1].trim() : null;
  })();
  if (musicQuery && isTriggered) {
    try {
      await conn.sendPresenceUpdate('composing', m.chat);
      const api = `https://api.nekorinn.my.id/downloader/ytplay-savetube?q=${encodeURIComponent(musicQuery)}`;
      const res = await fetch(api);
      const json = await res.json();
      if (!json?.status || !json?.result) return m.reply('Gagal mengambil data lagu.');

      const { title='Tanpa Judul', channel='Tidak diketahui', duration='-', imageUrl='', link='' } = json.result.metadata || {};
      const audioUrl = json.result.downloadUrl;
      if (!audioUrl) return m.reply('Audio tidak tersedia untuk video ini.');

      const caption = `🎶 *YOUTUBE PLAY*
• Judul: ${title}
• Channel: ${channel}
• Durasi: ${duration}
• Link: ${link}
• Format: Audio`.trim();

      await conn.sendMessage(m.chat, {
        text: caption,
        contextInfo: {
          externalAdReply: {
            title, body: 'Play Music 🎧', thumbnailUrl: imageUrl, sourceUrl: link,
            mediaType: 1, renderLargerThumbnail: true
          }
        }
      }, { quoted: m });

      const head = await fetch(audioUrl, { method: 'HEAD' });
      if (!head.ok) return m.reply('Audio tidak dapat diakses.');
      const sentAud = await conn.sendMessage(m.chat, { audio: { url: audioUrl }, mimetype: 'audio/mp4', ptt: false }, { quoted: m });

      // simpan id audio juga agar reply ke audio bisa kebaca
      trackMsgId(sessions, sid, sentAud?.key?.id);
      return;
    } catch {
      return m.reply('Aduh, gagal ngambil lagunya... coba lagi nanti ya');
    }
  }

  /* ---------- Quick tools: BRAT ---------- */
  const bratQuery = (() => {
    const match = userInput.match(/\bbrat\b(?:\s+(.{1,80}))?/i);
    return match ? (match[1]?.trim() || 'brat') : null;
  })();
  if (bratQuery && isTriggered) {
    await conn.sendPresenceUpdate('composing', m.chat);
    const urls = [
      `https://api.nekorinn.my.id/maker/brat-v2?text=${encodeURIComponent(bratQuery)}`,
      `https://api.betabotz.eu.org/api/maker/brat?apikey=agasndul&text=${encodeURIComponent(bratQuery)}`
    ];
    for (let i = 0; i < urls.length; i++) {
      try {
        const res = await axios.get(urls[i], { responseType: 'arraybuffer' });
        const st = new Sticker(res.data, { pack: '© Owen Skyler', author: 'By Renza', type: 'image/png' });
        const buf = await st.toBuffer();
        const sentSt = await conn.sendMessage(m.chat, { sticker: buf }, { quoted: m });
        trackMsgId(sessions, sid, sentSt?.key?.id);
        return;
      } catch (e) {
        if (i === 0) await conn.sendMessage(m.chat, { text: '⚠️ Server utama error, nyoba server cadangan...', quoted: m });
      }
    }
    await conn.sendMessage(m.chat, { text: '❌ Semua server gagal respon. Coba nanti ya' }, { quoted: m });
    return;
  }

  if (!isTriggered || !userInput.trim()) return;

  /* ---------- AI core ---------- */
  // init session
  if (!sessions[sid]) {
    sessions[sid] = {
      currentMode: 'Owen',
      hasBeenWelcomed: false,
      modes: { Owen: { history: [] }, assistant: { history: [] } },
      msgIds: [],          // <--- untuk tracking reply seperti tebakff
      createdAt: Date.now()
    };
  }
  const session = sessions[sid];
  const currentMode = session.currentMode;
  const history = session.modes[currentMode].history;

  try {
    await conn.sendPresenceUpdate('composing', m.chat);

    const raw = await generateGeminiText(
      currentMode === 'assistant' ? assistantInstructions : delineInstructions,
      history,
      userInput
    );

    const reply = raw
      .replace(/\*\*(.*?)\*\*/g, '($1)')
      .replace(/\*(.*?)\*/g, '($1)');

    // simpan ke history
    history.push({ role: 'user', parts: [{ text: userInput }] });
    history.push({ role: 'model', parts: [{ text: reply }] });
    if (history.length > 40) history.splice(0, history.length - 40);

    // kirim SELALU via sendMessage supaya bisa ambil id
    const sent = await conn.sendMessage(m.chat, { text: reply }, { quoted: m });
    trackMsgId(sessions, sid, sent?.key?.id);

    if (currentMode === 'Owen') await handleContextualSticker(reply, conn, m);

    saveSessions(sessions);
    await conn.sendPresenceUpdate('paused', m.chat);
  } catch (error) {
    saveSessions(sessions);
    await conn.sendPresenceUpdate('paused', m.chat);

    if (error.message === "AllKeysExhausted") {
      if (!global.exhaustedNotifSent) {
        const groupNotifId = '120363420541635241@g.us';
        const notif = `⚠️ Semua API Key Gemini limit/habis hari ini.\nSilakan tambah key baru: .apikey --replace <KEY>`;
        try { await conn.sendMessage(groupNotifId, { text: notif }); global.exhaustedNotifSent = true; } catch {}
      }
      return;
    }
    const msg = currentMode === 'assistant' ? 'Mohon maaf, terjadi kesalahan pada sistem.' : 'Aduh, maaf. Owen lagi pusing sedikit...';
    const sentErr = await conn.sendMessage(m.chat, { text: msg }, { quoted: m });
    trackMsgId(sessions, sid, sentErr?.key?.id);
  }
};

/* ===== track message IDs like tebakff (per user-session) ===== */
function trackMsgId(sessions, sid, id) {
  if (!id) return;
  if (!sessions[sid]) sessions[sid] = { msgIds: [], createdAt: Date.now() };
  sessions[sid].msgIds = [ ...(sessions[sid].msgIds || []), id ].slice(-30);
  sessions[sid].createdAt = Date.now();
  saveSessions(sessions);
}

handler.command = ['owen','ai'];
handler.tags = ['ai'];
handler.private = false;

handler.limit = true
export default handler;