let handler = async (m, { conn }) => {
    conn.tebakchara = conn.tebakchara || {}
    let id = m.chat
    if (!(id in conn.tebakchara)) throw false

    const jawaban = (conn.tebakchara[id][1]?.name || '').trim()
    const clue = jawaban.replace(/[AIUEOaiueo]/ig, '_')

    conn.reply(
        m.chat,
        '```' + clue + '```',
        conn.tebakchara[id][0] // quoted ke pesan soal
    )
}

handler.command = /^hcha$/i

export default handler
