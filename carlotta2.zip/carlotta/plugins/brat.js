import axios from 'axios';
import { Sticker } from 'wa-sticker-formatter';

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `Contoh penggunaan:\n${usedPrefix + command} kamu hytam 😭`;

    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    try {
        const url = `https://api-faa.my.id/faa/brat?text=${encodeURIComponent(text)}`;
        const res = await axios.get(url, { responseType: 'arraybuffer' });

        const sticker = new Sticker(res.data, {
            pack: '© Owen Skyler',
            author: 'Renza',
            type: 'image/png',
        });

        const buffer = await sticker.toBuffer();
        const msg = await conn.sendMessage(m.chat, { sticker: buffer }, { quoted: m });

        await conn.sendMessage(m.chat, { react: { text: '🎉', key: msg.key } });
    } catch (err) {
        console.error('API gagal:', err?.response?.status || err.message);
        await conn.reply(m.chat, '❌ Gagal membuat stiker. Coba lagi nanti ya 😓', m);
    }
};

handler.help = ['brat', 'stext'];
handler.tags = ['sticker'];
handler.command = /^(brat|stext)$/i;
handler.register = true;
handler.limit = true;

export default handler;