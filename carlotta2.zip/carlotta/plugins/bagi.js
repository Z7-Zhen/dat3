let handler = async (m, { conn, text, usedPrefix, command }) => {
  const args = text.trim().split(/\s+/);

  if (args.length < 2) {
    throw `Format salah!\nContoh penggunaan: ${usedPrefix + command} 10 2`;
  }

  const a = parseFloat(args[0]);
  const b = parseFloat(args[1]);

  if (isNaN(a) || isNaN(b)) {
    throw `Pastikan kedua input adalah angka!\nContoh: ${usedPrefix + command} 10 2`;
  }

  if (b === 0) {
    throw `Tidak bisa membagi dengan nol!`;
  }

  const result = a / b;
  await conn.reply(m.chat, `${a} ÷ ${b} = *${result}*`, m);
};

handler.help = ['bagi'];
handler.tags = ['tools'];
handler.command = /^bagi$/i;
handler.register = true;
handler.limit = false;

handler.limit = true
export default handler;