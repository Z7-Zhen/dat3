let handler = async (m, { conn }) => {
    conn.game = conn.game || {}
    let id = 'tebakgambar-' + m.chat

    // Pastikan game aktif
    if (!(id in conn.game)) throw false

    const jawaban = (conn.game[id][1]?.jawaban || '').trim()
    const clue = jawaban.replace(/[AIUEOaiueo]/ig, '_')

    conn.reply(
        m.chat,
        `Clue : \`\`\`${clue}\`\`\`\n\n_*Jangan Balas Chat Ini Tapi Balas Soalnya*_`,
        conn.game[id][0] // quoted ke pesan soal
    )
}

handler.command = /^hgamb$/i

handler.group = true

export default handler
