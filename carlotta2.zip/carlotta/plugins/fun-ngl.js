import axios from "axios";

let handler = async (m, { text, usedPrefix, command }) => {
  const defaultLink = "https://ngl.link/renza_owen";
  if (!text) throw `📨 Cara pakai:\n${usedPrefix + command} <pesan>\n\nContoh:\n${usedPrefix + command} kamu ganteng banget 😋`;

  m.reply("⏳ Mengirim pesan anonim ke NGL...");

  try {
    const api = `https://api-faa.my.id/faa/ngl?link=${encodeURIComponent(defaultLink)}&text=${encodeURIComponent(text)}`;
    const { data } = await axios.get(api, { timeout: 30000 });

    if (data?.status === true || data?.success) {
      await m.reply(`✅ Pesan berhasil dikirim ke:\n${defaultLink}\n\n📝 Isi pesan: ${text}`);
    } else {
      throw data?.error || "Gagal mengirim pesan ke NGL.";
    }
  } catch (err) {
    console.error("Error .ngl:", err);
    await m.reply(`❌ Error saat mengirim ke NGL.\n\nDetail: ${err?.message || err}`);
  }
};

handler.help = ["ngl <pesan>"];
handler.tags = ["fun", "tools"];
handler.command = /^ngl$/i;
handler.register = true;
handler.limit = true;

export default handler;