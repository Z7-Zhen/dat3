import { db, saveDB } from '../lib/monopoli-db.js'
import { drawBoardImage } from '../lib/monopoli-board.js' // async function buat gambar papan & token

// Buat papan monopoli sederhana
function createBoard() {
  return [
    { name: "Start", type: "start" },
    { name: "Tanah 1", type: "property", price: 100, rent: 10, owner: null },
    { name: "Pajak", type: "tax", amount: 50 },
    { name: "Tanah 2", type: "property", price: 120, rent: 12, owner: null },
    { name: "Penjara", type: "jail" },
    { name: "Tanah 3", type: "property", price: 150, rent: 15, owner: null },
    { name: "Kesempatan", type: "chance" },
    { name: "Stasiun", type: "property", price: 130, rent: 13, owner: null },
    { name: "Hotel", type: "property", price: 200, rent: 25, owner: null },
    { name: "Taman", type: "property", price: 110, rent: 11, owner: null },
    { name: "Pajak Mewah", type: "tax", amount: 100 },
    { name: "Tanah 4", type: "property", price: 140, rent: 14, owner: null },
  ]
}

// Fungsi lempar dadu 1-6
function rollDice() {
  return Math.floor(Math.random() * 6) + 1
}

// Ganti giliran pemain berikutnya
function nextTurn(game) {
  game.turnIndex = (game.turnIndex + 1) % game.turnOrder.length
  return game.turnOrder[game.turnIndex]
}

// Event kartu kesempatan
const chanceEffects = [
  { text: "Kamu dapat bonus $200!", apply: p => p.money += 200 },
  { text: "Bayar denda $100", apply: p => p.money -= 100 },
  { text: "Maju 2 langkah", apply: (p, game) => { p.pos = (p.pos + 2) % game.board.length } },
  { text: "Mundur 2 langkah", apply: (p, game) => { p.pos = (p.pos - 2 + game.board.length) % game.board.length } }
]

// Handler utama command monopoli
const handler = async (m, { conn, args }) => {
  const sender = m.sender
  const chatID = m.chat

  if (!db.monopoli) db.monopoli = { games: {} }
  const games = db.monopoli.games

  if (!games[chatID]) {
    games[chatID] = {
      players: {},
      turnOrder: [],
      turnIndex: 0,
      board: createBoard(),
      pendingBuy: null,
      started: false,
    }
  }

  const game = games[chatID]
  const isJoined = !!game.players[sender]
  const cmd = (args[0] || '').toLowerCase()

  if (!cmd) {
    // Pesan tutorial saat cuma ketik !monopoli
    const tutorial = `*Game Monopoli*\n\n` +
      `Perintah:\n` +
      `- !monopoli join : Gabung ke permainan\n` +
      `- !monopoli start : Mulai permainan (hanya pemain pertama)\n` +
      `- !monopoli roll : Lempar dadu giliranmu\n` +
      `- !monopoli beli : Beli properti yang kamu landai\n` +
      `- !monopoli jual [index] : Jual properti\n` +
      `- !monopoli status : Lihat status pemain\n` +
      `- !monopoli reset : Reset permainan (hanya pemain pertama)\n\n` +
      `Minimal 2 pemain, maksimal 5.\n` +
      `Giliran pertama adalah pemain pertama yang join.\n`
    return conn.reply(chatID, tutorial, m)
  }

  if (cmd === 'join') {
    if (game.started) return conn.reply(chatID, 'Game sudah dimulai, tidak bisa join.', m)
    if (isJoined) return conn.reply(chatID, 'Kamu sudah bergabung!', m)
    if (game.turnOrder.length >= 5) return conn.reply(chatID, 'Jumlah pemain sudah maksimal (5).', m)

    game.players[sender] = { pos: 0, money: 1500, props: [] }
    game.turnOrder.push(sender)
    saveDB()
    return conn.reply(chatID, `Pemain @${sender.split('@')[0]} bergabung.`, m, { contextInfo: { mentionedJid: [sender] } })
  }

  if (!isJoined) {
    return conn.reply(chatID, 'Kamu belum bergabung! Ketik *!monopoli join* dulu.', m)
  }

  if (cmd === 'start') {
    if (game.started) return conn.reply(chatID, 'Game sudah dimulai.', m)
    if (game.turnOrder[0] !== sender) return conn.reply(chatID, 'Hanya pemain pertama yang bergabung yang bisa mulai game.', m)
    if (game.turnOrder.length < 2) return conn.reply(chatID, 'Minimal 2 pemain untuk mulai game.', m)

    game.started = true
    game.turnIndex = 0
    saveDB()
    const firstPlayer = game.turnOrder[0]
    return conn.reply(chatID, `Game dimulai! Giliran pertama: @${firstPlayer.split('@')[0]}`, m, { contextInfo: { mentionedJid: [firstPlayer] } })
  }

  if (!game.started) {
    return conn.reply(chatID, 'Game belum dimulai. Tunggu pemain pertama memulai dengan *!monopoli start*.', m)
  }

  if (cmd === 'roll') {
    if (game.turnOrder[game.turnIndex] !== sender) return conn.reply(chatID, 'Bukan giliran kamu!', m)

    const dice = rollDice()
    const player = game.players[sender]
    player.pos = (player.pos + dice) % game.board.length
    const tile = game.board[player.pos]

    let message = `🎲 Dadu: ${dice}\n📍 Kamu mendarat di: *${tile.name}*\n`

    if (tile.type === 'property') {
      if (!tile.owner) {
        if (player.money >= tile.price) {
          game.pendingBuy = { user: sender, tileIndex: player.pos }
          saveDB()
          const path = await drawBoardImage(game.board, game.players)
          return await conn.sendFile(chatID, path, 'monopoli.png',
            `🏠 Properti *${tile.name}* tersedia seharga $${tile.price}.\nKetik *!monopoli beli* untuk membelinya.`, m)
        } else {
          message += "💸 Uangmu tidak cukup untuk membeli."
        }
      } else if (tile.owner !== sender) {
        const rent = tile.rent
        player.money -= rent
        game.players[tile.owner].money += rent
        message += `💰 Kamu membayar sewa $${rent} ke @${tile.owner.split('@')[0]}`
      } else {
        message += "🏡 Ini properti milikmu."
      }
    } else if (tile.type === 'tax') {
      player.money -= tile.amount
      message += `💸 Kamu bayar pajak $${tile.amount}`
    } else if (tile.type === 'jail') {
      message += "🚓 Kamu ke penjara (giliran tetap jalan)."
    } else if (tile.type === 'chance') {
      const effect = chanceEffects[Math.floor(Math.random() * chanceEffects.length)]
      effect.apply(player, game)
      message += `🎁 Kesempatan: ${effect.text}`
    }

    // Cek bangkrut
    if (player.money < 0) {
      message += `\n☠️ Kamu bangkrut! Semua properti dilelang.`
      player.props.forEach(i => game.board[i].owner = null)
      player.props = []
      delete game.players[sender]
      game.turnOrder = game.turnOrder.filter(id => id !== sender)
      if (game.turnIndex >= game.turnOrder.length) game.turnIndex = 0
    }

    const next = nextTurn(game)
    const path = await drawBoardImage(game.board, game.players)
    message += `\n\n🔁 Selanjutnya: @${next.split('@')[0]}`
    await conn.sendFile(chatID, path, 'monopoli.png', message, m)
    saveDB()
    return
  }

  if (cmd === 'beli') {
    if (!game.pendingBuy || game.pendingBuy.user !== sender) return conn.reply(chatID, 'Tidak ada properti untuk dibeli saat ini.', m)

    const player = game.players[sender]
    const tile = game.board[game.pendingBuy.tileIndex]

    if (player.money < tile.price) {
      game.pendingBuy = null
      return conn.reply(chatID, '💸 Uangmu tidak cukup untuk membeli properti ini.', m)
    }

    player.money -= tile.price
    player.props.push(game.pendingBuy.tileIndex)
    tile.owner = sender
    game.pendingBuy = null
    saveDB()
    return conn.reply(chatID, `Kamu berhasil membeli *${tile.name}* seharga $${tile.price}.`, m)
  }

  if (cmd === 'jual') {
    const player = game.players[sender]
    if (player.props.length === 0) return conn.reply(chatID, 'Kamu tidak punya properti untuk dijual.', m)
    const index = parseInt(args[1]) - 1
    if (isNaN(index) || index < 0 || index >= player.props.length) return conn.reply(chatID, 'Index properti tidak valid.', m)
    const tileIndex = player.props[index]
    const tile = game.board[tileIndex]
    tile.owner = null
    player.money += Math.floor(tile.price / 2)
    player.props.splice(index, 1)
    saveDB()
    return conn.reply(chatID, `Kamu berhasil menjual *${tile.name}* dan mendapatkan $${Math.floor(tile.price / 2)}.`, m)
  }

  if (cmd === 'status') {
    let statusMsg = `📊 *Status Pemain:*\n\n`
    for (const id of game.turnOrder) {
      const p = game.players[id]
      if (!p) continue
      statusMsg += `@${id.split('@')[0]}\n💵 Uang: $${p.money}\n🏠 Properti: `
      if (p.props.length === 0) statusMsg += `-`
      else statusMsg += p.props.map(i => game.board[i].name).join(', ')
      statusMsg += '\n\n'
    }
    return conn.reply(chatID, statusMsg, m, { contextInfo: { mentionedJid: game.turnOrder } })
  }

  if (cmd === 'reset') {
    if (game.turnOrder[0] !== sender) return conn.reply(chatID, 'Hanya pemain pertama yang bisa reset permainan.', m)
    delete games[chatID]
    saveDB()
    return conn.reply(chatID, 'Permainan telah di-reset.', m)
  }

  return conn.reply(chatID, 'Perintah tidak dikenali.', m)
}

handler.help = ['join', 'start', 'roll', 'beli', 'jual', 'status', 'reset'].map(v => 'monopoli ' + v)
handler.tags = ['game']
handler.command = /^monopoli$/i

export default handler
