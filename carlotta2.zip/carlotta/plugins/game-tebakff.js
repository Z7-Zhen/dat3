import fetch from 'node-fetch'

const timeout = 60000 
const rewardMoney = 10000
const rewardExp = 5000

let handler = async (m, { conn }) => {
  conn.tebakff = conn.tebakff || {}

  if (conn.tebakff[m.chat]) {
    return m.reply('🚫 Game sedang berlangsung di chat ini!\nHarap selesaikan terlebih dahulu sebelum memulai yang baru.')
  }

  try {
    const url = `https://api.deline.web.id/game/tebakff`
    const res = await fetch(url)
    const data = await res.json()

    const item = data?.result
    if (!item) throw 'Data karakter tidak ditemukan.'

    const img = item.img || item.fullimg
    const jawaban = String(item.jawaban || '').toLowerCase().trim()
    const deskripsi = item.deskripsi || ''

    if (!img || !jawaban) throw 'Data tidak lengkap dari API.'

    const sent = await conn.sendMessage(m.chat, {
      image: { url: img },
      caption: `*Tebak Karakter Free Fire!*\n\nBalas (reply) pesan ini dengan nama karakternya dari gambar di atas.\n(Waktu: 60 detik)`
    }, { quoted: m })

    conn.tebakff[m.chat] = {
      jawab: jawaban,
      timeout: setTimeout(() => {
        m.reply(`⏰ Waktu habis!\nJawabannya adalah *${jawaban}*`)
        delete conn.tebakff[m.chat]
      }, timeout),
      msgId: sent.key.id 
    }

  } catch (e) {
    console.error(e)
    m.reply('⚠️ Gagal memulai game tebak karakter.')
  }
}

handler.before = async function (m, { conn }) {
  conn.tebakff = conn.tebakff || {}
  const sesi = conn.tebakff[m.chat]
  if (!sesi) return

  const quotedId = m.quoted?.id || m.quoted?.key?.id
  if (!quotedId || quotedId !== sesi.msgId) return

  const norm = (s = '') => String(s).toLowerCase().trim()
  const jawaban = norm(sesi.jawab)
  const teks = norm(m.text)
  const user = global.db.data.users[m.sender]

  if (teks === jawaban) {
    clearTimeout(sesi.timeout)
    delete conn.tebakff[m.chat]
    user.money += rewardMoney
    user.exp += rewardExp
    m.reply(`🎉 *Benar!* Jawabannya adalah *${jawaban}*\n\n💰 +${rewardMoney} money\n💎 +${rewardExp} exp`)
  } else {
    m.reply(`❌ *Salah!* Coba lagi.\nClue: Nama terdiri dari *${jawaban.length}* huruf.`)
  }

  return true
}

handler.command = /^tebakff$/i
handler.tags = ['game']
handler.help = ['tebakff']
handler.register = true

export default handler