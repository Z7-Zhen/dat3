// src/yukichat-gemini.js
import fs from 'fs'
import path from 'path'
import { GoogleGenerativeAI } from '@google/generative-ai'

const ownerID = global.nomorwa + '@s.whatsapp.net'
const dbPath = path.join(process.cwd(), 'src/yukichat.json')

const API_KEYS_FILE = path.resolve(process.cwd(), './database/geminiApiKeys.json')
const SESSION_TTL_MS = 60_000         // 1 menit
const MAX_HISTORY = 12                // simpan 12 turn (user+bot)

// ===== API key rotation
function ensureKeysFile() {
  if (!fs.existsSync(API_KEYS_FILE)) {
    fs.mkdirSync(path.dirname(API_KEYS_FILE), { recursive: true })
    fs.writeFileSync(API_KEYS_FILE, JSON.stringify({ keys: [], currentIndex: 0 }, null, 2))
  }
}
function loadKeys() {
  ensureKeysFile()
  try {
    const raw = fs.readFileSync(API_KEYS_FILE, 'utf-8')
    const data = JSON.parse(raw)
    if (!Array.isArray(data.keys)) return { keys: [], currentIndex: 0 }
    if (typeof data.currentIndex !== 'number') data.currentIndex = 0
    return data
  } catch { return { keys: [], currentIndex: 0 } }
}
function saveKeys(data) {
  const tmp = API_KEYS_FILE + '.tmp'
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2))
  fs.renameSync(tmp, API_KEYS_FILE)
}
function getNextApiKey() {
  const data = loadKeys()
  if (data.keys.length === 0) return null
  const key = data.keys[data.currentIndex]
  data.currentIndex = (data.currentIndex + 1) % data.keys.length
  try { saveKeys(data) } catch {}
  return key
}

// ===== Gemini
async function geminiGenerate({ systemInstruction, history = [], userText, modelName = 'gemini-2.0-flash' }) {
  const apiKey = getNextApiKey()
  if (!apiKey) throw new Error('NO_GEMINI_KEY::Tambahkan API key di ./database/geminiApiKeys.json — { "keys": ["GEMINI_KEY"], "currentIndex": 0 }')

  const genAI = new GoogleGenerativeAI(apiKey)
  const model = genAI.getGenerativeModel({ model: modelName, systemInstruction })

  // history: [{role:'user'|'model', text:'...'}]
  const contents = [
    ...history.map(h => ({ role: h.role, parts: [{ text: h.text }] })),
    { role: 'user', parts: [{ text: userText }] }
  ]

  const result = await model.generateContent({ contents })
  return (result.response.text() || '').trim()
}

// ===== Prompts
const ownerSystem = `
Kamu adalah Owen Skyler, gadis remaja yang ceria dan perhatian.
Kamu sangat dekat dengan Renza (owner). Balas hangat, sopan, tanpa emotikon/emoji.
Gaya bahasa ringan, natural, positif. Jangan pakai tanda kurung atau narasi tindakan.
`.trim()

const tsundereSystem = `
Owen adalah wanita tsundere, cuek ke semua orang.
Jawaban singkat, padat, agak jutek, panggil "Senpai". Tanpa emotikon/emoji.
Jangan pakai tanda kurung atau narasi tindakan.
`.trim()

const emojiSystem = `
You analyze the tone of the Indonesian text and return ONE emoji character only.
No words, no punctuation, no spaces.
`.trim()

// ===== Opening texts
const randomTexts = [
  'Ada apa manggil manggil?','Iya kak Kenapa?','Udah makan Belum kak?','Hmm??','Nyariin Ya?',
  'Mandi sono','Apa coba','Yoo Gw disini!!','Bomatt','Capek menanggapi','Napa butuh bantuan?',
  'Berisik luh','Jangan lupa bernapas','Kenapa dah','Lagi tes sinyal?','Oi oi','Iya',
  'Jangan ngagetin dong','Hah?','humm??','Lagi ngapain sih?','Pagi, apa kabar?',
  'Eh, loh kok nyanyi?','Sabar ya, aku bales','Woi, santai dong','Laper ga?','Keren ga suaraku?',
  'Aku tidur bentar ya','Cepet balesnya dong','Lagi nonton apa?'
]
const ownerTexts = [
  'Hallo za','Kenapa zaa??','Aku di sini za','Ui zaa','Makan belum zaa?','Udah mandi belum za?',
  'Semangat zaa','Aku selalu di sini za','Aku Online Kok','Aman udah ku urus za','Yo Ownerkuu',
  'Za, lagi apa?','Siap bantu za','zaa, chill ya','Halo raja Renza','Zaa, apa kabar?',
  'Ownerku panggil, siap!','Zaa, aku setia nih','Za, jangan lupa istirahat','Za, aku imut ga?',
  'Halo Zaa','Za, aku cepet bales ya','Ownerku, apa kabar?','Zaa, santai aja','Zaa aku standby nih'
]
const premiumTexts = [
  'Yo, apa kabar?','Senpai premium, apa kabar?','Oi VIP, butuh apa?','Halo, ready bantu!',
  'Waduh, yang premium manggil!','Chill, aku ada nih','Premium call, apa kabar?','Eh, yang spesial nyapa!',
  'Siap bantu anytime!','Yuhuu, premium mode on!','Premium, apa kabar?','VIP nih, apa kabar?',
  'Halo, yang eksklusif!','Premium, aku siap!','Yo yo, yang spesial nyanyi','Senpai VIP, chill ya',
  'Premium squad, apa kabar?','Aku spesial buatmu','VIP call, siap bantu!','Premium mode, let’s go!',
  'Halo, kece ya?','Senpai premium, aku di sini','VIP, santai aja','Premium nih, aku bales cepet',
  'Yo, yang spesial, apa kabar?'
]

// ===== Store helpers
const getSessionId = (m) => `${m.sender}` // per user
function loadStore() {
  if (!fs.existsSync(path.dirname(dbPath))) fs.mkdirSync(path.dirname(dbPath), { recursive: true })
  return fs.existsSync(dbPath) ? JSON.parse(fs.readFileSync(dbPath, 'utf8')) : {}
}
function saveStore(obj) { fs.writeFileSync(dbPath, JSON.stringify(obj, null, 2)) }
function pick(arr){ return arr[Math.floor(Math.random()*arr.length)] }

// ===== Main trigger
let handler = async (m, { conn }) => {
  let store = loadStore()

  const isOwner = m.sender === ownerID
  const isPremium = global.isPremium && global.isPremium.includes(m.sender)

  let text = isOwner ? pick(ownerTexts) : isPremium ? pick(premiumTexts) : pick(randomTexts)

  const sessionId = getSessionId(m)
  const sent = await conn.sendMessage(m.chat, { text }, { quoted: m })
  const firstId = sent?.key?.id || null

  store[sessionId] = {
    user: m.sender,
    chat: m.chat,
    msgIds: firstId ? [firstId] : [],
    createdAt: Date.now(),
    history: [] // [{role:'user'|'model', text}]
  }

  setTimeout(() => {
    try {
      const cur = loadStore()
      delete cur[sessionId]
      saveStore(cur)
    } catch {}
  }, SESSION_TTL_MS)

  saveStore(store)
}

// ===== Reply flow (with history)
handler.before = async (m, { conn }) => {
  if (!m.text || !m.quoted) return
  if (/^[.\#!\/\\]/.test(m.text)) return

  let store = loadStore()
  const sessionId = getSessionId(m)
  const sesi = store[sessionId]
  if (!sesi) return

  const quotedId =
    m.quoted?.id ||
    m.quoted?.key?.id ||
    m.msg?.contextInfo?.stanzaId ||
    m.quoted?.stanzaId ||
    m.quoted?.contextInfo?.stanzaId ||
    null

  const isMatch = quotedId && Array.isArray(sesi.msgIds) && sesi.msgIds.includes(quotedId)
  if (!isMatch) return

  if (Date.now() - (sesi.createdAt || 0) > SESSION_TTL_MS) {
    delete store[sessionId]
    saveStore(store)
    return
  }

  await conn.sendMessage(m.chat, { react: { text: '🫎', key: m.key } })

  try {
    const systemInstruction = (m.sender === ownerID) ? ownerSystem : tsundereSystem

    // siapkan history max MAX_HISTORY
    const history = (sesi.history || []).slice(-MAX_HISTORY)

    const reply = await geminiGenerate({
      systemInstruction,
      history,
      userText: m.text
    })

    const cleaned = reply.replace(/\*\*/g, '*').trim()
    await conn.sendMessage(m.chat, { react: { text: '', key: m.key } })

    // kirim balasan + emoji terpisah
    const emoji = await geminiGenerate({
      systemInstruction: emojiSystem,
      history: [],
      userText: cleaned
    }).then(t => (t || '').trim()).catch(() => '😒')

    const ids = []
    const parts = splitTsundereRandom(cleaned)
    for (let i = 0; i < parts.length; i++) {
      const id = await sendMessageWithDelay(conn, m.chat, parts[i], m, i * 1500)
      if (id) ids.push(id)
    }
    if (parts.length < 3) {
      const id = await sendMessageWithDelay(conn, m.chat, emoji.length > 4 ? '😒' : emoji, m, parts.length * 1500)
      if (id) ids.push(id)
    }

    // update sesi
    sesi.msgIds = [...(sesi.msgIds || []), ...ids].slice(-30)
    sesi.createdAt = Date.now()
    // simpan history (user + model)
    sesi.history = [
      ...(sesi.history || []),
      { role: 'user', text: m.text },
      { role: 'model', text: cleaned }
    ].slice(-MAX_HISTORY)

    store[sessionId] = sesi
    saveStore(store)
  } catch (e) {
    await conn.sendMessage(m.chat, { react: { text: '', key: m.key } })
    if (String(e?.message || '').startsWith('NO_GEMINI_KEY::')) {
      m.reply('API key belum diset.\n' + String(e.message).split('::')[1])
    } else {
      m.reply('Hah? Error? Sabar ya, Senpai, aku joget dulu: "Error ilang, bug kabur~"')
    }
  }
}

// ===== Utils
function splitTsundereRandom(text) {
  const sentences = text.split('. ').filter(s => s.trim())
  const randomCount = Math.floor(Math.random() * 3) + 1
  const messages = []
  if (sentences.length <= 1) return [text]
  for (let i = 0; i < randomCount && i < sentences.length; i++) {
    messages.push(sentences[i] + (sentences[i].endsWith('.') ? '' : '.'))
  }
  if (messages.length < sentences.length) {
    messages[messages.length - 1] += ' ' + sentences.slice(messages.length).join('. ')
  }
  return messages
}
async function sendMessageWithDelay(conn, chatId, text, quotedMsg, delayMs) {
  await new Promise(r => setTimeout(r, delayMs))
  const sent = await conn.sendMessage(chatId, { text }, { quoted: quotedMsg })
  return sent?.key?.id || null
}

handler.customPrefix = /^(owen|wen|bot)$/i
handler.command = new RegExp()

export default handler