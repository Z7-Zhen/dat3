import fs from 'fs';
import moment from 'moment-timezone';

const FILE_PATH = './src/absen.json';

function loadAbsenData() {
  if (!fs.existsSync(FILE_PATH)) fs.writeFileSync(FILE_PATH, '{}');
  const data = JSON.parse(fs.readFileSync(FILE_PATH));

  const today = moment().tz('Asia/Jakarta').format('YYYY-MM-DD');

  // 🔁 Hapus semua data absen hari sebelumnya
  for (const date in data) {
    if (date !== today) {
      delete data[date];
    }
  }

  return data;
}

function saveAbsenData(data) {
  fs.writeFileSync(FILE_PATH, JSON.stringify(data, null, 2));
}

const handler = async (m, { conn, command, isAdmin }) => {
  const jid = m.sender;
  const groupId = m.chat;
  const now = moment().tz('Asia/Jakarta');
  const jam = now.hour();
  const today = now.format('YYYY-MM-DD');
  const data = loadAbsenData();

  // Struktur awal data
  if (!data[today]) data[today] = {};
  if (!data[today][groupId]) data[today][groupId] = { list: {} };

  const absen = data[today][groupId];

  switch (command) {
    case 'absen':
      if (jam < 6) {
        return m.reply(`🕒 *Absen belum dimulai!*\nAbsen baru dibuka jam *06:00 WIB*`);
      }

      if (jam >= 12) {
        return m.reply(`🚫 *Absen sudah ditutup!*\nAbsen ditutup jam *12:00 WIB*`);
      }

      if (absen.list[jid]) {
        return m.reply(`ℹ️ *Kamu sudah absen hari ini*\nWaktu: ${absen.list[jid]}`);
      }

      const waktu = now.format('HH:mm');
      absen.list[jid] = waktu;

      // 🎁 Reward
      const user = global.db.data.users?.[jid];
      if (user) {
        user.money = (user.money || 0) + 1000000;
        user.limit = (user.limit || 0) + 5;
      }

      saveAbsenData(data);
      m.reply(`✅ *Absen berhasil!*\nWaktu tercatat: ${waktu}\n\n🎁 Kamu mendapat:\n• 💰 *1.000.000 Money*\n• ✨ *5 Limit*`);
      break;

    case 'absensi':
      if (!isAdmin) return m.reply('⛔ *Hanya admin yang bisa melihat absensi!*');

      const entries = Object.entries(absen.list || {});
      const list = entries.map(([jid, time], i) => `${i + 1}. @${jid.split('@')[0]} 🕒 ${time}`).join('\n') || '📭 Belum ada yang absen hari ini.';

      conn.sendMessage(m.chat, {
        text: `📋 *Daftar Absensi (${today}):*\n\n${list}`,
        mentions: entries.map(([jid]) => jid)
      }, { quoted: m });
      break;
  }
};

handler.help = ['absen', 'absensi'];
handler.tags = ['group'];
handler.command = ['absen', 'absensi'];
handler.group = true;

handler.limit = true
export default handler;