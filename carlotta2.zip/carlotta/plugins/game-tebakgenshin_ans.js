import similarity from 'similarity'

let poin = 10000
const threshold = 0.72
let handler = m => m

handler.before = async function (m, { conn }) {
  let id = m.chat
  let users = global.db.data.users[m.sender]

  if (!m.quoted || !/Ketik.*gca/i.test(m.quoted.text)) return !0

  this.tebakgenshin = this.tebakgenshin || {}
  if (!(id in this.tebakgenshin)) return conn.reply(m.chat, 'Soal itu telah berakhir', m)

  const soalMsg  = this.tebakgenshin[id][0]
  const quotedId = m.quoted?.id || m.quoted?.key?.id
  const soalId   = soalMsg?.key?.id || soalMsg?.id
  if (!quotedId || quotedId !== soalId) return !0

  let json = JSON.parse(JSON.stringify(this.tebakgenshin[id][1]))
  const jawaban = json.jawaban.toLowerCase().trim()
  const userAns = (m.text || '').toLowerCase().trim()

  if (userAns === jawaban) {
    global.db.data.users[m.sender].exp += this.tebakgenshin[id][2]
    global.db.data.users[m.sender].tiketcoin += 1
    users.money = (users.money || 0) + poin
    await conn.reply(m.chat, `*Benar!*\n+${this.tebakgenshin[id][2]} money`, soalMsg)
    clearTimeout(this.tebakgenshin[id][3])
    delete this.tebakgenshin[id]
  } else if (similarity(userAns, jawaban) >= threshold) {
    await conn.reply(m.chat, `*Dikit Lagi!*`, soalMsg)
  } else {
    await conn.reply(m.chat, `*Salah!*`, soalMsg)
  }

  return !0
}

handler.exp = 0

export default handler
