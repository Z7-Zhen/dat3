import { areJidsSameUser } from '@adiwajshing/baileys'

function resolveJid(input, participants = []) {
    const found = participants.find(p =>
        areJidsSameUser(p?.id, input) ||
        areJidsSameUser(p?.lid, input) ||
        areJidsSameUser(p?.jid, input)
    )
    return found?.jid || input
}

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)]
}

let handler = async (m, { conn, text, participants }) => {
    if ((!text || !text.trim()) && (!m.mentionedJid || !m.mentionedJid.length)) {
        return conn.reply(m.chat, '📌 Contoh: .cekbh nama / @user', m)
    }

    let name, mentions = []

    if (m.mentionedJid && m.mentionedJid.length) {
        const targetJid = resolveJid(m.mentionedJid[0], participants)
        name = '@' + targetJid.split('@')[0]
        mentions = [targetJid]
    } else {
        name = text.trim()
    }

    const sizes = ['30A','32B','32C','32D','34A','34B','34C','36A','36B','36C','38A','38B','38C','40A','40B','40C','42A','42B','42C','42D']
    const colors = ['Merah','Biru','Hijau','Kuning','Hitam','Putih','Oranye','Ungu','Coklat','Abu-abu','Merah Muda','Biru Muda','Hijau Muda','Krem','Biru Tua','Hijau Tua','Biru Langit','Toska','Salmon','Emas','Perak','Magenta','Cyan','Olive','Navy']
    const shapes = ['Boxer','Brief','Trunk','Thong','Jockstrap','Bikini','Hipster','Tanga','G-string','T-brief','Mini Boxer','Shorty','Midi','Maxi','Slip','High-leg','Cheeky','Brazilian','Cutaway','Sport Brief']

    conn.reply(m.chat, `
╭━━━━°「 *BH ${name}* 」°
┃
┊• Nama : ${name}
┃• Ukuran : ${pickRandom(sizes)}
┊• Warna : ${pickRandom(colors)}
┃• Bentuk : ${pickRandom(shapes)}
╰═┅═━––––––๑
`.trim(), m, { mentions })
}

handler.help = ['cekbh *<text|@user>*']
handler.tags = ['fun']
handler.command = /^cekbh$/i
handler.limit = true
handler.register = true

export default handler