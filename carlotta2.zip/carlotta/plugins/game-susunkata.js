import fetch from 'node-fetch'

let timeout = 180000 
let money = 5000
let limit = 1

let handler = async (m, { conn, usedPrefix }) => {
  conn.susunkata = conn.susunkata || {}
  const id = m.chat

  if (id in conn.susunkata) {
    conn.reply(m.chat, ' *❗Masih Ada Soal Yang Belum Terjawab* ', conn.susunkata[id][0])
    throw false
  }

  try {
    const res = await fetch('https://api.deline.web.id/game/susunkata')
    if (!res.ok) throw `❌ API error: ${res.status} ${res.statusText}`

    const data = await res.json()
    if (!data?.status || !data?.result) throw '❌ Gagal mengambil soal dari API.'

    const json = data.result 

    const caption = `
📄 ${json.soal}

Tipe : ${json.tipe}

🕑 Timeout *${(timeout / 1000).toFixed(0)} detik*

💰 Hadiah
Limit: ${limit}
Money: ${money}
Ketik ${usedPrefix}suska untuk bantuan
`.trim()

    const sentMsg = await conn.reply(m.chat, caption, m)

    conn.susunkata[id] = [
      sentMsg,
      json,
      money,
      setTimeout(() => {
        if (conn.susunkata[id]) {
          conn.reply(m.chat, `❗ Waktu habis!\nJawabannya adalah *${json.jawaban}*`, conn.susunkata[id][0])
          delete conn.susunkata[id]
        }
      }, timeout)
    ]
  } catch (e) {
    console.error(e)
    m.reply('❌ Gagal memulai game Susun Kata. Silakan coba lagi nanti.')
  }
}

handler.help = ['susunkata']
handler.tags = ['game']
handler.command = /^susunkata|sskata/i
handler.group = true

export default handler