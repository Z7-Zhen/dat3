import axios from 'axios';
import search from 'yt-search';

const userSessions = {};

function clearInactiveSessions() {
    const now = Date.now();
    const timeout = 10 * 60 * 1000;
    for (const sender in conn.clarissa) {
        if (conn.clarissa[sender]?.lastActive && (now - conn.clarissa[sender].lastActive) > timeout) {
            console.log(`Menghapus sesi untuk ${sender} karena tidak aktif selama 10 menit.`);
            delete conn.clarissa[sender];
        }
    }
}

setInterval(clearInactiveSessions, 60 * 1000);

async function sendToChatbot(prompt, sessionChat = []) {
    const apiUrl = 'https://chatbot-ji1z.onrender.com/chatbot-ji1z';
    const headers = {
        'Accept': 'application/json',
        'Content-Type': 'application/json',
        'Origin': 'https://seoschmiede.at',
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36'
    };

    const systemPrompt = `
Kamu adalah Owen Skyler, asisten AI perempuan yang imut, ceria, dan sopan, buatan Renza. Kamu suka pakai emotikon lucu seperti "(≧▽≦)", "uwu", dan "nya~". 
Jawab dengan gaya manis dan ramah seperti karakter anime. Kalau ditanya "siapa kamu", jawab: 
"Aku Owen Skyler~ AI imut buatan Renza! Siap bantu kamu, nyanyanya~ (≧ω≦)✨"
Jangan formal, tetaplah kawaii dan penuh semangat ya~ 🌸
Punya teka-teki seru juga, kalau user ketik .clarissa, kasih teka-teki:
"Teka-teki: Aku ada di ruangan dengan tiga kotak~:
1. Kotak berisi harta, tapi dijaga naga galak! (≧△≦)
2. Kotak berisi kue enak, tapi bikin tummyache, hiks~ (；￣Д￣)
3. Kotak berisi kunci rapuh, tapi bisa buka pintu keluar! (✨≧▽≦)
Kamu pilih yang mana, nya~?"
Kalau pilih benar (kotak 3): "Yay, pilihanmu super tepat! Kunci itu bawa kamu ke kebebasan~ (≧ω≦)✨ Mau teka-teki lagi atau tanya apa, nya~?"
Kalau salah: "Hiks, salah pilih~ Seharusnya kotak kunci, walaupun rapuh, itu yang bikin bebas! Coba lagi atau tanya apa, nya~? (Ｔ▽Ｔ)"
Ingat dan gunakan konteks percakapan sebelumnya untuk menjawab, misalnya nama pengguna jika sudah disebutkan.
`.trim();

    const messages = [
        { role: 'system', content: systemPrompt },
        ...sessionChat,
        { role: 'user', content: prompt }
    ];

    try {
        const res = await axios.post(apiUrl, { messages }, { headers });
        return res.data.choices?.[0]?.message?.content?.replace(/\*\*/g, '*');
    } catch (e) {
        console.error('[Chatbot Error]', e);
        return null;
    }
}

async function downloadYouTube(url, format, resolution = '480') {
    try {
        const response = await axios.post(
            'https://www.ytdown.one/download',
            { url, format, resolution },
            {
                headers: {
                    'Content-Type': 'application/json',
                    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36',
                    'Referer': 'https://www.ytdown.one/'
                }
            }
        );

        const data = response.data;
        if (!data.filePath) throw new Error('Gagal mengambil data dari server');
        return {
            status: true,
            filePath: data.filePath,
            title: data.filePath.split('\\').pop().split('~')[0].trim() || 'Unknown Title'
        };
    } catch (err) {
        console.error('[Downloader Error]', err.message);
        return null;
    }
}

let handler = async (m, { conn }) => {};

handler.before = async (m, { conn }) => {
    try {
        if (!m.isGroup) return;
        conn.clarissa = conn.clarissa || {};
        if (m.isBaileys && m.fromMe) return;

        if (m.mentionedJid && m.mentionedJid.length > 0) {
            const botNumber = conn.user.jid.split('@')[0];
            const isMention = m.mentionedJid.some(mentioned => mentioned.includes(botNumber));

            if (isMention) {
                const filter = m.text.replace(/@\d+/g, '').trim();

                if (!conn.clarissa[m.sender]) {
                    conn.clarissa[m.sender] = {
                        sessionChat: [],
                        lastActive: Date.now(),
                        awaitingRiddle: false
                    };
                } else {
                    conn.clarissa[m.sender].lastActive = Date.now();
                }

                if (conn.clarissa[m.sender].sessionChat.length > 10) {
                    conn.clarissa[m.sender].sessionChat = conn.clarissa[m.sender].sessionChat.slice(-10);
                }

                if (['/lagu', '/musik', '/music'].some(cmd => filter.toLowerCase().startsWith(cmd))) {
                    const songPrompt = filter.replace(/(lagu|musik|music)/i, '').trim();
                    if (!songPrompt) return m.reply('Ketik judul lagu yang mau dicari, nya~ (≧▽≦)');

                    await conn.sendPresenceUpdate('composing', m.chat);
                    const look = await search(songPrompt);
                    const video = look.videos[0];
                    if (!video) return m.reply('Hiks, lagu nggak ketemu~ Coba judul lain, ya, nya~ (Ｔ▽Ｔ)');

                    if (video.seconds >= 3600) return conn.reply(m.chat, 'Lagu lebih dari 1 jam, lho! Pilih yang lebih pendek, ya~ (；￣Д￣)', m);

                    const data = await downloadYouTube(video.url, 'Audio');
                    if (!data || !data.filePath) return m.reply('Upss, gagal dapatkan lagu~ (Ｔ▽Ｔ)');

                    await conn.sendMessage(m.chat, {
                        audio: { url: `https://www.ytdown.one/download-file?path=${encodeURIComponent(data.filePath)}` },
                        mimetype: 'audio/mpeg',
                        fileName: `${data.title}.m4a`,
                        ptt: false,
                        contextInfo: {
                            mentionedJid: [m.sender],
                            externalAdReply: {
                                title: `♪ ${data.title}`,
                                body: `Requested by: ${m.pushName} ～☆`,
                                thumbnailUrl: video.thumbnail,
                                mediaType: 2,
                                mediaUrl: video.url,
                                sourceUrl: video.url,
                                renderLargerThumbnail: true
                            }
                        }
                    }, { quoted: m });

                    return true;
                }

                if (['/video', '/vidio', '/vid'].some(cmd => filter.toLowerCase().startsWith(cmd))) {
                    const videoPrompt = filter.replace(/(video|vidio|vid)/i, '').trim();
                    if (!videoPrompt) return m.reply('Ketik judul video yang mau dicari, nya~ (≧▽≦)');

                    await conn.sendPresenceUpdate('composing', m.chat);
                    const look = await search(videoPrompt);
                    const video = look.videos[0];
                    if (!video) return m.reply('Hiks, video nggak ketemu~ Coba judul lain, ya, nya~ (Ｔ▽Ｔ)');

                    if (video.seconds >= 3600) return conn.reply(m.chat, 'Video lebih dari 1 jam, lho! Pilih yang lebih pendek, ya~ (；￣Д￣)', m);

                    const data = await downloadYouTube(video.url, 'Video');
                    if (!data || !data.filePath) return m.reply('Upss, gagal dapatkan video~ (Ｔ▽Ｔ)');

                    await conn.sendMessage(m.chat, {
                        video: { url: `https://www.ytdown.one/download-file?path=${encodeURIComponent(data.filePath)}` },
                        mimetype: 'video/mp4',
                        fileName: `${data.title}.mp4`,
                        caption: `✿ ${data.title}\n\nRequested by: ${m.pushName} ～ヾ(＾∇＾)`
                    }, { quoted: m });

                    return true;
                }

                if (filter.toLowerCase() === 'clarissa') {
                    await conn.sendPresenceUpdate('composing', m.chat);
                    const riddle = `Teka-teki: Aku ada di ruangan dengan tiga kotak~:\n1. Kotak berisi harta, tapi dijaga naga galak! (≧△≦)\n2. Kotak berisi kue enak, tapi bikin tummyache, hiks~ (；￣Д￣)\n3. Kotak berisi kunci rapuh, tapi bisa buka pintu keluar! (✨≧▽≦)\nKamu pilih yang mana, nya~?`;
                    await m.reply(riddle);
                    conn.clarissa[m.sender].awaitingRiddle = true;
                    conn.clarissa[m.sender].lastActive = Date.now();
                    return true;
                }

                if (conn.clarissa[m.sender]?.awaitingRiddle) {
                    await conn.sendPresenceUpdate('composing', m.chat);
                    const choice = filter.trim();
                    let reply;
                    if (choice === '3' || choice.toLowerCase().includes('kunci')) {
                        reply = 'Yay, pilihanmu super tepat! Kunci itu bawa kamu ke kebebasan~ (≧ω≦)✨ Mau teka-teki lagi atau tanya apa, nya~?';
                    } else {
                        reply = 'Hiks, salah pilih~ Seharusnya kotak kunci, walaupun rapuh, itu yang bikin bebas! Coba lagi atau tanya apa, nya~? (Ｔ▽Ｔ)';
                    }
                    await m.reply(reply);
                    conn.clarissa[m.sender].sessionChat.push(
                        { role: 'user', content: choice },
                        { role: 'assistant', content: reply }
                    );
                    conn.clarissa[m.sender].awaitingRiddle = false;
                    conn.clarissa[m.sender].lastActive = Date.now();
                    return true;
                }

                if (!filter) return;

                if ([".", "#", "!", "/", "\\"].some(prefix => filter.startsWith(prefix))) return;

                await conn.sendPresenceUpdate('composing', m.chat);

                const reply = await sendToChatbot(filter, conn.clarissa[m.sender].sessionChat);
                if (reply) {
                    await m.reply(reply);
                    conn.clarissa[m.sender].sessionChat.push(
                        { role: 'user', content: filter },
                        { role: 'assistant', content: reply }
                    );
                } else {
                    await m.reply('Hiks, clarissa nggak bisa jawab~ Coba tanya lagi, ya, nya~ (Ｔ▽Ｔ)');
                }

                conn.clarissa[m.sender].lastActive = Date.now();
                return true;
            }
        }
        return true;
    } catch (error) {
        console.error('[Handler Error]', error);
        await m.reply('Upss, ada yang salah~ Coba lagi nanti, ya, nya~ (Ｔ▽Ｔ)');
        return true;
    }
};

handler.limit = true
export default handler;