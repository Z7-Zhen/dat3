import axios from "axios";
import * as cheerio from "cheerio";

const jaxzynnice = async (m, { conn, args, command, usedPrefix }) => {
  if (!args[0])
    return m.reply(
      `🚫 Masukkan URL Instagram!\n\nContoh:\n${
        usedPrefix + command
      } https://www.instagram.com/reel/xxxxx`
    );

  const mollyGram = async (url) => {
    try {
      m.reply("Tunggu sebentar...");

      const { data } = await axios.get(
        `https://media.mollygram.com?url=${encodeURIComponent(url)}`,
        {
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
            Referer: "https://mollygram.com/"
          }
        }
      );

      const $ = cheerio.load(data.html);
      const userName = $("#user_info p.h4").text().trim();
      const nickName = $("#user_info p.text-muted").text().trim();
      const title = $("p.text-sm").text().trim();

      const likesText = $(".stats.text-sm:first-child small")
        .text()
        .trim();
      let likesCount = likesText.includes("K")
        ? parseFloat(likesText) * 1000
        : parseInt(likesText.replace(/\D/g, "")) || 0;

      const commentsText = $(".stats.text-sm:nth-child(2) small")
        .text()
        .trim();
      let commentsCount = commentsText.includes("K")
        ? parseFloat(commentsText) * 1000
        : parseInt(commentsText.replace(/\D/g, "")) || 0;

      const postedAt = $(".stats.text-sm:last-child small")
        .text()
        .trim();
      const videoUrl = $("video source").attr("src");
      const imageUrl = $("img.img-fluid").attr("src");

      return {
        userName,
        nickName,
        title,
        likesCount,
        commentsCount,
        postedAt,
        media: {
          videoUrl,
          imageUrl
        }
      };
    } catch (e) {
      console.error(e);
      throw "❌ Gagal mengambil data dari MollyGram.";
    }
  };

  try {
    let res = await mollyGram(args[0]);
    let caption = `✨ *Instagram Media Info* ✨\n\n`;
    caption += `👤 *Username:* ${res.userName}\n`;
    caption += `🆔 *Nickname:* ${res.nickName}\n`;
    caption += `📝 *Caption:* ${res.title || "Tidak ada"}\n`;
    caption += `❤️ *Likes:* ${res.likesCount.toLocaleString()}\n`;
    caption += `💬 *Comments:* ${res.commentsCount.toLocaleString()}\n`;
    caption += `📅 *Posted:* ${res.postedAt}\n`;

    if (res.media.videoUrl) {
      await conn.sendFile(
        m.chat,
        res.media.videoUrl,
        "igvideo.mp4",
        caption,
        m
      );
    } else if (res.media.imageUrl) {
      await conn.sendMessage(
        m.chat,
        { text: "🖼️ Mengirim gambar ke chat pribadi Anda..." },
        { quoted: m }
      );
      await conn.sendFile(
        m.sender,
        res.media.imageUrl,
        "igimage.jpg",
        caption,
        m
      );
    } else {
      m.reply("❌ Media tidak ditemukan atau tidak didukung.");
    }
  } catch (e) {
    m.reply(`❌ Terjadi kesalahan:\n${e}`);
  }
};

jaxzynnice.command = [
  "igdl",
  "instagram",
  "ig",
  "igstory",
  "instagramstory",
  "reels",
  "instavid",
  "insta"
];
jaxzynnice.tags = ["downloader"];
jaxzynnice.help = ["igdl <url>", "instagram <url>", "igstory <url>"];
jaxzynnice.limit = true;
jaxzynnice.register = true;

export default jaxzynnice;