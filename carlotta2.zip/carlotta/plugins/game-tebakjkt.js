import fetch from "node-fetch";

let timeout = 60000; // 60 detik
let exp = 4999;

const handler = async (m, { conn }) => {
  conn.tebakjkt = conn.tebakjkt || {};
  let id = m.chat;

  if (id in conn.tebakjkt) {
    conn.reply(m.chat, "❌ Masih ada soal yang belum terjawab di chat ini.", conn.tebakjkt[id][0]);
    throw false;
  }

  try {
    let res = await fetch("https://api-faa.my.id/faa/tebakjkt");
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    let json = await res.json();

    if (!json.result?.jawaban) throw new Error("Respon API tidak valid!");

    let jawaban = json.result.jawaban;
    let clue = jawaban[0] + "*".repeat(jawaban.length - 2) + jawaban.slice(-1);

    let caption = `
≡ *TEBAK JKT48*

📖 Tebak nama member JKT48!
💡 Clue: ${clue}
⏳ Timeout: ${(timeout / 1000).toFixed(0)} detik
🎁 Hadiah: +${exp} XP

Balas pesan ini dengan jawabanmu!
`.trim();

    conn.tebakjkt[id] = [
      await conn.sendMessage(m.chat, { text: caption }, { quoted: m }),
      jawaban,
      exp,
      setTimeout(() => {
        if (conn.tebakjkt[id]) {
          conn.reply(m.chat, `⏰ Waktu habis!\nJawaban yang benar adalah *${jawaban}*`, conn.tebakjkt[id][0]);
          delete conn.tebakjkt[id];
        }
      }, timeout)
    ];
  } catch (e) {
    m.reply(`❌ Terjadi kesalahan: ${e.message}`);
  }
};

// cek jawaban user
export async function before(m, { conn }) {
  conn.tebakjkt = conn.tebakjkt || {};
  let id = m.chat;
  if (!(id in conn.tebakjkt)) return !0;

  let [soalMsg, jawaban, exp] = conn.tebakjkt[id];
  let text = m.text.trim().toLowerCase();

  if (text === jawaban.toLowerCase()) {
    await conn.reply(m.chat, `*Benar!*\n+${exp} XP`, m);
    if (global.db?.data?.users) global.db.data.users[m.sender].exp += exp;
    clearTimeout(conn.tebakjkt[id][3]);
    delete conn.tebakjkt[id];
  }
  return !0;
}

handler.help = ["tebakjkt"];
handler.tags = ["game"];
handler.command = /^tebakjkt$/i;
handler.group = true;

export default handler;