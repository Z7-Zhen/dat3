import fs from 'fs';
import fetch from 'node-fetch';
import crypto from 'crypto';

const SESSION_FILE_PATH = './src/groksessions.json';
const SESSION_TIMEOUT = 60 * 60 * 1000;
const XAI_API_KEY = 'xai-naLD02iGX7T5EMXpISc1vkc3sCAiJQgvDaegEbwtHwPZEnWgbT2GXsqO9Lo9YuLHz729O0stlB2xUi08';

if (!fs.existsSync(SESSION_FILE_PATH)) {
  fs.writeFileSync(SESSION_FILE_PATH, JSON.stringify({}, null, 2));
}

let userSessions = {};
try {
  userSessions = JSON.parse(fs.readFileSync(SESSION_FILE_PATH, 'utf8'));
} catch {
  userSessions = {};
}

let userTimeouts = {};

async function grokAI(query, userId) {
  const id = crypto.randomBytes(16).toString('hex');
  const now = new Date();
  const offset = 7;
  const wibTime = new Date(now.getTime() + offset * 60 * 60 * 1000);
  const currentTime = wibTime.toISOString();

  if (!Array.isArray(userSessions[userId])) {
    userSessions[userId] = [];
  }

  if (userSessions[userId].length > 0) {
    const lastMessageTime = new Date(userSessions[userId].slice(-1)[0].waktu);
    if (Date.now() - lastMessageTime.getTime() > SESSION_TIMEOUT) {
      userSessions[userId] = [];
    }
  }

  const aiRole = `You are Grok, created by xAI. Provide concise, accurate, and helpful answers. Keep responses short and engaging, with a touch of humor when appropriate.`;

  if (userSessions[userId].length === 0) {
    userSessions[userId].push({
      role: "system",
      content: aiRole,
      waktu: currentTime
    });
  }

  userSessions[userId].push({
    role: "user",
    content: query,
    id: id,
    waktu: currentTime
  });

  try {
    const response = await fetch("https://api.x.ai/v1/chat/completions", {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${XAI_API_KEY}`
      },
      body: JSON.stringify({
        messages: userSessions[userId],
        model: "grok-3-latest",
        stream: false,
        temperature: 0
      }),
    });

    if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);

    const res = await response.json();
    let aiResponse = res.choices[0].message.content.trim();

    userSessions[userId].push({
      role: "assistant",
      content: aiResponse,
      waktu: currentTime
    });
    fs.writeFileSync(SESSION_FILE_PATH, JSON.stringify(userSessions, null, 2));
    if (userTimeouts[userId]) clearTimeout(userTimeouts[userId]);
    userTimeouts[userId] = setTimeout(() => {
      delete userSessions[userId];
      delete userTimeouts[userId];
      fs.writeFileSync(SESSION_FILE_PATH, JSON.stringify(userSessions, null, 2));
    }, SESSION_TIMEOUT);
    return aiResponse;
  } catch (error) {
    console.error(error);
    return 'Whoops! Something broke in the cosmos. Try again, human!';
  }
}

let grok = async (m, { conn, text, usedPrefix, command }) => {
  const userId = m.sender;

  if (command === 'grokclear') {
    if (!userSessions[userId] || userSessions[userId].length === 0) {
      return conn.sendMessage(m.chat, { text: 'No conversation to clear, human.' }, { quoted: m });
    }
    userSessions[userId] = [];
    fs.writeFileSync(SESSION_FILE_PATH, JSON.stringify(userSessions, null, 2));
    return conn.sendMessage(m.chat, { text: 'Conversation cleared. Fresh start, let’s go!' }, { quoted: m });
  }

  if (!text && !m.quoted) throw `Use format:\n${usedPrefix + command} <question>`;
  if (m.quoted) {
    text = m.quoted.text || m.quoted.caption || m.quoted.content;
  }

  conn.sendMessage(m.chat, { react: { text: '🚀', key: m.key } });

  let response = await grokAI(text, userId);
  await conn.sendMessage(m.chat, {
    text: response,
    contextInfo: {
      forwardingScore: 99999999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: '120363418731043391@newsletter',
        serverMessageId: null,
        newsletterName: `© ${global.namebot} || ${global.author}`
      }
    }
  }, { quoted: m });

  await conn.sendMessage(m.chat, { react: { text: null, key: m.key } });
};

grok.help = ['grok'];
grok.tags = ['ai'];
grok.command = /^(grok|grokclear)$/i;
grok.limit = 3;
grok.register = true;

export default grok;