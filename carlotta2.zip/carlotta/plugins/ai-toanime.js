import axios from 'axios'
import uploadImage from '../lib/uploadImage.js'

const handler = async (m, { conn, command }) => {
  const q = m.quoted ? m.quoted : m
  const mime = (q.msg || q).mimetype || ''

  if (!/image\/(jpe?g|png|webp)/.test(mime)) {
    return m.reply('❌ Kirim atau balas gambar dengan caption .toanime')
  }

  const buffer = await q.download()
  if (!buffer) return m.reply('❌ Gagal mengunduh gambar')

  await conn.sendMessage(m.chat, {
    react: {
      text: '🎨',
      key: m.key
    }
  })

  try {
    const imageUrl = await uploadImage(buffer)
    const { data } = await axios.get('https://api.botcahx.eu.org/api/maker/jadianime', {
      params: {
        apikey: global.btc,  
        url: imageUrl
      }
    })

    if (!data.status || !data.result?.img_2) {
      return m.reply('❌ Gagal mendapatkan hasil dari API')
    }

    await conn.sendMessage(m.chat, {
      image: { url: data.result.img_2 }, 
      caption: `🌸 *Berhasil mengubah ke gaya Anime!*\n\n🖼️ Gaya: *Anime Style*`
    }, { quoted: m })

  } catch (e) {
    console.error(e)
    m.reply('❌ Terjadi kesalahan saat menghubungi server')
  }
}

handler.command = /^toanime$/i
handler.tags = ['ai', 'tools']
handler.help = ['toanime']
handler.limit = true
handler.premium = true

export default handler