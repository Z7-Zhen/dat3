import { llama } from '../scraper/nuy-llama.js';

let handler = async(m, { conn, text, command, usedPrefix }) => {
  if (!text) return m.reply(`Apa yang kamu ingin tanyakan?\n*Contoh:* ${usedPrefix + command} halo aku ipah`)
  conn.sendMessage(m.chat, { react: { text: '🌺', key: m.key }})
  
  const { message } = await llama('Jawab dengan bahasa Indonesia: ' + text);
  if (message && message.split(' ').length > 0) {
  await conn.reply(m.chat, message, m)
  conn.sendMessage(m.chat, { react: { text: '🍄', key: m.key }})
  } else {
    m.reply('error kak, lapor owner')
  }
}
handler.tags = ['ai']
handler.help = ['llama <pertanyaan>']
handler.command = /^(llama)$/i
handler.register = true
handler.limit = true

export default handler