import db from '../lib/database.js'

let handler = async (m, { conn, participants }) => {
  // ambil semua user di grup
  let users = participants.map(p => p.id).filter(v => v !== conn.user.jid)
  if (users.length === 0) return m.reply("🌸 Grupnya sepi, gaada yg yapping~")

  // shuffle & ambil max 5
  let picked = users.sort(() => Math.random() - 0.5).slice(0, 5)

  // format mention aesthetic
  let teks = `🌸✨ *Top Yapping Awards* ✨🌸\n\n`
  teks += `꒰ 🌷 Yang suka bnyk ngoceh di sini ꒱\n\n`
  teks += picked.map((u, i) => `${i + 1}. @${u.split('@')[0]} ${randomEmoji()}`).join('\n')
  teks += `\n\n💭 Mereka tuh *raja & ratu yapping* hari ini ˚₊‧꒰ა ☆ ໒꒱ ‧₊˚`

  await conn.sendMessage(m.chat, { text: teks, mentions: picked }, { quoted: m })
}

// random emoji biar lebih imut
function randomEmoji() {
  let emojis = ["🌈", "🐾", "🌼", "🍓", "🧸", "💖", "🌸", "✨", "🍭", "🎀"]
  return emojis[Math.floor(Math.random() * emojis.length)]
}

handler.help = ['topyapping']
handler.tags = ['fun']
handler.command = /^topyapping$/i
handler.group = true

export default handler