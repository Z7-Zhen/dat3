import { areJidsSameUser } from '@adiwajshing/baileys'

function resolveJid(input, participants = []) {
    const found = participants.find(p =>
        areJidsSameUser(p?.id, input) ||
        areJidsSameUser(p?.lid, input) ||
        areJidsSameUser(p?.jid, input)
    )
    return found?.jid || input
}

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)]
}

let handler = async (m, { conn, text, participants }) => {
    if ((!text || !text.trim()) && (!m.mentionedJid || !m.mentionedJid.length)) {
        return conn.reply(m.chat, '📌 Contoh: .cekkontol nama / @user', m)
    }

    let name, mentions = []

    if (m.mentionedJid && m.mentionedJid.length) {
        const targetJid = resolveJid(m.mentionedJid[0], participants)
        name = '@' + targetJid.split('@')[0]
        mentions = [targetJid]
    } else {
        name = text.trim()
    }

    conn.reply(m.chat, `
╭━━━━°「 *Kontol ${name}* 」°
┃
┊• Nama : ${name}
┃• Kontol : ${pickRandom(['ih item','Belang wkwk','Muluss','Putih Mulus','Black Doff','Pink wow','Item Glossy'])}
┊• True : ${pickRandom(['perjaka','ga perjaka','udah pernah dimasukin','masih ori','jumbo'])}
┃• Jembut : ${pickRandom(['lebat','ada sedikit','gada jembut','tipis','muluss'])}
╰═┅═━––––––๑
`.trim(), m, { mentions })
}

handler.help = ['cekkontol *<text|@user>*']
handler.tags = ['fun']
handler.command = /^cekkontol$/i
handler.limit = true
handler.register = true

export default handler