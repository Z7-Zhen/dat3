import axios from "axios"
import FormData from "form-data"

let handler = async (m, { conn }) => {
  try {
    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || ''
    if (!mime.startsWith('image/')) return m.reply('Mana gambarnya')
    m.reply('Wait...')
    const buffer = await q.download()
    const form = new FormData()
    form.append("file", buffer, { filename: "image.jpg" })
    let { data } = await axios.post("https://be.neuralframes.com/clip_interrogate/", form, {
      headers: {
        ...form.getHeaders(),
        "Accept": "application/json, text/plain, */*",
        "Authorization": "Bearer uvcKfXuj6Ygncs6tiSJ6VXLxoapJdjQ3EEsSIt45Zm+vsl8qcLAAOrnnGWYBccx4sbEaQtCr416jxvc/zJNAlcDjLYjfHfHzPpfJ00l05h0oy7twPKzZrO4xSB+YGrmCyb/zOduHh1l9ogFPg/3aeSsz+wZYL9nlXfXdvCqDIP9bLcQMHiUKB0UCGuew2oRt",
        "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36",
        "Referer": "https://www.neuralframes.com/tools/image-to-prompt"
      }
    })
    await m.reply(data.prompt)
  } catch (e) {
    m.reply(e.message)
  }
}

handler.help = ['topromt']
handler.command = ['topromt']
handler.tags = ['ai']
handler.premium = true

export default handler