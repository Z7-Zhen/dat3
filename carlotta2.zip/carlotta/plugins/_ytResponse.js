import { ytMp3 } from '../scraper/SaaytMp3.js';
import { ytMp4 } from '../scraper/SaaytMp4V4.js';

let handler = async(m, { conn, text, usedPrefix, command }) => {
     conn.play = conn.play || {}
     let id = 'play_' + new Date() * 1
     let play = conn.play[m.sender]
   if (play) {
     
     let { title, thumbnail, timestamp, views, ago, url, author, sender, mes } = play;
     let { name } = author;

     if(command == 'mp3yt' && m.sender === sender) {
     await conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: true, id: mes.key.id, participant: mes.key.participant }})
     conn.sendMessage(m.chat, { react: { text: '🎸', key: m.key }})
     let cap = `⬣─ 〔 *Y T  A U D I O* 〕 ─⬣
* *- Title:* ${title}
* *- Views:* ${formatNumber(views)}
* *- Duration:* ${timestamp}
* *- Upload:* ${ago}
* *- Author Url:* ${author.url}
⬣────────────────⬣`;
     let res = await (await ytMp3(url))
     let { mp3 } = res.data
     
     let doc = {
        audio: { url: mp3 },
        mimetype: 'audio/mp4',
        fileName: `${title}`
      };
      conn.sendMessage(m.chat, { text: cap, contextInfo: { mentiondJid: [sender], externalAdReply: { mediaUrl: '', mediaType: 1, title: title, body: '© Owen Skyler', thumbnailUrl: thumbnail, sourceUrl: url, renderLargerThumbnail: true, showAdAttribution: false } } }, { quoted: flok });
      await conn.sendMessage(m.chat, doc, { quoted: flok });
    } else if (command == 'mp4yt' && m.sender === sender) {
    await conn.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: true, id: mes.key.id, participant: mes.key.participant }})
    conn.sendMessage(m.chat, { react: { text: '🎥', key: m.key }})
    let cap = `⬣─ 〔 *Y T  V I D E O* 〕 ─⬣
* *- Title:* ${title}
* *- Views:* ${formatNumber(views)}
* *- Duration:* ${timestamp}
* *- Upload:* ${ago}
* *- Author Url:* ${author.url}
⬣────────────────⬣`;
     let res = await ytMp4(url)
     let { mp4 } = res.data
    await conn.sendFile(m.chat, mp4, '', cap, m, 0, {
      mimetype: "video/mp4",
      fileName: `zell.mp4`
         });
      }
     delete conn.play[m.sender]
   }
}

handler.command = /^(mp3yt|mp4yt)$/i

handler.limit = true
export default handler


function formatNumber(num) {
  const suffixes = ['', 'Rb', 'Jt', 'T', 'Kl'];
  const numString = Math.abs(num).toString();
  const numDigits = numString.length;

  if (numDigits <= 3) {
    return numString;
  }

  const suffixIndex = Math.floor((numDigits - 1) / 3);
  let formattedNum = (num / Math.pow(1000, suffixIndex)).toFixed(1);
  
  if (formattedNum.endsWith('.0')) {
    formattedNum = formattedNum.slice(0, -2);
  }

  return formattedNum + suffixes[suffixIndex];
}