let handler = async (m, { conn, participants }) => {
  let users = participants.map(p => p.id).filter(v => v !== conn.user.jid)
  if (users.length < 5) return m.reply("🙀 Grupnya ga cukup orang buat Top 5 Tolol~")

  let picked = users.sort(() => Math.random() - 0.5).slice(0, 5)

  let teks = `🧠💩 *TOP 5 PALING TOLOL* 💩🧠\n\n`
  teks += `👑 1. @${picked[0].split('@')[0]} — ${pickJoke()}\n`
  teks += `🥈 2. @${picked[1].split('@')[0]} — ${pickJoke()}\n`
  teks += `🥉 3. @${picked[2].split('@')[0]} — ${pickJoke()}\n`
  teks += `4. @${picked[3].split('@')[0]} — ${pickJoke()}\n`
  teks += `5. @${picked[4].split('@')[0]} — ${pickJoke()}\n`

  teks += `\n😹✦ sabar beb, ini cuma roasting gemes ✦😹\n`
  teks += `*tolol tapi tetep uwu kok ˚₊‧꒰ა 🐰໒꒱ ‧₊˚*`

  await conn.sendMessage(m.chat, { text: teks, mentions: picked }, { quoted: m })
}

function pickJoke() {
  let jokes = [
    "IQ-nya minus, kalkulator aja error 😭",
    "Tololnya legend, bikin Google nyerah 🔍",
    "Main UNO kalah sama bot 🃏",
    "Kalo otak dijual, harga second pun ga laku 🛒",
    "Ngomong kayak NPC error di GTA 🤖",
    "Pinter acting tolol, atau emang tolol beneran? 🐒",
    "Nyalain lampu aja salah tombol 💡",
    "Brain AFK 24/7 💤",
    "Salah mulu tapi pede, combo tolol 😹",
    "Kalo ada olimpiade tolol, auto dapet emas 🏅"
  ]
  return jokes[Math.floor(Math.random() * jokes.length)]
}

handler.help = ['toptolol']
handler.tags = ['fun']
handler.command = /^toptolol$/i
handler.group = true

export default handler