import fetch from 'node-fetch'

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(
      `Masukkan URL CapCut\nContoh:\n${usedPrefix + command} https://www.capcut.com/tv2/ZSDxrduSN/`
    )
  }

  try {
    await conn.reply(m.chat, 'Tunggu sebentar, sedang memproses...', m)

    const api = `https://api.deline.web.id/downloader/capcut?url=${encodeURIComponent(text)}`
    const res = await fetch(api)
    if (!res.ok) throw new Error(`HTTP ${res.status}`)
    const json = await res.json()

    if (!json.status || !json.result?.video) throw new Error('Video tidak ditemukan')

    const { title, author, thumbnail, video } = json.result

    await conn.sendMessage(
      m.chat,
      {
        video: { url: video },
        caption: `🎬 *CapCut Downloader*\n\n📌 *Judul:* ${title || '-'}\n👤 *Author:* ${author || '-'}\n🔗 Source: CapCut`,
        jpegThumbnail: thumbnail ? await (await fetch(thumbnail)).buffer() : null
      },
      { quoted: m }
    )
  } catch (err) {
    console.error(err)
    m.reply('Terjadi kesalahan saat mengunduh video CapCut.')
  }
}

handler.help = ['capcut <url>']
handler.tags = ['downloader']
handler.command = /^capcut$/i
handler.register = true
handler.limit = true

export default handler