import { fbDown } from '../scraper/nuy-fbDown.js';

let handler = async(m, { text, conn, usedPrefix, command }) => {
  if (!text) return m.reply(`Urlnya mana?\n*Contoh:* ${usedPrefix + command} https://facebook.com/xxxxx`)
  conn.sendMessage(m.chat, {
          react: {
              text: "🚀",
              key: m.key
             }
         })
  let response = await fbDown(text)
  let { vid_HD, durasi } = response
  
  if (vid_HD && durasi) {
     await conn.sendFile(m.chat, vid_HD.links, '', `\`Sukses Download Facebook Video ✓\`\n*Resolusi:* \`720 (HD)\`\n*Durasi:* \`${durasi}\``, m)
      conn.sendMessage(m.chat, {
          react: {
              text: "✅",
              key: m.key
             }
         })
      } else {
       m.reply(eror)
       conn.sendMessage(m.chat, {
          react: {
              text: "❌",
              key: m.key
             }
         })
     }
}
handler.tags = ['downloader','premium']
handler.help = ['fbhd','facebookhd']
handler.command = /^(fbhd|facebookhd|fbdlhd)$/i
handler.premium = true

export default handler