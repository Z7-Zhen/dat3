let handler = m => m;

handler.before = async function (m, { conn, isBotAdmin, isAdmin }) {
  if ((m.isBaileys && m.fromMe) || m.fromMe || !m.isGroup || isAdmin) return true;

  let chatId = m.chat;
  let groupData = global.db.data.chats[chatId];

  if (!groupData.antiTagStatus || m.mtype !== 'groupStatusMentionMessage') return false;

  let sender = m.sender;
  let tag = '@' + sender.split`@`[0];

  if (!groupData.users) groupData.users = {};

  // Langsung kick saat terdeteksi mention status
  await m.reply(`*「 ANTI TAG STATUS 」*\n\nDetected *${tag}* mention status di grup!\nKarena aturan ini aktif, kamu langsung dikeluarkan dari grup!`);

  if (isBotAdmin) {
    await conn.sendMessage(m.chat, { delete: m.key }).catch(() => {});
    await conn.groupParticipantsUpdate(m.chat, [sender], 'remove');
  }

  return true;
};

handler.group = true;
handler.botAdmin = true;

handler.limit = true
export default handler;