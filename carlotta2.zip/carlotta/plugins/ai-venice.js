// venice.js
import fetch from "node-fetch"

let handler = async (m, { text }) => {
  if (!text) throw `⚠️ Gunakan perintah:\n.venice <pertanyaan / prompt>`

  try {
    let res = await fetch(`https://api.nekolabs.my.id/ai/venice?text=${encodeURIComponent(text)}`)
    let raw = await res.text()

    let reply
    try {
      let json = JSON.parse(raw)
      reply =
        json.result?.text ||
        json.result ||
        json.data?.text ||
        json.answer ||
        null
    } catch {
      reply = raw // fallback kalau bukan JSON
    }

    if (!reply || reply.includes('<html')) throw '❌ API tidak balikin jawaban valid'

    await m.reply(reply)
  } catch (e) {
    console.error('Error venice:', e)
    m.reply('❌ Gagal ambil jawaban, coba lagi nanti.')
  }
}

handler.help = ['venice <teks>']
handler.tags = ['ai']
handler.command = /^venice$/i
handler.limit = true
handler.register = true

export default handler