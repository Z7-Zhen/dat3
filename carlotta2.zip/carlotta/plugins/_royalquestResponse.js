const { proto, generateWAMessageFromContent } = (await import('@adiwajshing/baileys')).default;

let handler = async (m, { conn, command, text }) => {
    conn.royal = conn.royal || {};
    conn.quest = conn.quest || {};
    let royal = conn.royal[m.chat];
    let quest = conn.quest[m.chat];
    let user = global.db.data.users[m.sender];

    if (royal) {
        if (m.sender !== royal.peran) return;
        switch (command) {
            case 'hutan':
            case 'kastil':
            case 'gurun':
            case 'teluk':
            case 'vulkan':
            case 'astral':
            case 'lembah':
            case 'gua':
            case 'kuil':
            case 'kota':
                if (!user.skill) return m.reply(`⚔️: Kamu belum mempunyai skill! silahkan .pilihskill terlebih dahulu`);
                let id = Math.floor(Math.random() * 10000000);
                let tuju = '';
                switch (command) {
                    case 'hutan': tuju = 'Hutan Gelap'; break;
                    case 'kastil': tuju = 'Kastil Terkutuk'; break;
                    case 'gurun': tuju = 'Gurun Elenium'; break;
                    case 'teluk': tuju = 'Teluk Abyss'; break;
                    case 'vulkan': tuju = 'Pegunungan Vulkan'; break;
                    case 'astral': tuju = 'Menara Astral'; break;
                    case 'lembah': tuju = 'Lembah Mistik'; break;
                    case 'gua': tuju = 'Gua Arakhnid'; break;
                    case 'kuil': tuju = 'Kuil Terlupakan'; break;
                    case 'kota': tuju = 'Kota Mekanis'; break;
                }

                let tujuan = `⚔️: Berhasil membuat room!\n*📌 Room ID:* ${id}\n*⚔️ Quest:* ${tuju}\n\n🕐 Menunggu petualang lain bergabung!`;
                let msg = generateWAMessageFromContent(m.chat, {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                body: proto.Message.InteractiveMessage.Body.create({
                                    text: tujuan,
                                }),
                                footer: proto.Message.InteractiveMessage.Footer.create({
                                    text: "*© Owen Skyler*"
                                }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    title: "\t⬣─〔 *⚔️ Royal Quest* 〕─⬣\n",
                                    subtitle: "",
                                    hasMediaAttachment: false
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons: [
                                        {
                                            name: "quick_reply",
                                            buttonParamsJson: "{\"display_text\":\"🛡️ Bergabung\",\"id\":\"royal_gabung\"}"
                                        },
                                        {
                                            name: "quick_reply",
                                            buttonParamsJson: "{\"display_text\":\"🛡️ Solo\",\"id\":\"royal_sendirian_aja\"}"
                                        },
                                        {
                                            name: "quick_reply",
                                            buttonParamsJson: "{\"display_text\":\"🚫 Batalkan\",\"id\":\"royal_batallken\"}"
                                        },
                                    ],
                                })
                            })
                        },
                    }
                }, {});
                await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
                conn.quest[m.chat] = {
                    master: royal.peran,
                    players: [m.sender],
                    id: id,
                    tujuan: tuju,
                    status: 'waiting',
                    del: delete conn.royal[m.chat]
                };
                break;
        }
    }
}

handler.command = /^(hutan|kastil|gurun|teluk|vulkan|astral|lembah|gua|kuil|kota)$/i;
handler.limit = true
export default handler;