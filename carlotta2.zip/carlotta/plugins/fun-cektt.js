import { areJidsSameUser } from '@adiwajshing/baileys'

function resolveJid(input, participants = []) {
    const found = participants.find(p =>
        areJidsSameUser(p?.id, input) ||
        areJidsSameUser(p?.lid, input) ||
        areJidsSameUser(p?.jid, input)
    )
    return found?.jid || input
}

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)]
}

let handler = async (m, { conn, text, participants }) => {
    if ((!text || !text.trim()) && (!m.mentionedJid || !m.mentionedJid.length)) {
        return conn.reply(m.chat, '📌 Contoh: .cektt nama / @user', m)
    }

    let name, mentions = []

    if (m.mentionedJid && m.mentionedJid.length) {
        const targetJid = resolveJid(m.mentionedJid[0], participants)
        name = '@' + targetJid.split('@')[0]
        mentions = [targetJid]
    } else {
        name = text.trim()
    }

    conn.reply(m.chat, `
╭━━━━°「 *TT ${name}* 」°
┃
┊• Nama : ${name}
┃• TT : ${pickRandom(['Putih','Hitam','Putih mulus','Hitam banget','Karatan ☠️'])}
┊• Pentil : ${pickRandom(['Hitam','Pink','Kecil','Perfect'])}
┃• Ukuran : ${pickRandom(['Tepos','Spek Nasi KFC','Tobrut','32','34','36'])}
╰═┅═━––––––๑
`.trim(), m, { mentions })
}

handler.help = ['cektt *<text|@user>*']
handler.tags = ['fun']
handler.command = /^cektt$/i
handler.limit = true
handler.register = true

export default handler