let handler = async (m, { conn, participants }) => {
  let users = participants.map(p => p.id).filter(v => v !== conn.user.jid)
  if (users.length < 10) return m.reply("🙀 Grupnya ga cukup orang buat Top 10 Jelek~")

  let picked = users.sort(() => Math.random() - 0.5).slice(0, 10)

  let teks = `💔👹 *TOP 10 JELEK BANGET ANJ* 👹💔\n\n`
  teks += `👑 1. @${picked[0].split('@')[0]} — Jeleknya permanen, skincare aja langsung uninstall 😭\n`
  teks += `🥈 2. @${picked[1].split('@')[0]} — Mukanya kaya draft foto yang ga jadi dipost 🗑️\n`
  teks += `🥉 3. @${picked[2].split('@')[0]} — Jelek limited edition, sayang ga bisa di-refund 🐵\n`

  let jokes = [
    "Astaga… jeleknya aesthetic kaya filter failed 🦆",
    "Bikin hp nge-lag tiap difoto 📸",
    "Kalo jadi emoji, pasti “🗿” biar netral 🐷",
    "Mukanya kaya bug Roblox 🐔",
    "Jelek tapi sok pamer, kombinasi toxic 🦖",
    "Mukanya kaya watermark ilegal “Made With VivaVideo” 🐙",
    "Editor CapCut aja ga bisa nolong 🦑",
  ]

  for (let i = 3; i < picked.length; i++) {
    teks += `${i+1}. @${picked[i].split('@')[0]} — ${jokes[i-3]}\n`
  }

  teks += `\n🌸✦ calm down beb, ini roasting + gemes ✦🌸\n`
  teks += `*jelek = unik, unik = limited, limited = mahal 🐰💎 uwu*`

  await conn.sendMessage(m.chat, { text: teks, mentions: picked }, { quoted: m })
}

handler.help = ['topjelek']
handler.tags = ['fun']
handler.command = /^topjelek$/i
handler.group = true
handler.register = true

export default handler