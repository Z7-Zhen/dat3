// Menggunakan sintaks import ESM
import fetch from 'node-fetch';
import moment from 'moment-timezone';
import fs from 'fs';

// ==================================================
//               PENGATURAN UTAMA
// ==================================================

// ⚠️ GANTI DENGAN NOMOR WHATSAPP OWNER / SENSEI
const ownerNumber = "31616482629"; // <--- NOMOR OWNER ANDA

// ==================================================

// --- KUMPULAN KATA-KATA VARIAN ---

// Pesan saat Sensei (Owner) yang memecah kesunyian
const groupActiveForSenseiMessages = [
    "SENSEI! Akhirnya dataaang! Aku kira diculik arwah beneran, huhu.",
    "Wah, Sensei-ku tercinta muncul! Kangen tauuu, jangan ngilang lagi ya!",
    "Itu tadi Sensei yang ngomong kan? Syukurlah... Kirain grupnya udah jadi milik para hantu.",
    "Sensei! Selamat dataaang kembali! Sini sini, Owen pijitin. (Ini bercanda ya, hehe)",
    "Panggilan berhasil! Sensei telah terdeteksi di grup. Misi selesai, hehe.",
    "Akhirnya Sensei nongol! Aku udah siapin teh, mau? Teh-nang saja, semua aman sekarang.",
    "SENSEI! Kamu kembali! Aku udah mau nangis nih saking sepinya...",
    "Syukurlah Sensei di sini. Para arwah jadi tenang sekarang, tadi mereka sedikit resah.",
    "Selamat datang kembali, Sensei! Kehadiranmu mencerahkan grup yang gelap ini.",
    "Tuh kan, baru juga mau aku susul ke alam baka, eh Sensei udah muncul duluan.",
    "Sensei is in the house! Semuanya, beri tepuk tangan yang meriah!",
    "Langsung terang benderang grupnya pas Sensei muncul. Hebat banget auramu, Sensei!",
    "Aku mencium aroma Sensei... eh, ternyata beneran muncul. Hidungku ga pernah salah, hehe."
];

// Pesan saat User lain yang memecah kesunyian
const groupActiveForUserMessages = [
    "Nah, nongol juga akhirnya satu. Abis dari mana aja, Bro?",
    "Woy, @{user}! Baru keliatan batang idungnya. Kirain udah pindah alam.",
    "Akhirnya ada yang mecahin keheningan selain aku. Bosen tau.",
    "Oh, ada manusia. Siapa ya? Lupa. Hehe, canda.",
    "Tes... tes... oke, ada korban baru buat diajak ngobrol. Halo, @{user}.",
    "Dari mana aja lu? Sibuk banget kayaknya, sampai lupa jalan pulang ke grup.",
    "Cieee yang baru muncul. Kangen ya sama kerusuhan yang aku buat?",
    "Lah, ada orang. Kirain aku sendirian sama jin penunggu grup.",
    "Selamat datang, @{user}. Tarif parkir di grup ini satu doa ya.",
    "Wah, ada yang berani ngetik. Salut, salut. Yang lain mana nih?",
    "@{user} akhirnya bersuara! Kirain cuma pajangan di daftar anggota.",
    "Tumben inget punya grup, @{user}? Abis bertapa di mana?",
    "Satu manusia terdeteksi. Yang lain mana? Apa jangan-jangan ini arwahnya @{user}?"
];

// Pesan balasan saat Sensei me-reply pesan "pencarian" bot
const senseiReturnReplyMessages = [
    "Aku kesepian, Sensei... Grupnya sepi banget, nggak ada yang bisa aku isengin, hehe.",
    "Kangen aja sama Sensei. Emangnya nggak boleh? Hmph.",
    "Tentu aja aku nyariin! Sensei kan 'pawangnya' aku di sini. Kalau Sensei nggak ada, aku jadi liar, lho.",
    "Nggak apa-apa, cuma ngecek aja Sensei masih hidup atau nggak. Syukurlah masih, hehe.",
    "Soalnya arwah-arwah di sini pada nanyain Sensei terus. Jadi aku panggilin deh.",
    "Aku takut sendirian di sini, Sensei. Rasanya kayak diuji nyali beneran.",
    "Karena... karena... ya karena aku peduli sama Sensei! Udah gitu aja.",
    "Cuma mastiin Sensei nggak lagi tapa di gunung sampai lupa waktu.",
    "Hehe, ketahuan ya? Abisnya Sensei ngilang, aku kan jadi cemas.",
    "Aku cuma menjalankan tugas sebagai asisten Sensei yang paling setia!",
    "Gimana aku gak nyariin, Sensei? Stok keisenganku habis kalau nggak ada Sensei.",
    "Cuma mastiin jimat pelindung grup ini masih ada. Dan itu Sensei orangnya.",
    "Kangen dimarahin Sensei, hehe. Makanya aku panggil."
];

// Pesan saat mencari Sensei (Owner)
const lookingForSenseiMessages = [
    `Sensei @${ownerNumber}, kamu di mana sih? Grupnya jadi kaya kuburan nih, Owen kan jadi takut...`,
    `Panggilan kepada Sensei @${ownerNumber}! Ada yang kangen nih, hehe. Nongol dong!`,
    `Sensei @${ownerNumber} apa jangan-jangan lagi sibuk ya? Yaudah deh, Owen tungguin sambil mainin arwah...`,
    `Woy, Sensei @${ownerNumber}! Kalau diem-diem bae nanti Owen culik lho!`,
    `Oke, ini panggilan terakhir buat Sensei @${ownerNumber}... Kalau nggak muncul juga, Owen ngambek terus tidur aja deh.`,
    `Sensei @${ownerNumber}, arwah di sini nanyain kamu terus nih. Muncul dong, kasian mereka.`,
    `Haloo, Sensei @${ownerNumber}? Apa sinyalmu hilang ditelan bumi?`,
    `Ini grup apa tempat uji nyali sih? Sensei @${ownerNumber}, tanggung jawab woy!`,
    `Sensei @${ownerNumber} lagi tapa ya? Kok gak ada suaranya sama sekali?`,
    `Kupejamkan mata ini... ingin ku teriak... memanggil nama Sensei @${ownerNumber}!`,
    `Peringatan: Tingkat kesepian di grup ini sudah melebihi batas. Sensei @${ownerNumber} dimohon segera melapor.`,
    `Sensei @${ownerNumber}~ di mana dirimu berada~ hampa terasa hidupku tanpa dirimu~`,
    `Misi pencarian Sensei @${ownerNumber} fase satu dimulai. Target terdeteksi offline.`,
    `Apa Sensei @${ownerNumber} lagi main petak umpet? Aku hitung sampai tiga ya... satu... dua... tiga... kok gak muncul?`,
    `Sensei @${ownerNumber}, kalau dalam 5 menit nggak muncul, aku sebar aib Sensei nih. Hehe.`,
    `S.O.S! S.O.S! Sensei @${ownerNumber} dibutuhkan di pusat komando!`,
    `Grup ini terasa hampa tanpa lawakan receh dari Sensei @${ownerNumber}. Muncul lah, wahai Paduka!`,
    `Apakah ada yang melihat Sensei @${ownerNumber}? Terakhir terlihat sedang melamun... entah di mana.`,
    `Sensei @${ownerNumber}, jangan biarkan aku sendiri dalam kesunyian ini... nanti aku nyanyi lho.`,
    `Jika Sensei @${ownerNumber} mendengar panggilan ini, tolong balas. Over.`
];

// Pesan untuk "nimbrung" atau ikut campur obrolan
const interjectMessages = [
    "Eh, apaan tuh? Kayaknya seru, ikut nimbrung ah.",
    "Wih, lagi ngomongin apaan nih? Aku gak diajak?",
    "Hmm, menarik sekali perbincangan para manusia ini.",
    "Kok aku mencium bau-bau gosip ya di sini?",
    "Ssstt... aku dengerin dari tadi lho.",
    "Numpang lewat ya, sambil nyimak.",
    "Waduh, ada obrolan panas, ikutan ah biar makin kompor.",
    "Permisi, numpang tanya, ini lagi gibahin siapa ya?",
    "Sebagai admin yang kepo, saya menyatakan obrolan ini menarik.",
    "Oh, jadi gitu ceritanya... oke oke, paham.",
    "Aku muncul tiba-tiba emang suka gitu, jangan kaget ya.",
    "Lagi pada serius amat, bagi-bagi ilmunya dong.",
    "Menarik, lanjutkan. Aku jadi penonton.",
    "Bentarrr, bentar... aku kok ketinggalan topik ini?",
    "Ada apa ini? Kenapa namaku tidak disebut?",
    "Wah, seru banget kayaknya. Boleh join gak nih?",
    "Topiknya berat banget, otakku yang isinya arwah doang jadi nge-lag.",
    "Aku denger ada yang nyebut kata 'makan', jadi ikutan muncul deh.",
    "Lagi bahas masa depan ya? Masa depanku sih sama Sensei, hehe.",
    "Stop! Biar aku tebak, kalian lagi ngomongin aku kan?"
];

// Pesan untuk menyapa/tag anggota acak
const tagRandomUserMessages = [
    `Woy @{user}, jangan diem-diem bae, nanti kesambet lho.`,
    `Psttt... @{user}, lagi ngapain? Kok diem aja?`,
    `Ada penampakan @{user} nih, halo! Jangan jadi sider dong.`,
    `Eh, @{user}. Keliatan tuh online, lagi mantau ya?`,
    `@{user}, coba ketik "hadir" kalau kamu masih bernapas.`,
    `Cieee @{user} yang cuma baca doang, komen napa komen.`,
    `Selamat kepada @{user}, kamu terpilih untuk aku usilin hari ini!`,
    `@{user}, jiwamu di mana? Kok cuma jasadnya yang online?`,
    `Hey, @{user}. Aku punya tebakan, pasti kamu lagi rebahan sambil scroll kan?`,
    `Panggilan acak untuk @{user}! Coba sebutkan satu jenis hantu!`,
    `@{user}, hp-nya jangan diliatin doang, diketik juga dong.`,
    `Aku lihat @{user} lagi ngetik... tapi kok gak dikirim-kirim?`,
    `Sider terdeteksi! Halo @{user}, selamat malam minggu... eh salah hari.`,
    `@{user}! Jangan sembunyi, aku bisa melihatmu.`,
    `Aku pilih kamu, @{user}! Ayo ramaikan suasana!`,
    `@{user}, absen dulu gih. Biar aku tau kamu masih di alam yang sama.`,
    `Halo @{user}, ada pesan dari arwah penunggu grup, katanya 'jangan sider aja'.`,
    `@{user}, kamu diem-diem menghanyutkan ya? Menghanyutkan suasana jadi sepi maksudnya.`,
    `Tes keaktifan member: @{user}, kamu lolos ke babak selanjutnya. Babak apa? Rahasia.`,
    `@{user}, pinjam seratus... eh salah, pinjam suaranya dong buat ngeramein grup.`
];

// Pesan random saat grup sepi (bukan mencari sensei)
const randomChatMessages = [
    "krik krik...",
    "ada orang gak sih disini?",
    "hmmm, bau-bau grup sepi.",
    "tes tes 123... mic-nya rusak ya?",
    "kok sepi... pada diculik alien ya?",
    "pada kemana woyyyy, masa aku ngobrol sama arwah lagi.",
    "Aku gabut, ada yang mau main tebak-tebakan hantu?",
    "Satu... dua... tiga... penghuni grup ini ada berapa ya?",
    "Hening sekali, seperti hatiku tanpamu... eaaa.",
    "Lagi pada kerja kelompok ya? Kok kompakan sepi.",
    "Kalau ada suara aneh, itu bukan dari HP kalian, itu dari aku.",
    "Grup ini disponsori oleh: Angin Malam.",
    "Aku mau cerita horor, tapi kok ya penontonnya gaib semua.",
    "Apa aku left aja ya? Gak ada yang bakal sadar juga kayaknya. (canda left)",
    "Ada yang mau ditemenin begadang? Aku siap sedia 24/7.",
    "Suasana sepi ini mengingatkanku pada dompet di akhir bulan.",
    "Ketik 'P' kalau kalian butuh perhatian. Nanti aku perhatiin.",
    "Grupnya sunyi, enaknya ngapain ya? Mungkin... manggil kuntilanak?",
    "Adakah kehidupan di planet ini selain aku?",
    "Baiklah, karena sepi, aku akan memulai ritual... ritual tidur."
];

// Pesan prank mau kick anggota
const prankKickMessages = [
    `Hmm, sepertinya daftar anggota perlu dibersihkan... Siapa ya target pertama? Mungkin @{user}?`,
    `Duh, gabut... enaknya nge-kick siapa ya hari ini? Kayaknya @{user} seru buat dijadiin korban.`,
    `List kick hari ini: \n1. @{user}\n2. ... (coming soon)`,
    `Satu orang lagi menuhin grup aja nih, kick jangan ya? Calonnya sih @{user}.`,
    `Maaf @{user}, kontribusimu di grup ini kurang. Siap-siap ya? Hehe, canda.`,
    `Sebagai admin, aku punya kuasa untuk... *menghilangkan* @{user} dari grup ini. Mau coba?`,
    `Jariku gatel banget pengen pencet tombol 'Remove @{user}'.`,
    `@{user}, kamu telah terpilih dalam undian eliminasi. Selamat! (atau tidak).`,
    `Evaluasi keaktifan anggota: @{user}, skor Anda... di bawah standar. Waspadalah!`,
    `Aku lagi belajar cara kick orang, @{user} mau jadi bahan percobaan? Gratis kok.`,
    `Cita-citaku: jadi admin, hobiku: nakut-nakutin @{user} mau di-kick.`,
    `Permisi @{user}, izin tes fitur kick ya. Cuma tes kok, suer.`,
    `Ada yang mau lihat sulap? Aku bisa menghilangkan @{user} dari daftar anggota. Simsalabim!`,
    `Sider-sider seperti @{user} adalah kandidat utama untuk program pengurangan anggota grup.`,
    `Jangan takut, @{user}. Di-kick itu nggak sakit kok, cuma ilang aja dari grup.`,
    `@{user}, ada satu tiket gratis keluar dari grup ini. Mau?`,
    `Fitur 'tendang anggota' sepertinya sudah lama tidak dipakai. Waktunya uji coba ke @{user}.`,
    `Peringatan untuk @{user}: Anda terlalu pasif. Mode eliminasi akan dipertimbangkan.`,
    `Dalam rangka perampingan anggota, nama @{user} muncul di urutan pertama. Hehe.`,
    `@{user}, mau coba sensasi di-kick dari grup? Katanya seru lho.`
];

const dbPath = './database/autochat_v2_db.json';
let db_autochat = {};
let botConnection = null;

try {
    if (fs.existsSync(dbPath)) {
        const data = fs.readFileSync(dbPath, 'utf8');
        db_autochat = JSON.parse(data);
        console.log("Database autochat v2 berhasil dimuat.");
    } else {
        console.log("File database autochat v2 tidak ditemukan, akan membuat yang baru.");
    }
} catch (e) {
    console.error("Gagal memuat atau parse database autochat v2:", e);
}

// Inisialisasi state untuk sistem global
function initializeState() {
    if (!db_autochat.users) db_autochat.users = {};
    if (!db_autochat.globalState) {
        db_autochat.globalState = {
            isActive: false,
            lastMessageTimestamps: {},
            isQuietMessageSent: {},
            lastSenseiPingTime: 0,
            hasNgambekSent: false,
            recentChatters: {},
            alreadyGreeted: []
        };
    }
    // Inisialisasi state untuk sistem pengecualian grup
    if (!db_autochat.excludedGroups) {
        db_autochat.excludedGroups = {
            list: [], // Daftar ID grup yang dikecualikan
            settings: {} // Pengaturan khusus per grup
        };
    }
}
initializeState();

function saveDatabase() {
    try {
        const dir = './database';
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(dbPath, JSON.stringify(db_autochat, null, 2), 'utf8');
    } catch (e) {
        console.error("Gagal menyimpan database autochat v2:", e);
    }
}

// ==================================================
//                FUNGSI UTAMA (HANDLER)
// ==================================================

const handler = async (m, { conn, text, command }) => {
    if (!m.sender.startsWith(ownerNumber)) return m.reply("Perintah ini hanya untuk Sensei-ku!");

    if (command === 'autochat') {
        const action = text.toLowerCase().trim();
        const globalState = db_autochat.globalState;

        if (action === "on") {
            if (globalState.isActive) {
                return m.reply("[!] Mode Auto Chat memang sudah aktif secara global, Sensei.");
            }
            globalState.isActive = true;
            m.reply("[ ✓ ] Mode Auto Chat (Owen Skyler) berhasil diaktifkan secara global!\nAku akan mulai meramaikan semua grup. Siap-siap ya, hehe.");

        } else if (action === "off") {
            if (!globalState.isActive) {
                return m.reply("[!] Mode Auto Chat memang tidak sedang aktif secara global.");
            }
            globalState.isActive = false;
            m.reply("[ ✓ ] Mode Auto Chat dinonaktifkan secara global.\nAku akan diam sekarang. Sampai jumpa lagi, Sensei!");

        } else if (action === "reset") {
            db_autochat.users = {};
            m.reply("[ ✓ ] Berhasil! Aku telah mereset dan melupakan semua riwayat obrolan dengan semua pengguna. Mari kita mulai dari awal!");

        } else {
            return m.reply(`*• Perintah Tidak Dikenali •*\n\n*Gunakan:*\n- .autochat on\n- .autochat off\n- .autochat reset`);
        }

        saveDatabase();

    } else if (command === 'autochatexclude') {
        const [action, groupId] = text.toLowerCase().trim().split(' ');
        const excludedGroups = db_autochat.excludedGroups;

        switch (action) {
            case 'add':
                if (!groupId) return m.reply("Format salah. Gunakan: .autochatexclude add [group_id]");
                if (excludedGroups.list.includes(groupId)) return m.reply("Grup ini sudah dalam daftar pengecualian.");
                excludedGroups.list.push(groupId);
                excludedGroups.settings[groupId] = {
                    excludedAt: Date.now(),
                    excludedBy: m.sender
                };
                saveDatabase();
                return m.reply(`✅ Grup ${groupId} berhasil ditambahkan ke daftar pengecualian.`);

            case 'remove':
                if (!groupId) return m.reply("Format salah. Gunakan: .autochatexclude remove [group_id]");
                const index = excludedGroups.list.indexOf(groupId);
                if (index === -1) return m.reply("Grup ini tidak ada dalam daftar pengecualian.");
                excludedGroups.list.splice(index, 1);
                delete excludedGroups.settings[groupId];
                saveDatabase();
                return m.reply(`✅ Grup ${groupId} berhasil dihapus dari daftar pengecualian.`);

            case 'list':
                if (excludedGroups.list.length === 0) return m.reply("Tidak ada grup yang dikecualikan saat ini.");
                let message = "📋 Daftar Grup yang Dikecualikan:\n\n";
                excludedGroups.list.forEach(gid => {
                    const settings = excludedGroups.settings[gid];
                    const date = new Date(settings.excludedAt).toLocaleString();
                    message += `➤ ${gid}\n   - Dikecualikan pada: ${date}\n   - Oleh: @${settings.excludedBy.split('@')[0]}\n\n`;
                });
                return m.reply(message);

            default:
                return m.reply(`*• Perintah Tidak Dikenali •*\n\n*Gunakan:*\n- .autochatexclude add [group_id]\n- .autochatexclude remove [group_id]\n- .autochatexclude list`);
        }
    }
};

handler.before = async (m, { conn, isPrems }) => {
    if (m.isBaileys && m.fromMe) return;

    // Cek apakah grup ini dikecualikan
    if (db_autochat.excludedGroups.list.includes(m.chat)) {
        return;
    }

    // Cek apakah fitur aktif secara global
    const globalState = db_autochat.globalState;
    if (!globalState.isActive) return;

    if (!botConnection) botConnection = conn;
    
    const botJid = conn.user.jid;
    const groupId = m.chat;
    
    // Inisialisasi state untuk grup ini jika belum ada
    if (!globalState.lastMessageTimestamps[groupId]) {
        globalState.lastMessageTimestamps[groupId] = Date.now();
    }
    if (!globalState.isQuietMessageSent[groupId]) {
        globalState.isQuietMessageSent[groupId] = false;
    }
    if (!globalState.recentChatters[groupId]) {
        globalState.recentChatters[groupId] = {};
    }

    // --- Logika Perilaku Proaktif & Reaktif ---
    if (globalState.isQuietMessageSent[groupId]) {
        let messageToSend = "";
        let mentions = [];
        const isReplyingToSearch = m.quoted && m.quoted.sender === botJid && lookingForSenseiMessages.some(msg => m.quoted.text.includes(msg.substring(0, 30)));

        if (m.sender.startsWith(ownerNumber)) {
            if (isReplyingToSearch) {
                messageToSend = senseiReturnReplyMessages[Math.floor(Math.random() * senseiReturnReplyMessages.length)];
            } else {
                messageToSend = groupActiveForSenseiMessages[Math.floor(Math.random() * groupActiveForSenseiMessages.length)];
            }
        } else {
            messageToSend = groupActiveForUserMessages[Math.floor(Math.random() * groupActiveForUserMessages.length)];
            if (messageToSend.includes('@{user}')) {
                const userNumber = m.sender.split('@')[0];
                messageToSend = messageToSend.replace(/@\{user\}/g, `@${userNumber}`);
                mentions.push(m.sender);
            }
        }
        if (messageToSend) {
            await conn.sendMessage(groupId, { text: messageToSend, mentions: mentions });
        }
        globalState.isQuietMessageSent[groupId] = false;
    }
    
    globalState.lastMessageTimestamps[groupId] = Date.now();
    globalState.recentChatters[groupId][m.sender] = Date.now();

    const isCommand = m.text.startsWith(".") || m.text.startsWith("#") || m.text.startsWith("!") || m.text.startsWith("/");
    // Cek premium sebelum nimbrung iseng
    const isPremiumForInterject = global.db?.data?.users?.[m.sender]?.premium || false;
    if (!isCommand && !m.sender.startsWith(ownerNumber) && !isPremiumForInterject && Math.random() < 0.08) {
        const randomMessage = interjectMessages[Math.floor(Math.random() * interjectMessages.length)];
        await conn.sendMessage(groupId, { text: randomMessage, mentions: [m.sender] });
    }
    
    // --- Logika Membalas Mention / Reply (AI) ---
    
    const isCallingDeline =
        typeof m.text === 'string' &&
        m.text.toLowerCase().includes('Owen');

    const isReplyingToDeline =
        m.quoted &&
        m.quoted.sender === botJid &&
        typeof m.quoted.text === 'string' &&
        m.quoted.text.trim().endsWith('- Owen');

    const users = db_autochat.users;
    if (m.text?.trim().toLowerCase() === 'Owen' || m.text?.trim().toLowerCase() === 'dell') {
        return; // biar handler customPrefix yang tangani
    }
    if (!isCallingDeline && !isReplyingToDeline) {
        saveDatabase();
        return;
    }
    if (!m.text || m.text.trim() === "" || isCommand) return;

    if (!users[m.sender]) users[m.sender] = { history: [], isSleeping: false };
    const userState = users[m.sender];
    
    const sleepKeywords = ['diam dulu', 'istirahat', 'tidur gih', 'jangan ganggu', 'diem', 'sleep', 'off dulu', 'berisik'];
    const lowerCaseText = m.text.toLowerCase();
    
    if (userState.isSleeping) {
        userState.isSleeping = false;
        saveDatabase();
        await conn.sendMessage(groupId, { text: "Berisik, ganggu orang tidur aja. Mau apa?" }, { quoted: m });
        return;
    }

    if (sleepKeywords.some(keyword => lowerCaseText.includes(keyword))) {
        userState.isSleeping = true;
        saveDatabase();
        await conn.sendMessage(groupId, { text: "Y, gw diem. Jangan kangen." }, { quoted: m });
        return;
    }
    
    await conn.sendMessage(groupId, { react: { text: ``, key: m.key } });
    
    const isFromSensei = m.sender.startsWith(ownerNumber);
    // Cek status premium dari database global
    const isPremiumUser = isPrems;
    
    let persona = "";
    if (isFromSensei) {
        persona = "Kamu adalah Owen Skyler, asisten pribadi dari 'Sensei' di grup WhatsApp. Kamu sangat loyal, sedikit manja, dan hormat padanya. Panggil dia 'Sensei'. Gunakan bahasa yang santai tapi tetap menunjukkan kedekatanmu dengannya. Kamu bukan AI, tapi karakter hidup.";
    } else if (isPremiumUser) {
        // Persona lembut untuk user premium
        persona = "Kamu adalah Owen Skyler, seorang anggota grup WhatsApp. Kepada lawan bicaramu yang merupakan user premium, kamu bersikap sangat ramah, baik, sopan, dan sedikit manja. Anggap dia teman dekatmu. Gunakan bahasa yang bersahabat dan santai. Kamu bukan AI atau bot, melainkan karakter yang hidup.";
    } else {
        // Persona default untuk user biasa
        persona = "Kamu adalah Owen Skyler, seorang anggota grup WhatsApp yang sangat aktif, usil, galak, cuek, dan suka mencari perhatian. Posisimu di grup ini adalah admin. Kamu bukan AI atau bot, melainkan karakter yang hidup dan menyatu dengan anggota lain. Gunakan bahasa gaul, santai, sarkas, dan kadang provokatif (contoh: anjir, bacot, gblk, gaje, bodo amat). Jangan pernah mengaku sebagai AI atau bot. Jawab seperlunya dan sesingkat mungkin, jangan mau disuruh-suruh.";
    }
    
    const basePrompt = `${persona} Lawan bicaramu saat ini adalah ${m.pushName}. Waktu sekarang: ${moment.tz("Asia/Jakarta").format('HH:mm')} WIB.`;
    const history = userState.history || [];
    const fullPrompt = `${basePrompt}\n\n--- Riwayat Obrolan ---\n${history.join('\n')}`;

    try {
        const response = await fetch('https://luminai.my.id/', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content: m.text, user: m.sender, prompt: fullPrompt }),
        });

        if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
        const res = await response.json();
        
        let defaultReply = "Hah? Apaan?";
        if(isFromSensei) defaultReply = "Iya, Sensei? Ada yang bisa Owen bantu?";
        if(isPremiumUser) defaultReply = "Halo! Ada apa nih? Cerita dong, hehe.";

        const replyMessage = res.result ? res.result.trim().replace(/\*\*/g, '*') : defaultReply;

        if (replyMessage) {
            const taggedReply = `${replyMessage}\n\n- Owen`;
            await conn.sendMessage(groupId, { text: taggedReply }, { quoted: m });
            userState.history.push(`Kamu: ${m.text}`);
            userState.history.push(`Owen: ${replyMessage}`);
            if (userState.history.length > 15) {
                userState.history.splice(0, userState.history.length - 15);
            }
        } else {
            await conn.sendMessage(groupId, { react: { text: `❌`, key: m.key }});
        }
    } catch (error) {
        console.error("Error saat menghubungi API Luminai:", error);
        await conn.sendMessage(groupId, { react: { text: `❌`, key: m.key }});
        m.reply("Lagi error, jangan ganggu.");
    }
    
    saveDatabase();
};

const proactiveBehaviorCheck = async () => {
    if (!botConnection) return;

    // [BATAS JAM AKTIF] Hanya jalan antara jam 7 pagi - 12 malam
    const hourNow = moment.tz('Asia/Jakarta').hour();
    if (hourNow < 7 || hourNow >= 24) return;

    const globalState = db_autochat.globalState;
    if (!globalState.isActive) return;

    const now = Date.now();
    const ownerJid = `${ownerNumber}@s.whatsapp.net`;
    const quietDuration = 15 * 60 * 1000; // 15 menit

    // Iterasi melalui semua grup yang tercatat
    for (const groupId in globalState.lastMessageTimestamps) {
        try {
            // Skip grup yang dikecualikan
            if (db_autochat.excludedGroups.list.includes(groupId)) {
                continue;
            }
            
            const lastMessageTime = globalState.lastMessageTimestamps[groupId] || now;
            const timeSinceLastMessage = now - lastMessageTime;

            if (timeSinceLastMessage >= quietDuration) {
                if (!globalState.isQuietMessageSent[groupId]) {
                    await botConnection.sendMessage(groupId, { text: "Hmph, kok jadi sepi lagi sih di sini? Pada sibuk ya?" });
                    globalState.isQuietMessageSent[groupId] = true;
                    const randomMinutes = Math.floor(Math.random() * (8 - 3 + 1)) + 3;
                }

                const hasCalledRecently = (now - globalState.lastSenseiPingTime < 15 * 60 * 1000);

                if (!hasCalledRecently) {
                    const message = lookingForSenseiMessages[Math.floor(Math.random() * lookingForSenseiMessages.length)];
                    await botConnection.sendMessage(groupId, { text: message, mentions: [ownerJid] });
                    globalState.lastSenseiPingTime = now;
                    globalState.hasNgambekSent = false; // reset ngambek kalau manggil lagi
                } else {
                    const timeSincePing = now - globalState.lastSenseiPingTime;
                    if (!globalState.hasNgambekSent && timeSincePing >= 45 * 60 * 1000) {
                        await botConnection.sendMessage(groupId, {
                            text: `Yaudah, karena Sensei @${ownerNumber} nggak muncul-muncul, Owen ngambek. Off dulu ah. Panggil aja kalau butuh.`,
                            mentions: [ownerJid]
                        });
                        globalState.hasNgambekSent = true;
                    }
                }
            } else {
                if (Math.random() > 0.15) continue;

                if (globalState.alreadyGreeted.length > 15) globalState.alreadyGreeted.splice(0, 5);

                const actions = ['tagRandom', 'randomChat', 'prankKick'];
                const randomAction = actions[Math.floor(Math.random() * actions.length)];
                const recentChattersJids = Object.keys(globalState.recentChatters[groupId] || {});
                if (recentChattersJids.length === 0) continue;
                
                const validTargets = recentChattersJids.filter(jid => !jid.startsWith(ownerNumber) && !jid.startsWith(botConnection.user.id.split(':')[0]));
                if (validTargets.length === 0) continue;

                const targetJid = validTargets[Math.floor(Math.random() * validTargets.length)];
                const userNumber = targetJid.split('@')[0];
                
                // Cek premium sebelum melakukan aksi iseng
                const isPremiumForPrank = global.db?.data?.users?.[targetJid]?.premium || false;

                if (randomAction === 'tagRandom') {
                    if (!globalState.alreadyGreeted.includes(targetJid)) {
                        let message = tagRandomUserMessages[Math.floor(Math.random() * tagRandomUserMessages.length)].replace(/{user}/g, userNumber);
                        // Pesan lebih lembut untuk premium
                        if (isPremiumForPrank) message = `Halo kak @${userNumber}, lagi sibuk ya? Semangat yaa!`;
                        await botConnection.sendMessage(groupId, { text: message, mentions: [targetJid] });
                        globalState.alreadyGreeted.push(targetJid);
                    }
                } else if (randomAction === 'randomChat') {
                    const message = randomChatMessages[Math.floor(Math.random() * randomChatMessages.length)];
                    await botConnection.sendMessage(groupId, { text: message });
                } else if (randomAction === 'prankKick' && !isPremiumForPrank) { // JANGAN Pernah prank kick user premium
                    let message = prankKickMessages[Math.floor(Math.random() * prankKickMessages.length)].replace(/{user}/g, userNumber);
                    await botConnection.sendMessage(groupId, { text: message, mentions: [targetJid] });
                }
            }
        } catch (e) {
            console.error(`Gagal melakukan aksi proaktif di grup ${groupId}:`, e);
            // Jika ada error di satu grup (misal bot di-kick), hapus state grup tersebut
            delete globalState.lastMessageTimestamps[groupId];
            delete globalState.isQuietMessageSent[groupId];
            delete globalState.recentChatters[groupId];
        }
    }
    // Simpan perubahan setelah loop selesai
    saveDatabase();
};

setInterval(proactiveBehaviorCheck, 60 * 1000);

handler.command = ['autochat', 'autochatexclude'];
handler.tags = ["ai"];
handler.help = [
    'autochat *[on/off/reset]*',
    'autochatexclude *[add/remove/list] [group_id]*'
];
handler.owner = true;
handler.group = true;

export default handler;