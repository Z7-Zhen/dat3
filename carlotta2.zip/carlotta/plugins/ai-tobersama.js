import axios from "axios"
import FormData from "form-data"

const tobersamaStore = {}

const handler = async (m, { conn, command, usedPrefix }) => {
  const chatId = m.chat

  const cleanUp = (chatId) => {
    if (tobersamaStore[chatId]) {
      clearTimeout(tobersamaStore[chatId].timeout)
      delete tobersamaStore[chatId]
    }
  }

  const uploadToUguu = async (buffer) => {
    const form = new FormData()
    form.append("files[]", buffer, { filename: "file.png" })
    const { data } = await axios.post("https://uguu.se/upload.php", form, {
      headers: form.getHeaders(),
      timeout: 60000,
    })
    if (!data?.files?.[0]?.url) throw new Error("Upload gagal")
    return data.files[0].url
  }

  // Ambil gambar (langsung / reply)
  const getImageBuffer = async () => {
    if (m.message?.imageMessage) {
      return await m.download()
    } else if (m.quoted?.message?.imageMessage) {
      return await m.quoted.download()
    } else if (m.mimetype && /image\/(jpe?g|png|webp)/i.test(m.mimetype)) {
      return await m.download()
    } else if (m.quoted && /image\/(jpe?g|png|webp)/i.test(m.quoted.mimetype)) {
      return await m.quoted.download()
    }
    return null
  }

  // === Jika menunggu foto kedua ===
  if (tobersamaStore[chatId]?.buffer1) {
    const buffer2 = await getImageBuffer()
    if (!buffer2) return m.reply("❌ Kirim foto kedua (reply atau baru) agar digabung.")

    await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })
    await m.reply("⏳ Foto kedua diterima. Sedang menggabungkan...")

    try {
      const buffer1 = tobersamaStore[chatId].buffer1
      const url1 = await uploadToUguu(buffer1)
      const url2 = await uploadToUguu(buffer2)

      const response = await axios.get(
        `https://api-faa.my.id/faa/tobersamav2?url1=${encodeURIComponent(url1)}&url2=${encodeURIComponent(url2)}`,
        {
          responseType: "arraybuffer",
          timeout: 120000,
        }
      )

      const resultBuffer = Buffer.from(response.data)
      await conn.sendMessage(chatId, { image: resultBuffer, caption: "✨ Foto berhasil digabung!" }, { quoted: m })
      cleanUp(chatId)
      await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
    } catch (err) {
      console.error("❌ Gagal Tobersama:", err)
      m.reply("❌ Gagal menggabungkan foto.\n\nError: " + (err?.message || "Tidak diketahui"))
      cleanUp(chatId)
      await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
    }
    return
  }

  // === Foto pertama ===
  const buffer1 = await getImageBuffer()
  if (!buffer1) {
    return m.reply(`❌ Kirim atau balas *gambar* dengan caption *${usedPrefix + command}*`)
  }

  tobersamaStore[chatId] = { buffer1 }

  await conn.sendMessage(
    chatId,
    {
      image: buffer1,
      caption: "📸 Foto pertama diterima!\nKirim foto kedua (reply atau baru) dalam 5 menit agar digabung 💞",
      thumbnail: buffer1,
    },
    { quoted: m }
  )

  tobersamaStore[chatId].timeout = setTimeout(() => cleanUp(chatId), 5 * 60 * 1000)
}

handler.help = ["tobersama"]
handler.tags = ["ai", "premium", "tools"]
handler.command = ["tobersama"]
handler.premium = true

export default handler