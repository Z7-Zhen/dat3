// plugins/deepfake.js
import ws from 'ws'
import { downloadContentFromMessage } from '@adiwajshing/baileys'

async function downloadMedia(message) {
  const type = (message?.mimetype || '').split('/')[0]
  const stream = await downloadContentFromMessage(message, type)
  const buffer = []
  for await (const chunk of stream) buffer.push(chunk)
  return Buffer.concat(buffer)
}

async function deepfake(buffer, prompt = 'best quality, nude') {
  if (!buffer || !Buffer.isBuffer(buffer)) throw new Error('Gambar tidak valid')

  const session_hash = Math.random().toString(36).substring(2)
  const socket = new ws('wss://deepfakemaker.io/cloth-change/queue/join')

  return new Promise((resolve, reject) => {
    socket.on('message', (data) => {
      const d = JSON.parse(data.toString('utf8'))

      if (d.msg === 'send_hash') {
        socket.send(JSON.stringify({ session_hash }))
      } else if (d.msg === 'send_data') {
        socket.send(JSON.stringify({
          data: {
            prompt,
            request_from: 4,
            source_image: `data:image/jpeg;base64,${buffer.toString('base64')}`,
            type: 1
          }
        }))
      } else if (d.msg === 'process_completed') {
        socket.close()
        return resolve(`https://res.deepfakemaker.io/${d.output.result[0]}`)
      }
    })

    socket.on('error', (err) => reject(err))
    socket.on('close', () => reject(new Error('Socket closed sebelum proses selesai')))
  })
}

let handler = async (m, { conn }) => {
  const quoted = m.quoted || m
  const mime = quoted?.mimetype || ''

  if (!mime.startsWith('image/')) return m.reply('📸 Balas gambar orang yang ingin diubah pakai .mantapkan')

  await m.reply('⏳ Memproses... Harap tunggu ya...')

  try {
    const buffer = await downloadMedia(quoted)
    const resultUrl = await deepfake(buffer, 'best quality, nude')

    await conn.sendMessage(m.chat, {
      image: { url: resultUrl },
      caption: '✅ *Sukses!* Hasil mantap sudah jadi.'
    }, { quoted: m })

  } catch (err) {
    console.error(err)
    m.reply(`❌ Terjadi kesalahan:\n${err.message}`)
  }
}

handler.help = ['mantapkan']
handler.tags = ['ai']
handler.command = ['mantapkan']
handler.limit = true
handler.premium = true

export default handler