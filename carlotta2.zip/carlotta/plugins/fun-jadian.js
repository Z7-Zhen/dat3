let toM = a => '@' + a.split('@')[0]

function handler(m, { groupMetadata }) {
    const ps = groupMetadata.participants.map(v => v.id)
    const ownerId = '31616482629@s.whatsapp.net'
    const pasanganOwner = '6283891967187@s.whatsapp.net'

    let a, b

    if (m.sender === ownerId) {
        // Owner jadian dengan pasanganOwner
        a = ownerId
        b = pasanganOwner
    } else if (m.sender === pasanganOwner) {
        // PasanganOwner jadian dengan owner
        a = pasanganOwner
        b = ownerId
    } else {
        // Random jadian antar member
        a = ps.getRandom()
        do b = ps.getRandom()
        while (b === a)
    }

    m.reply(`${toM(a)} ❤️ ${toM(b)}`, null, {
        mentions: [a, b]
    })
}

handler.help = ['jadian']
handler.tags = ['main', 'fun']
handler.command = ['jadian']
handler.group = true

handler.limit = true
export default handler