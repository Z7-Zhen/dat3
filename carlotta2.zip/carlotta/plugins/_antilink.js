const linkRegex = /chat.whatsapp.com\/(?:invite\/)?([0-9A-Za-z]{20,24})/i;
const WaLinkRegex = /wa.me\/([0-9])/i;

export async function before(m, { isAdmin, isBotAdmin }) {
    if (m.isBaileys && m.fromMe) return;

    let chat = global.db.data.chats[m.chat] || {};
    let users = chat.users = chat.users || {};
    let sender = m.sender;

    if (!users[sender]) users[sender] = { warn: 0 };

    if (chat.antiLink && m.isGroup) {
        let isGroupLink = linkRegex.exec(m.text);
        if (isGroupLink && !isAdmin) {
            const linkThisGroup = `https://chat.whatsapp.com/${await this.groupInviteCode(m.chat)}`;
            
            if (m.text.includes(linkThisGroup)) return true;

            users[sender].warn += 1;

            m.reply(
                `*「 ANTI LINK GRUP 」*\n\nTerdeteksi *link grup* dari *${sender.split('@')[0]}*\n` +
                `Warn Kamu: *${users[sender].warn}/3*\n\n` +
                `> Jangan kirim link grup sembarangan ya!`
            );

            if (isBotAdmin) await this.sendMessage(m.chat, { delete: m.key });

            if (users[sender].warn >= 3 && isBotAdmin) {
                await m.reply(`*「 ANTI LINK GRUP 」*\n\n*${sender.split('@')[0]}* sudah 3x kirim link grup. Selamat tinggal!`);
                await this.groupParticipantsUpdate(m.chat, [sender], 'remove');
                users[sender].warn = 0;
            }

            return true;
        }
    }

    if (chat.antiLinkWa && m.isGroup) {
        let isLinkWa = WaLinkRegex.exec(m.text);
        if (isLinkWa && !isAdmin) {
            users[sender].warn += 1;

            m.reply(
                `*「 ANTI LINK WA 」*\n\nTerdeteksi *tautan wa.me* dari *${sender.split('@')[0]}*\n` +
                `Warn Kamu: *${users[sender].warn}/3*\n\n` +
                `> Jangan kirim tautan pribadi wa.me ya!`
            );

            if (isBotAdmin) await this.sendMessage(m.chat, { delete: m.key });

            if (users[sender].warn >= 3 && isBotAdmin) {
                await m.reply(`*「 ANTI LINK WA 」*\n\n*${sender.split('@')[0]}* sudah 3x kirim link WA. Bye-bye!`);
                await this.groupParticipantsUpdate(m.chat, [sender], 'remove');
                users[sender].warn = 0;
            }

            return true;
        }
    }

    return;
}