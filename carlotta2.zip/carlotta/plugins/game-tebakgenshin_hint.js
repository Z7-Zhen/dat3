let handler = async (m, { conn }) => {
    conn.tebakgenshin = conn.tebakgenshin || {}
    let id = m.chat
    if (!(id in conn.tebakgenshin)) throw false
    let json = conn.tebakgenshin[id][1]
    m.reply(
        '```' + json.jawaban.replace(/[bcdfghjklmnpqrstvwxyz]/gi, '_') + '```\n*BALAS SOALNYA, BUKAN PESAN INI!*',
        null,
        { quoted: conn.tebakgenshin[id][0] }
    )
}
handler.command = /^gca$/i

export default handler
