const winScore = 20000
import fetch from 'node-fetch'

async function handler(m, { conn }) {
  this.game = this.game || {}
  const id = 'family100_' + m.chat

  if (id in this.game) {
    this.reply(m.chat, '❗ Masih ada kuis yang belum terjawab di chat ini', this.game[id].msg)
    throw false
  }

  try {
    const res = await fetch('https://api.deline.web.id/game/family100')
    if (!res.ok) throw `API error: ${res.status} ${res.statusText}`
    const json = await res.json()

    const soal = json?.result?.soal
    const jawabanArr = json?.result?.jawaban
    if (!soal || !Array.isArray(jawabanArr)) throw 'Struktur API tidak sesuai'

    const jawaban = jawabanArr.map(v => String(v).toLowerCase())

    const caption = `
*📄 Soal:* ${soal}
📍 Terdapat *${jawaban.length}* jawaban${jawaban.find(v => v.includes(' ')) ? `
(beberapa jawaban terdapat spasi)
` : ''}

💥 +${winScore} Money tiap jawaban benar
    `.trim()

    this.game[id] = {
      id,
      msg: await conn.reply(m.chat, caption, m),
      soal,
      jawaban,
      terjawab: Array.from(jawaban, () => false),
      winScore,
      owner: m.sender
    }

  } catch (e) {
    console.error('[family100]', e)
    m.reply('❌ Gagal memulai kuis Family100. Silakan coba lagi nanti.')
  }
}

handler.help = ['family100']
handler.tags = ['game']
handler.command = /^family100$/i
handler.group = true
handler.register = true

export default handler