const { proto, generateWAMessageFromContent } = (await import('@adiwajshing/baileys')).default;

let handler = async (m, { conn, command }) => {
    let ruang = conn.mabar_sekiro[m.chat];
    conn.sekiro = conn.sekiro || {};
    let room = conn.sekiro[m.chat];

    if (ruang && ruang.state === 'pilihserver' && m.sender === ruang.master) {
        let user = global.db.data.users[m.sender];
        let enemies = {
            ashina: ['Ashina Soldier', 'Bandit', 'Wolf', 'Taro Trooper', 'Nightjar Ninja'],
            hirata: ['Shinobi Hunter', 'Juzou the Drunkard', 'Bandit Archer', 'Lone Shadow', 'Mist Noble'],
            senpou: ['Senpou Monk', 'Infested Monk', 'Centipede Assassin', 'Rat', 'Temple Guardian'],
            castle: ['Ashina Elite', 'Lone Shadow Vilehand', 'Nightjar Veteran', 'Red Guard', 'Chained Ogre'],
            fountainhead: ['Okami Warrior', 'Headless', 'Shichimen Warrior', 'Corrupted Monk', 'Divine Dragon']
        };

        const paths = {
            ashina: { 
                level: 10, 
                health: 100, 
                stamina: 100, 
                sword: 3, 
                sworddura: 50, 
                pathName: 'Ashina Outskirts', 
                swordName: 'Steel Sword' 
            },
            hirata: { 
                level: 30, 
                health: 150, 
                stamina: 100, 
                sword: 8, 
                sworddura: 100, 
                pathName: 'Hirata Estate', 
                swordName: 'Dwarven Sword' 
            },
            senpou: { 
                level: 50, 
                health: 200, 
                stamina: 120, 
                sword: 10, 
                sworddura: 150, 
                pathName: 'Senpou Temple', 
                swordName: 'Long Sword' 
            },
            castle: { 
                level: 100, 
                health: 1000, 
                stamina: 150, 
                sword: 15, 
                sworddura: 200, 
                pathName: 'Ashina Castle', 
                swordName: 'Thunder Blade' 
            },
            fountainhead: { 
                level: 200, 
                health: 1500, 
                stamina: 200, 
                sword: 30, 
                sworddura: 250, 
                pathName: 'Fountainhead Palace', 
                swordName: 'Ancient Blade' 
            }
        };

        let pathData = paths[command];
        if (!pathData) return m.reply('Jalur tidak valid!');

        if (user.level < pathData.level) return m.reply(`Kamu membutuhkan *Level ${pathData.level}* untuk bertarung di *${pathData.pathName}*!`);
        if (user.health < pathData.health) return m.reply(`Health kamu kurang dari *${pathData.health} ❤️*!`);
        if (user.stamina < pathData.stamina) return m.reply(`Stamina kamu kurang dari *${pathData.stamina} ⚡*!`);
        if (user.sword < pathData.sword) return m.reply(`Kamu membutuhkan *${pathData.swordName}* untuk bertarung di *${pathData.pathName}*!`);
        if (user.sworddurability < pathData.sworddura) return m.reply(`Durability sword kamu kurang dari *${pathData.sworddura} 🗡️*!`);

        conn.sekiro[m.chat] = {
            id: Math.floor(Math.random() * 100000000).toString(),
            p: m.sender,
            players: [m.sender],
            nameserver: command,
            healtserver: pathData.health,
            staminaserver: pathData.stamina,
            swordserver: pathData.sword,
            sworddura: pathData.sworddura,
            swordName: pathData.swordName,
            cdserver: 1800000,
            enemy: pickRandom(enemies[command]),
            hapus: delete conn.mabar_sekiro[m.chat],
            status: 'wait'
        };

        room = conn.sekiro[m.chat];
        let playerList = room.players.map((player, index) => `*${index + 1}.* @${player.replace(/@.+/, '')}`).join('\n');
        let buatRoom = `⚔️ Berhasil membuat room\n*Room ID:* ${room.id}\n*Path:* ${pathData.pathName}\n\n♻️ Menunggu shinobi lain untuk join`;
        let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: buatRoom,
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            text: "*© Owen Skyler*"
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            title: "\t🏯 *SEKIRO ROOM* 🏯\n",
                            subtitle: "",
                            hasMediaAttachment: false
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: "{\"display_text\":\"♻️ Join\",\"id\":\"sekiro_join\"}"
                                },
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: "{\"display_text\":\"👤 Solo\",\"id\":\"sekiro_solo\"}"
                                },
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: "{\"display_text\":\"🚫 Batalkan\",\"id\":\"sekiro_batall\"}"
                                },
                            ],
                        })
                    })
                },
            }
        }, {});
        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    }
};

handler.command = /^(ashina|hirata|senpou|castle|fountainhead)$/i;
handler.group = true;

export default handler;

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)];
}