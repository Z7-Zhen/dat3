let handler = async (m, { conn }) => {
  conn.susun = conn.susun ? conn.susun : {}
  let id = m.chat
  if (!(id in conn.susun)) throw false

  let json = conn.susun[id][1]
  let ans = json.jawaban.toLowerCase() // bikin lowercase semua
  let clue = ans.replace(/[aiueo]/g, '_') // ganti huruf hidup jadi _

  m.reply('```' + clue + '```')
}

handler.command = /^susn/i
handler.limit = true

export default handler