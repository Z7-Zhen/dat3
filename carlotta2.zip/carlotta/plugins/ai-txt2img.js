/*
- Name : Text To Image
- Deskripsi : Generate gambar dari teks (Text-to-Image) via texttoimage.org
- Source Referensi : https://whatsapp.com/channel/0029Vaio4dYC1FuGr5kxfy2l/1475
- Follow Channel : https://whatsapp.com/channel/0029Vb6D8o67YSd1UzflqU1d
*/

import axios from 'axios'
import cheerio from 'cheerio'

async function txttoimage(prompt) {
  const datapost = `prompt=${encodeURIComponent(prompt)}`
  const headers = {
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'Accept': 'application/json, text/javascript, */*; q=0.01',
    'X-Requested-With': 'XMLHttpRequest',
    'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Mobile Safari/537.36',
    'Referer': 'https://www.texttoimage.org/'
  }

  const res = await axios.post('https://www.texttoimage.org/generate', datapost, { headers })
  const pageurl = `https://www.texttoimage.org/${res.data.url}`
  const $ = cheerio.load((await axios.get(pageurl)).data)
  const imgsrc = $('a[data-lightbox="image-set"] img').attr('src')

  return `https://www.texttoimage.org${imgsrc}`
}

let handler = async (m, { conn, text }) => {
  if (!text) return m.reply('*Example:* .txt2img Cute Girl')

  try {
    // 💬 Reply saat mulai proses
    await m.reply('⏳ Sedang membuat gambar dari teks...')

    const imageUrl = await txttoimage(text)

    // ✅ Reply saat gambar berhasil dikirim
    await conn.sendMessage(m.chat, {
      image: { url: imageUrl },
      caption: `✅ Berikut hasil gambar dari teks:\n\n📝 *Prompt:* ${text}`
    }, { quoted: m })

  } catch (e) {
    m.reply('❌ Gagal generate gambar. Error: ' + e.message)
  }
}

handler.help = ['txt2img <teks>']
handler.command = ['txt2img']
handler.tags = ['ai']
handler.limit = true
handler.register = true

export default handler