let handler = async (m, { text }) => {
  if (!text) return m.reply('Contoh: .tekspanjang hai');

  const kata = text.trim();
  const baris = 50;  // jumlah baris
  const kolom = 10;  // jumlah kata per baris

  const hasil = Array.from({ length: baris }, () =>
    Array(kolom).fill(kata).join(' ')
  ).join('\n');

  m.reply(hasil);
};

handler.help = ['tekspanjang <teks>'];
handler.tags = ['fun'];
handler.command = /^\.?tekspanjang(?:\s+(.*))?$/i;

handler.register = true;  // Wajib register
handler.limit = true;     // Mengurangi 1 limit setiap kali pakai

export default handler;