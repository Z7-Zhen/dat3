import axios from 'axios'
import FormData from 'form-data'

let handler = async (m, { conn }) => {
  const q = m.quoted ? m.quoted : m
  const mime = q.mimetype || ''
  if (!/image/.test(mime)) return m.reply(`📸 Balas gambar dengan caption *.tobugil*`)

  await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

  try {
    // 🧩 Download gambar
    const buffer = await q.download()
    if (!buffer) throw new Error('❌ Gagal mengunduh gambar')

    // 🧩 Upload ke Catbox
    const form = new FormData()
    form.append('reqtype', 'fileupload')
    form.append('fileToUpload', buffer, { filename: 'photo.jpg', contentType: 'image/jpeg' })

    const resCat = await axios.post('https://catbox.moe/user/api.php', form, {
      headers: form.getHeaders(),
    })

    const imageUrl = resCat.data.trim()
    if (!/^https?:\/\//.test(imageUrl)) throw new Error('❌ Gagal upload ke Catbox: ' + resCat.data)

    // 🧠 API remove-clothes
    const apiUrl = `https://api.nekolabs.my.id/tools/convert/remove-clothes?imageUrl=${encodeURIComponent(imageUrl)}`
    const resApi = await axios.get(apiUrl, { timeout: 180000 })

    if (!resApi.data?.success || !resApi.data?.result) throw new Error('API gagal mengembalikan hasil')

    const resultUrl = resApi.data.result

    // 📤 Kirim hasil
    await conn.sendMessage(
      m.chat,
      { image: { url: resultUrl }, caption: `✨ Hasil AI To Bugil` },
      { quoted: m }
    )

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
  } catch (e) {
    console.error(e)
    m.reply(`❌ Eror kak: ${e.message}`)
  }
}

handler.help = ['tobugil']
handler.tags = ['ai', 'premium', 'tools']
handler.command = /^tobugil$/i
handler.premium = true

export default handler