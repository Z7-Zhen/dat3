import axios from "axios";
import FormData from "form-data";
import crypto from "crypto";

const BASE_URL = "https://ai-apps.codergautam.dev";

function acakName(len = 10) {
  const chars = "abcdefghijklmnopqrstuvwxyz";
  return Array.from({ length: len }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
}

async function autoregist() {
  const uid = crypto.randomBytes(12).toString("hex");
  const email = `gienetic${Date.now()}@nyahoo.com`;

  const payload = {
    uid,
    email,
    displayName: acakName(),
    photoURL: "https://i.pravatar.cc/150",
    appId: "photogpt"
  };

  try {
    const res = await axios.post(`${BASE_URL}/photogpt/create-user`, payload, {
      headers: {
        "content-type": "application/json",
        "accept": "application/json",
        "user-agent": "okhttp/4.9.2"
      }
    });
    if (!res.data.success) throw new Error("Register gagal: " + JSON.stringify(res.data));
    return uid;
  } catch (e) {
    throw new Error("Gagal register akun: " + e.message);
  }
}

async function img2img(imageBuffer, prompt) {
  const uid = await autoregist();
  const form = new FormData();
  form.append("image", imageBuffer, { filename: "input.jpg", contentType: "image/jpeg" });
  form.append("prompt", prompt);
  form.append("userId", uid);

  try {
    const uploadRes = await axios.post(`${BASE_URL}/photogpt/generate-image`, form, {
      headers: {
        ...form.getHeaders(),
        "accept": "application/json",
        "user-agent": "okhttp/4.9.2",
        "accept-encoding": "gzip"
      }
    });

    if (!uploadRes.data.success) throw new Error(JSON.stringify(uploadRes.data));

    const { pollingUrl } = uploadRes.data;
    let status = "pending";
    let resultUrl = null;

    // Polling sampai gambar jadi (maksimal 5x coba)
    for (let i = 0; i < 5; i++) {
      const pollRes = await axios.get(pollingUrl, {
        headers: { "accept": "application/json", "user-agent": "okhttp/4.9.2" }
      });
      status = pollRes.data.status;
      if (status === "Ready") {
        resultUrl = pollRes.data.result.url;
        break;
      }
      await new Promise(r => setTimeout(r, 3000)); // Tunggu 3 detik
    }

    if (!resultUrl) throw new Error("Gagal mendapatkan hasil gambar (timeout).");

    const resultImg = await axios.get(resultUrl, { responseType: "arraybuffer" });
    return Buffer.from(resultImg.data);
  } catch (e) {
    throw new Error("Gagal generate gambar: " + e.message);
  }
}

let handler = async (m, { conn, text, command, usedPrefix }) => {
  try {
    const q = m.quoted ? m.quoted : m;
    if (!q) return m.reply("❌ *Balas gambar dengan perintah ini!*");
    
    const mime = (q.msg || q).mimetype || q.mediaType || '';
    if (!/^image/.test(mime) || /webp/.test(mime)) {
      return m.reply(`*Cara penggunaan:*\n1. Kirim gambar (JPG/PNG).\n2. Balas dengan: ${usedPrefix}${command} [prompt]\n\n*Contoh:* ${usedPrefix}${command} cyberpunk city at night`);
    }

    if (!text) return m.reply(`Masukkan prompt!\n*Contoh:* ${usedPrefix}${command} make it a fantasy landscape`);

    const loadingMsg = await conn.sendMessage(m.chat, {
      text: `⏳ *Generating AI image with prompt:*\n"${text}"\nPlease wait...`
    });

    const imageBuffer = await q.download();
    if (!imageBuffer) throw new Error("Gagal mengunduh gambar.");

    const resultBuffer = await img2img(imageBuffer, text);

    await conn.sendMessage(m.chat, {
      image: resultBuffer,
      caption: `✨ *AI Image Result*\nPrompt: ${text}`
    }, { quoted: m });

    await conn.sendMessage(m.chat, { delete: loadingMsg.key });

  } catch (e) {
    console.error("Error:", e);
    m.reply(`❌ *Failed to generate image!*\n\n*Error:* ${e.message}\n\n*Please try again or change the prompt.*`);
  }
};

handler.help = ['img2img'];
handler.tags = ['ai', 'tools'];
handler.command = /^(img2img|aiimage|aigenerate)$/i;
handler.limit = false;
handler.premium = true;

export default handler;