import axios from 'axios';

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `❗ Gunakan dengan format:\n${usedPrefix + command} <pertanyaan>`;
  
  await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

  try {
    let res = await axios.get(`https://izumiiiiiiii.dpdns.org/ai/gptnano`, {
      params: {
        prompt: text // coba pakai "prompt", kalau gagal bisa ganti "text" / "query"
      }
    });

    let data = res.data;
    if (!data || !data.status) {
      return m.reply(`❌ Gagal ambil jawaban.\n\nDetail: ${data?.error || "Unknown"}`);
    }

    m.reply(`🤖 *GPTNano*:\n\n${data.result}`);
  } catch (e) {
    console.error(e);
    m.reply(`❌ Error: ${e.message}`);
  }
};

handler.help = ['gptnano <teks>'];
handler.tags = ['ai'];
handler.command = /^gptnano$/i;

export default handler;