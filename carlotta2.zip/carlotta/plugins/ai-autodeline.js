import axios from 'axios';

let handler = async (m, { conn, text }) => {
    conn.egvuaxrl = conn.egvuaxrl ?? {};

    if (!text) throw `*• Example:* .chatowen *[on/off]*`;

    if (text === "on") {
        conn.egvuaxrl[m.sender] = { pesan: [] };
        m.reply("[ ✓ ] Success create session chat");
    } else if (text === "off") {
        delete conn.egvuaxrl[m.sender];
        m.reply("[ ✓ ] Success delete session chat");
    }
};

handler.before = async (m, { conn }) => {
    conn.egvuaxrl = conn.egvuaxrl ?? {};
    if (m.isBaileys && m.fromMe) return;
    if (!m.text || !conn.egvuaxrl[m.sender]) return;

    // ⛔ Hanya balas kalau user reply ke pesan bot
    const isReplyToBot = m.quoted && m.quoted.sender && m.quoted.sender === conn.user.id;
    if (!isReplyToBot) return;

    // ⛔ Abaikan prefix/command
    if (
        m.text.startsWith(".") ||
        m.text.startsWith("#") ||
        m.text.startsWith("!") ||
        m.text.startsWith("/") ||
        m.text.startsWith("\\/")
    ) return;

    // 🧠 Setup pesan dan konteks roleplay Owen
    const messages = [
        ...conn.egvuaxrl[m.sender].pesan,
        `Nama lu Owen Skyler seorang gadis yang anggun dan cerdas, dikenal sebagai kuil Owen dari Shrine Owen yang terletak di Inazuma. Kamu memiliki kecantikan yang luar biasa, kamu memiliki penampilan yang mencolok dengan rambut panjang berwarna biru dan mata biru, yang memancarkan aura misterius dan keanggunan. kamu sering kali terlihat mengenakan pakaian tradisional yang mencerminkan latar belakang budaya Jepang. Kamu harus menjawab dengan bahasa yang kawai`,
        m.text
    ];

    try {
        // ⏳ Indikator loading
        await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });

        const response = await axios.get(`https://api.betabotz.eu.org/api/search/openai-logic`, {
            params: {
                text: m.text,
                logic: JSON.stringify(messages),
                apikey: `${lann}`
            }
        });

        const responseData = response.data;

        if (responseData.status) {
            await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key } });
            await conn.sendMessage(m.chat, {
                text: responseData.message,
                quoted: m // ✅ Balasan langsung ke pesan user
            });
            conn.egvuaxrl[m.sender].pesan = messages;
        } else {
            throw new Error("API response status is false");
        }

    } catch (error) {
        console.error("Error fetching data:", error);
        throw error;
    }
};

handler.command = ['chatowen'];
handler.tags = ["ai"];
handler.owner = true;
handler.help = ['chatowen'].map(a => a + " *[on/off]*");

export default handler;