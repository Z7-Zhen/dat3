// ripleai.js
import fetch from "node-fetch"

let handler = async (m, { text }) => {
  if (!text) throw `⚠️ Gunakan perintah:\n.ripleai <pertanyaan / prompt>`

  try {
    let res = await fetch(`https://api.nekolabs.my.id/ai/ripleai?text=${encodeURIComponent(text)}`)
    let raw = await res.text()

    let reply
    try {
      let json = JSON.parse(raw)
      reply =
        json.result?.text ||
        json.result ||
        json.data?.text ||
        json.answer ||
        null
    } catch {
      reply = raw // fallback kalau bukan JSON
    }

    if (!reply || reply.includes('<html')) throw '❌ API tidak balikin jawaban valid'

    await m.reply(reply)
  } catch (e) {
    console.error('Error ripleai:', e)
    m.reply('❌ Gagal ambil jawaban, coba lagi nanti.')
  }
}

handler.help = ['ripleai <teks>']
handler.tags = ['ai']
handler.command = /^ripleai$/i
handler.limit = true
handler.register = true

export default handler