import axios from "axios"
import FormData from "form-data"

async function uploadToUguu(buffer, filename = "image.jpg") {
  const form = new FormData()
  form.append("files[]", buffer, { filename })
  const { data } = await axios.post("https://uguu.se/upload.php", form, {
    headers: form.getHeaders(),
    timeout: 60000
  })
  const url = data?.files?.[0]?.url
  if (!url) throw new Error("Uguu upload gagal")
  return url
}

const handler = async (m, { conn, text, usedPrefix }) => {
  const q = m.quoted ? m.quoted : m
  const mime = (q.msg || q).mimetype || ""

  if (!/image\//i.test(mime)) {
    return conn.sendMessage(
      m.chat,
      { text: `📷 Balas *gambar* dengan caption: *${usedPrefix}editimg <prompt>*` },
      { quoted: m }
    )
  }

  if (!text) {
    return conn.sendMessage(
      m.chat,
      { text: "📝 Prompt wajib diisi!\nContoh: *.editimg ubah jadi anime realistis lighting warm*" },
      { quoted: m }
    )
  }

  await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } })

  try {
    const imgBuffer = await q.download()
    if (!imgBuffer?.length) throw new Error("Gagal download media")

    const imageUrl = await uploadToUguu(imgBuffer, "input.jpg")

    const apiUrl = `https://api.deline.web.id/ai/editimg?url=${encodeURIComponent(imageUrl)}&prompt=${encodeURIComponent(text)}`
    const { data } = await axios.get(apiUrl, { timeout: 180000 })

    if (!data?.status || !data?.result?.url) {
      throw new Error(data?.error || "API tidak mengembalikan result")
    }

    const outResp = await axios.get(data.result.url, {
      responseType: "arraybuffer",
      timeout: 120000
    })
    const outBuf = Buffer.from(outResp.data)

    await conn.sendFile(m.chat, outBuf, "editimg.jpg", "✨ *Edit Image Berhasil*", m)
    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
  } catch (e) {
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
    conn.sendMessage(m.chat, { text: `Gagal: ${e?.message || e}` }, { quoted: m })
  }
}

handler.help = ["editimg <prompt>", "editimage <prompt>", "editfoto <prompt>"]
handler.tags = ["ai"]
handler.command = /^(editimg|editimage|editfoto|editgambar)$/i
handler.register = true
handler.premium = true

export default handler