import axios from 'axios'
import fs from 'fs'

let handler = async (m, { conn, text }) => {
  if (!text) return m.reply('🔗 Kirim link MediaFirenya dulu kak!')

  try {
    const api = `https://api.siputzx.my.id/api/d/mediafire?url=${encodeURIComponent(text)}`
    const { data } = await axios.get(api)

    if (!data.status || !data.data?.downloadLink) {
      return m.reply('❌ Gagal ambil data dari MediaFire. Pastikan linknya benar ya!')
    }

    const { fileName, fileSize, downloadLink, mimeType } = data.data
    const fileRes = await axios.get(downloadLink, { responseType: 'arraybuffer' })
    const buffer = Buffer.from(fileRes.data)

    const caption = `📁 *MediaFire File Info*\n\n` +
                    `🧾 *Name:* ${fileName}\n` +
                    `📦 *Size:* ${fileSize}\n` +
                    `🔗 *Link:* ${text}`

    await conn.sendMessage(m.chat, {
      document: buffer,
      mimetype: mimeType || 'application/octet-stream',
      fileName,
      caption,
      jpegThumbnail: fs.existsSync('./thumbnail.jpg') ? fs.readFileSync('./thumbnail.jpg') : null
    }, { quoted: m })

  } catch (err) {
    console.error(err)
    m.reply('🚫 Terjadi kesalahan saat mengunduh file dari MediaFire.')
  }
}

handler.help = ['mediafireprem <url>']
handler.tags = ['premium']
handler.command = /^(mfprem|mediafireprem)$/i
handler.premium = true
handler.register = true

export default handler