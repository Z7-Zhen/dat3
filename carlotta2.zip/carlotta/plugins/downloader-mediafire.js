import axios from 'axios';
import fs from 'fs';

let handler = async (m, { conn, text }) => {
  if (!text) return m.reply('🔗 Kirim link MediaFirenya dulu kak!');

  try {
    const api = `https://api.deline.web.id/downloader/mediafire?url=${encodeURIComponent(text)}`;
    const { data } = await axios.get(api, { timeout: 30000 });

    if (!data?.status || !data?.result?.downloadLink) {
      return m.reply('❌ Gagal ambil data dari MediaFire. Cek linknya ya!');
    }

    const {
      title = 'file',
      size: fileSize = '',
      type: fileType = '',
      uploaded = '',
      downloadLink
    } = data.result;

    const fileRes = await axios.get(downloadLink, { responseType: 'arraybuffer', timeout: 120000 });
    const buffer = Buffer.from(fileRes.data);

    const safeName = title.replace(/[<>:"/\\|?*\x00-\x1F]/g, '_');
    const fileName = safeName || 'mediafire_file';
    const mimeType =
      fileRes.headers['content-type'] ||
      (fileType?.toLowerCase().includes('zip') ? 'application/zip' : 'application/octet-stream');

    const caption =
`📁 *MediaFire File*
🧾 *Nama:* ${fileName}
📦 *Ukuran:* ${fileSize || '-'}
🗂 *Tipe:* ${fileType || '-'}
🗓 *Uploaded:* ${uploaded || '-'}
🔗 *Sumber:* ${text}`;

    await conn.sendMessage(
      m.chat,
      {
        document: buffer,
        mimetype: mimeType,
        fileName,
        caption,
        jpegThumbnail: fs.existsSync('./thumbnail.jpg') ? fs.readFileSync('./thumbnail.jpg') : null
      },
      { quoted: m }
    );
  } catch (err) {
    console.error(err);
    m.reply('🚫 Terjadi kesalahan saat mengunduh file dari MediaFire.');
  }
};

handler.help = ['mediafire <url>'];
handler.tags = ['downloader'];
handler.command = /^(mf|mediafire)$/i;
handler.register = true;
handler.limit = true;


export default handler;