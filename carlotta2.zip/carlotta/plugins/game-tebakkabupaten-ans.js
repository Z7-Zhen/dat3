import similarity from 'similarity'
const threshold = 0.72

export async function before(m, { conn }) {
    let id = m.chat
    const quotedId = m.quoted?.id || m.quoted?.key?.id
    const quotedText = m.quoted?.text || m.quoted?.caption || ''
    if (!quotedId || !quotedText || !/Ketik.*hkab/i.test(quotedText) || /hkab/i.test(m.text)) return true

    this.tebakkabupaten = this.tebakkabupaten || {}
    if (!(id in this.tebakkabupaten)) return conn.reply(m.chat, 'Soal itu telah berakhir', m)

    if (quotedId === (this.tebakkabupaten[id][0]?.key?.id || this.tebakkabupaten[id][0]?.id)) {
        let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(m.text)
        if (isSurrender) {
            clearTimeout(this.tebakkabupaten[id][3])
            delete this.tebakkabupaten[id]
            return conn.reply(m.chat, '*Yah Menyerah :( !*', m)
        }

        let json = JSON.parse(JSON.stringify(this.tebakkabupaten[id][1]))
        const ans = json.title.toLowerCase().trim()
        const usr = m.text.toLowerCase().trim()

        if (usr === ans) {
            global.db.data.users[m.sender].exp += this.tebakkabupaten[id][2]
            conn.reply(m.chat, `✅ *Benar!*\n+${this.tebakkabupaten[id][2]} XP`, m)
            clearTimeout(this.tebakkabupaten[id][3])
            delete this.tebakkabupaten[id]
        } else if (similarity(usr, ans) >= threshold) {
            m.reply(`❗ *Dikit Lagi!*`)
        } else {
            conn.reply(m.chat, `❌ *Salah!*`, m)
        }
    }
    return true
}

export const exp = 0

const buttontebakkabupaten = [
    ['tebakkabupaten', '/tebakkabupaten']
]
