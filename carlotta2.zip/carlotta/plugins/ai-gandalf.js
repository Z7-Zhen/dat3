// gandalf.js
import fetch from "node-fetch"

let handler = async (m, { text }) => {
  if (!text) throw `⚠️ Gunakan: .gandalf <pertanyaan>`

  try {
    // pakai param "prompt" bukan "text"
    let res = await fetch(`https://api.siputzx.my.id/api/ai/gandalf?prompt=${encodeURIComponent(text)}`)
    let json = await res.json()

    if (!json || !json.result) throw '❌ API tidak balikin jawaban valid'

    await m.reply(json.result)
  } catch (e) {
    console.error("Error gandalf:", e)
    m.reply("❌ Gagal ambil jawaban, coba lagi nanti.")
  }
}

handler.help = ['gandalf <teks>']
handler.tags = ['ai']
handler.command = /^gandalf$/i
handler.register = true

export default handler