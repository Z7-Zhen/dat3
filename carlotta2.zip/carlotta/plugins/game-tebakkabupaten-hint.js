let handler = async (m, { conn }) => {
    conn.tebakkabupaten = conn.tebakkabupaten || {}
    let id = m.chat
    if (!(id in conn.tebakkabupaten)) throw false

    const jawaban = (conn.tebakkabupaten[id][1]?.title || '').trim()
    const clue = jawaban.replace(/[AIUEOaiueo]/ig, '_')

    conn.reply(
        m.chat,
        '```' + clue + '```',
        conn.tebakkabupaten[id][0]
    )
}

handler.command = /^hkab$/i

export default handler
