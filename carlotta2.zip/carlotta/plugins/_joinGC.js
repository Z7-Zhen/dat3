import fs from "fs"

const DB_PATH = "./database/joingc.json"

function loadDB() {
  const db = fs.existsSync(DB_PATH) ? JSON.parse(fs.readFileSync(DB_PATH)) : {}
  if (!db.joingc) db.joingc = { enabled: false }
  if (!db.warnedUsers) db.warnedUsers = {}
  return db
}

function saveDB(db) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2))
}

setInterval(() => {
  let db = loadDB()
  db.warnedUsers = {}
  saveDB(db)
  console.log("[INFO] warnedUsers direset (joingc.json).")
}, 5 * 60 * 1000)

let handler = m => m

handler.before = async function (m, { conn, isOwner, isPrems }) {
  let db = loadDB()
  if (!db.joingc.enabled) return true 

  if (!m.isGroup && !isOwner && !isPrems) {
    const sender = m.sender

    if (!db.warnedUsers[sender]) {
      db.warnedUsers[sender] = true
      saveDB(db)

      await conn.reply(
        m.chat,
        `❌ Bot ini hanya bisa digunakan di dalam grup.\n\n` +
        `👥 Silakan join ke grup resmi kami:\n` +
        `👉 https://chat.whatsapp.com/JB683jnIw1t6WjNUuNTUu4\n\n` +
        `⚡️ Atau upgrade ke premium untuk bisa menggunakan bot di private chat.\n` +
        `Hubungi owner: wa.me/31616482629`,
        m
      )
    }

    m.blocked = true
    throw false
  }
}

export default handler