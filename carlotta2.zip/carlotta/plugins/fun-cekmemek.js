import { areJidsSameUser } from '@adiwajshing/baileys'

function resolveJid(input, participants = []) {
    const found = participants.find(p =>
        areJidsSameUser(p?.id, input) ||
        areJidsSameUser(p?.lid, input) ||
        areJidsSameUser(p?.jid, input)
    )
    return found?.jid || input
}

function pickRandom(list) {
    return list[Math.floor(Math.random() * list.length)]
}

let handler = async (m, { conn, text, participants }) => {
    if ((!text || !text.trim()) && (!m.mentionedJid || !m.mentionedJid.length)) {
        return conn.reply(m.chat, '📌 Contoh: .cekmemek nama / @user', m)
    }

    let name, mentions = []

    if (m.mentionedJid && m.mentionedJid.length) {
        const targetJid = resolveJid(m.mentionedJid[0], participants)
        name = '@' + targetJid.split('@')[0]
        mentions = [targetJid]
    } else {
        name = text.trim()
    }

    conn.reply(m.chat, `
╭━━━━°「 *Memek ${name}* 」°
┃
┊• Nama     : ${name}
┃• Warna    : ${pickRandom(['Pink 🌸','Coklat 🍫','Putih susu 🍼','Merah muda ❤️','Hitam manis 🖤'])}
┊• Dalam    : ${pickRandom(['10 cm','15 cm','20 cm','25 cm','Dalam banget'])}
┃• Lebar    : ${pickRandom(['5 cm','7 cm','8 cm','9 cm','ketat banget 🔥'])}
┊• Kondisi  : ${pickRandom(['Basah kuyup 💦','Kering kerontang 🌵','Anget anget 🤭','Muluss bgt ✨'])}
╰═┅═━––––––๑
`.trim(), m, { mentions })
}

handler.help = ['cekmemek *<text|@user>*']
handler.tags = ['fun']
handler.command = /^cekmemek$/i
handler.limit = true
handler.register = true

export default handler