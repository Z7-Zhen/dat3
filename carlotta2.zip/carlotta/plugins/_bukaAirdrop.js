let handler = async (m, { conn, command }) => {
  conn.airdrop = conn.airdrop || {}
  let airdrop = conn.airdrop['120363421938515460@g.us']
  let users = global.db.data.users[m.sender]
  let fkontak = {
    key: {
      participants: "0@s.whatsapp.net",
      remoteJid: "status@broadcast",
      fromMe: false,
      id: "Halo"
    },
    message: {
      contactMessage: {
        vcard: `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
      }
    },
    participant: "0@s.whatsapp.net"
  }

  if (!airdrop) return

  let msg = airdrop.msg
  if (airdrop.users.includes(m.sender)) return m.reply(`❕Kamu sudah mengambil hadiah ini`)
  if (airdrop.users.length >= 10) return m.reply(`*Yahh* AirDrop sudah habis`)

  const quotedId = m.quoted?.id || m.quoted?.key?.id
  const quotedText = m.quoted?.text || ''
  if (command === 'buka' && (!quotedId || quotedId !== (msg.key?.id) || !/Ketik.*buka/i.test(quotedText))) {
    return conn.reply(m.chat, `Balas pesan ini!`, msg, { contextInfo: { mentionedJid: [m.sender] } })
  }

  let money = Math.floor(Math.random() * 30000000)
  let exp = Math.floor(Math.random() * 130000)
  let dm = Math.floor(Math.random() * 40)
  let boxs = Math.floor(Math.random() * 60)

  let cap = `*[ 🎁🎉 Kamu Telah Membuka AirDrop ]*

\`AirDrop-ID:\` ${airdrop.id}

*💵 Money:* ${money.toLocaleString()}
*🧪 Exp:* ${exp.toLocaleString()}
*💎 Diamond:* ${dm}
*📦 Boxs:* ${boxs}

\`Setiap user hadiahnya berbeda-beda\``

  users.money += money
  users.exp += exp
  users.diamond += dm
  users.boxs += boxs
  users.rock = (users.rock || 0) + 1
  airdrop.users.push(m.sender)

  await conn.sendMessage(m.chat, {
    text: cap,
    contextInfo: {
      mentionedJid: [m.sender],
      externalAdReply: {
        showAdAttribution: false,
        title: `[🎉🎀 Open AirDrop ]`,
        thumbnailUrl: 'https://telegra.ph/file/2481af9d807753ed42fd8.jpg',
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  }, { quoted: fkontak })

  if (airdrop.users.length >= 10) {
    conn.sendMessage('120363421938515460@g.us', {
      delete: {
        remoteJid: '120363421938515460@g.us',
        fromMe: true,
        id: msg.key.id,
        participant: msg.key.participant
      }
    })
    conn.reply(m.chat, `*🎁AirDrop* telah habis, Maksimum 10 player yang mendapatnya`)
    delete conn.airdrop['120363421938515460@g.us']
  }
}

handler.command = /^buka$/i
handler.limit = true
export default handler