const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = (await import('@adiwajshing/baileys')).default;
import uploadImage from '../lib/uploadImage.js';

async function handler(m, { conn, text, command }) {
    conn.prem = conn.prem || {};
    conn.loading = conn.loading || {};
    let pendings = conn.prem[m.chat];
    let wait = conn.loading['31616482629@s.whatsapp.net'];
    if (m.isPrivate) {
m.reply('Khusus group')
    delete conn.prem[m.chat]
    } else if (pendings && m.sender === pendings.buyer) {
    if (command === 'seminggu') {
    if (global.diskonprem == 'true') {
    if (global.listdiskon == 'mingguan') {
    pendings.nominal = 3000
    }
    }
    pendings.nominal = 5000
    let cap = `\`Transaksi Pembelian:\`
* 👑 Premium: 1 Minggu
* 🛒 Harga: Rp.${pendings.nominal.toLocaleString()}
* 🎁 Bonus: 1,000 Limit
* 📅 Bonus Hari: 3 Hari

\`Metode Transfer:\`
* Dana: 081219896962
* Qris: Klik Button Dibawah

\`BACA INI!\`
*Transfer sebelum 3 menit, melalui E-Wallet atau Qris, Kirim foto/screenshot bukti transfer, Lalu reply buktinya ketik: transaksi*`
    let msg = generateWAMessageFromContent(m.chat, {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                body: proto.Message.InteractiveMessage.Body.create({
                                    text: cap,
                                }),
                                footer: proto.Message.InteractiveMessage.Footer.create({
                                    text: "*© Renza!*"
                                }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    title: "\t[ 🛍️ *PAYMENT* ]\n",
                                    subtitle: "",
                                    hasMediaAttachment: false
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons: [
                                        {
                                            name: "quick_reply",
                                            buttonParamsJson: "{\"display_text\":\"🛒 QRIS\",\"id\":\"qris\"}"
                                        },
                                        {
                                            name: "quick_reply",
                                            buttonParamsJson: "{\"display_text\":\"❔ Contoh TF\",\"id\":\"contoh\"}"
                                        },
                                    ],
                                })
                            })
                        },
                    }
                }, {});
                await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
                pendings.status = 'pending'
                pendings.prem = 7;
                pendings.lim = 1000
    } else if (command === 'bulanin') {
    if (global.diskonprem == 'true') {
    if (global.listdiskon == 'bulanin') {
    pendings.nominal = 10000
    }
    }
    pendings.nominal = 12000
    let cap = `\`Transaksi Pembelian:\`
* 👑 Premium: 1 Bulan
* 🛒 Harga: Rp.${pendings.nominal.toLocaleString()}
* 🎁 Bonus: 5,000 Limit
* 📅 Bonus Hari: 10 Hari

\`Metode Transfer:\`
* Dana: 081219896962
* Qris: Klik Button Dibawah

\`BACA INI!\`
*Transfer sebelum 3 menit, melalui E-Wallet atau Qris, Kirim foto/screenshot bukti transfer, Lalu reply buktinya ketik: transaksi*`
    let msg = generateWAMessageFromContent(m.chat, {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                body: proto.Message.InteractiveMessage.Body.create({
                                    text: cap,
                                }),
                                footer: proto.Message.InteractiveMessage.Footer.create({
                                    text: "*© Renza!*"
                                }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    title: "\t[ 🛍️ *PAYMENT* ]\n",
                                    subtitle: "",
                                    hasMediaAttachment: false
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons: [
                                        {
                                            name: "quick_reply",
                                            buttonParamsJson: "{\"display_text\":\"🛒 QRIS\",\"id\":\"qris\"}"
                                        },
                                        {
                                            name: "quick_reply",
                                            buttonParamsJson: "{\"display_text\":\"❔ Contoh TF\",\"id\":\"contoh\"}"
                                        },
                                    ],
                                })
                            })
                        },
                    }
                }, {});
                await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
                pendings.status = 'pending'
                pendings.prem = 40;
                pendings.lim = 5000
    } else if (command === 'tigabulan') {
    if (global.diskonprem == 'true') {
    if (global.listdiskon == 'tigabulan') {
    pendings.nominal = 19000
    }
    }
    pendings.nominal = 23000
    let cap = `\`Transaksi Pembelian:\`
* 👑 Premium: 3 Bulan
* 🛒 Harga: Rp.${pendings.nominal.toLocaleString()}
* 🎁 Bonus: 10,000 Limit
* 📅 Bonus Hari: 15 Hari

\`Metode Transfer:\`
* Dana: 081219896962
* Qris: Klik Button Dibawah

\`BACA INI!\`
*Transfer sebelum 3 menit, melalui E-Wallet atau Qris, Kirim foto/screenshot bukti transfer, Lalu reply buktinya ketik: transaksi*`
    let msg = generateWAMessageFromContent(m.chat, {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                body: proto.Message.InteractiveMessage.Body.create({
                                    text: cap,
                                }),
                                footer: proto.Message.InteractiveMessage.Footer.create({
                                    text: "*© Renza!*"
                                }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    title: "\t[ 🛍️ *PAYMENT* ]\n",
                                    subtitle: "",
                                    hasMediaAttachment: false
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons: [
                                        {
                                            name: "quick_reply",
                                            buttonParamsJson: "{\"display_text\":\"🛒 QRIS\",\"id\":\"qris\"}"
                                        },
                                        {
                                            name: "quick_reply",
                                            buttonParamsJson: "{\"display_text\":\"❔ Contoh TF\",\"id\":\"contoh\"}"
                                        },
                                    ],
                                })
                            })
                        },
                    }
                }, {});
                await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
                pendings.status = 'pending'
              //  pendings.nominal = 23000;
                pendings.prem = 105;
                pendings.lim = 10000
    } else if (command === 'lapanbulan') {
    if (global.diskonprem == 'true') {
    if (global.listdiskon == 'lapanbulan') {
    pendings.nominal = 40000
    }
    }
    pendings.nominal = 50000
    let cap = `\`Transaksi Pembelian:\`
* 👑 Premium: 8 Bulan
* 🛒 Harga: Rp.${pendings.nominal.toLocaleString()}
* 🎁 Bonus: 25,000 Limit
* 📅 Bonus Hari: 30 Hari

\`Metode Transfer:\`
* Dana: 081219896962
* Qris: Klik Button Dibawah

\`BACA INI!\`
*Transfer sebelum 3 menit, melalui E-Wallet atau Qris, Kirim foto/screenshot bukti transfer, Lalu reply buktinya ketik: transaksi*`
    let msg = generateWAMessageFromContent(m.chat, {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                body: proto.Message.InteractiveMessage.Body.create({
                                    text: cap,
                                }),
                                footer: proto.Message.InteractiveMessage.Footer.create({
                                    text: "*© Renza!*"
                                }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    title: "\t[ 🛍️ *PAYMENT* ]\n",
                                    subtitle: "",
                                    hasMediaAttachment: false
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons: [
                                        {
                                            name: "quick_reply",
                                            buttonParamsJson: "{\"display_text\":\"🛒 QRIS\",\"id\":\"qris\"}"
                                        },
                                        {
                                            name: "quick_reply",
                                            buttonParamsJson: "{\"display_text\":\"❔ Contoh TF\",\"id\":\"contoh\"}"
                                        },
                                    ],
                                })
                            })
                        },
                    }
                }, {});
                await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
                pendings.status = 'pending'
             //   pendings.nominal = 50000;
                pendings.prem = 270;
                pendings.lim = 25000
    } else if (command === 'tahunin') {
    if (global.diskonprem == 'true') {
    if (global.listdiskon == 'tahunin') {
    pendings.nominal = 90000
    }
    }
    pendings.nominal = 70000
    let cap = `\`Transaksi Pembelian:\`
* 👑 Premium: 1 Tahun
* 🛒 Harga: Rp.${pendings.nominal.toLocaleString()}
* 🎁 Bonus: 50,000 Limit
* 📅 Bonus Hari: 45 Hari

\`Metode Transfer:\`
* Dana: 081219896962
* Qris: Klik Button Dibawah

\`BACA INI!\`
*Transfer sebelum 3 menit, melalui E-Wallet atau Qris, Kirim foto/screenshot bukti transfer, Lalu reply buktinya ketik: transaksi*`
    let msg = generateWAMessageFromContent(m.chat, {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                body: proto.Message.InteractiveMessage.Body.create({
                                    text: cap,
                                }),
                                footer: proto.Message.InteractiveMessage.Footer.create({
                                    text: "*© Renza Official*"
                                }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    title: "\t[ 🛍️ *PAYMENT* ]\n",
                                    subtitle: "",
                                    hasMediaAttachment: false
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons: [
                                        {
                                            name: "quick_reply",
                                            buttonParamsJson: "{\"display_text\":\"🛒 QRIS\",\"id\":\"qris\"}"
                                        },
                                        {
                                            name: "quick_reply",
                                            buttonParamsJson: "{\"display_text\":\"❔ Contoh TF\",\"id\":\"contoh\"}"
                                        },
                                    ],
                                })
                            })
                        },
                    }
                }, {});
                await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
                pendings.status = 'pending'
             //   pendings.nominal = 90000;
                pendings.prem = 405;
                pendings.lim = 50000
    } else if (command === 'permanent') {
    if (global.diskonprem == 'true') {
    if (global.listdiskon == 'permanent') {
    pendings.nominal = 270000
    }
    }
    pendings.nominal = 300000
    let cap = `\`Transaksi Pembelian:\`
* 👑 Premium: Permanent
* 🛒 Harga: Rp.${pendings.nominal.toLocaleString()}
* 🎁 Bonus: 100,000 Limit
* 💵 Money: 10,000,000,000

\`Metode Transfer:\`
* Dana: 081219896962
* Qris: Klik Button Dibawah

\`BACA INI!\`
*Transfer sebelum 3 menit, melalui E-Wallet atau Qris, Kirim foto/screenshot bukti transfer, Lalu reply buktinya ketik: transaksi*`
    let msg = generateWAMessageFromContent(m.chat, {
                    viewOnceMessage: {
                        message: {
                            messageContextInfo: {
                                deviceListMetadata: {},
                                deviceListMetadataVersion: 2
                            },
                            interactiveMessage: proto.Message.InteractiveMessage.create({
                                body: proto.Message.InteractiveMessage.Body.create({
                                    text: cap,
                                }),
                                footer: proto.Message.InteractiveMessage.Footer.create({
                                    text: "*© Renza!*"
                                }),
                                header: proto.Message.InteractiveMessage.Header.create({
                                    title: "\t[ 🛍️ *PAYMENT* ]\n",
                                    subtitle: "",
                                    hasMediaAttachment: false
                                }),
                                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                    buttons: [
                                        {
                                            name: "quick_reply",
                                            buttonParamsJson: "{\"display_text\":\"🛒 QRIS\",\"id\":\"qris\"}"
                                        },
                                        {
                                            name: "quick_reply",
                                            buttonParamsJson: "{\"display_text\":\"❔ Contoh TF\",\"id\":\"contoh\"}"
                                        },
                                    ],
                                })
                            })
                        },
                    }
                }, {});
                await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
                pendings.status = 'pending'
             //   pendings.nominal = 300000;
                pendings.prem = 999999999999999;
                pendings.lim = 100000;
                pendings.money = 10000000000
          }
     }
}

handler.command = /^(seminggu|bulanin|tigabulan|lapanbulan|tahunin|permanent)/i;


function getContentType(message) {
    if (!message) return null
    if (message.templateButtonReplyMessage) {
        return 'templateButtonReplyMessage'
    }
    return null
}

handler.before = async function (m) {
    this.loading = this.loading || {};
    this.prem = this.prem || {};
    let nuy = '31616482629@s.whatsapp.net';
    let wait = this.loading[nuy];
    let pendings = Object.values(this.prem).find(pendings => pendings.status && pendings.room && pendings.buyer === m.sender);
    const contentType = getContentType(m.message);

    if (contentType === 'templateButtonReplyMessage') {
        let selectedButton = m.message.templateButtonReplyMessage.selectedId;
       if (wait) {
       if (wait && wait.status == 'pending') {
        if (selectedButton === 'sukses') {
        let nuy = '31616482629@s.whatsapp.net';
            let sukses;
            if (wait.nominal === 5000) {
                sukses = `✅ *Transaksi Berhasil!*\n\n\`Pembelian\`\n* 👑 Premium: 1 Minggu\n* 🛒 Harga: Rp.5,000\n* 🎁 Bonus: 1,000 Limit\n* 📅 Bonus Hari: 3 Hari\n* 🛍️ Status: Suksess ✓\n\`Premium Otomatis Masuk\`\n\n*💬 Pesan Owner:*\n_Makasih Sudah Berbelanja Di Toko Renza Melalui Bot Kami ❤️`;
            } else if (wait.nominal === 12000) {
                sukses = `✅ *Transaksi Berhasil!*\n\n\`Pembelian\`\n* 👑 Premium: 1 Bulan\n* 🛒 Harga: Rp.12,000\n* 🎁 Bonus: 5,000 Limit\n* 📅 Bonus Hari: 10 Hari\n* 🛍️ Status: Suksess ✓\n\`Premium Otomatis Masuk\`\n\n*💬 Pesan Owner:*\nMakasih Sudah Berbelanja Di Toko Renza Melalui Bot Kami ❤️`;
            } else if (wait.nominal === 23000) {
                sukses = `✅ *Transaksi Berhasil!*\n\n\`Pembelian\`\n* 👑 Premium: 3 Bulan\n* 🛒 Harga: Rp.23,000\n* 🎁 Bonus: 10,000 Limit\n* 📅 Bonus Hari: 15 Hari\n* 🛍️ Status: Suksess ✓\n\`Premium Otomatis Masuk\`\n\n*💬 Pesan Owner:*\nMakasih Sudah Berbelanja Di Toko Renza Melalui Bot Kami ❤️`;
            } else if (wait.nominal === 50000) {
                sukses = `✅ *Transaksi Berhasil!*\n\n\`Pembelian\`\n* 👑 Premium: 8 Bulan\n* 🛒 Harga: Rp.50,000\n* 🎁 Bonus: 25,000 Limit\n* 📅 Bonus Hari: 30 Hari\n* 🛍️ Status: Suksess ✓\n\`Premium Otomatis Masuk\`\n\n*💬 Pesan Owner:*\nMakasih Sudah Berbelanja Di Toko Renza Melalui Bot Kami ❤️`;
            } else if (wait.nominal === 90000) {
                sukses = `✅ *Transaksi Berhasil!*\n\n\`Pembelian\`\n* 👑 Premium: 1 Tahun\n* 🛒 Harga: Rp.90,000\n* 🎁 Bonus: 50,000 Limit\n* 📅 Bonus Hari: 45 Hari\n* 🛍️ Status: Suksess ✓\n\`Premium Otomatis Masuk\`\n\n*💬 Pesan Owner:*\nMakasih Sudah Berbelanja Di Toko Renza Melalui Bot Kami ❤️`;
            } else if (wait.nominal === 300000) {
                sukses = `✅ *Transaksi Berhasil!*\n\n\`Pembelian\`\n* 👑 Premium: Permanen\n* 🛒 Harga: Rp.300,000\n* 🎁 Bonus: 100,000 Limit\n* 📅 Bonus Hari: ∞\n* 🛍️ Status: Suksess ✓\n\`Premium Otomatis Masuk\`\n\n*💬 Pesan Owner:*\nMakasih Sudah Berbelanja Di Toko Renza Melalui Bot Kami ❤️`;
            }
            m.reply(`✅ *Transaksi Sukses*`)
            await conn.reply(wait.room, sukses, m);
            let buyer = global.db.data.users[wait.buyer];
            let jumlahHari = 86400000 * wait.prem
            let now = new Date() * 1
            if (now < buyer.premiumTime) buyer.premiumTime += jumlahHari
            else buyer.premiumTime = now + jumlahHari 
            buyer.premium = true
            buyer.limit += wait.lim
            delete conn.loading[nuy];
        } else if (selectedButton === 'tidak') {
            let nuy = '31616482629@s.whatsapp.net';
            let tidak = `[❌] *Transaksi Gagal!*\n\n\`Pembelian:\`\n* 👑 Premium: ${wait.prem < 999999999999 ? + wait.prem + ' Days' : 'Permanen'}\n* 🛒 Harga: ${wait.nominal.toLocaleString()}\n* 🛍️ Status: Gagal X\n\n*💬 Pesan Owner:*\n*Maaf Transaksi Anda Kami Tolak, Di Karenakan Tidak Sesuai.*`;
            m.reply(`❌ *Transaksi Gagal*`)
            await conn.reply(wait.room, tidak, m);
            delete conn.loading[nuy];
        }
    }
   } else if (pendings) {
            pendings.status = 'pending';
            if (selectedButton === 'qris') {
            m.reply(`*Mohon Tunggu.*`)
            await conn.sendFile(m.chat, 'https://files.catbox.moe/pq8i7v.jpg', 'nuy.jpg', `*Scan QR Ini*\n\nJika Sudah Transfer, Kirim Dahulu Bukti Transfer nya, Lalu Reply Fotonya Dan Ketik *Transaksi*`, m);
        } else if (selectedButton === 'contoh') {
         m.reply(`*Mohon Tunggu*`)
         await conn.sendFile(m.chat, 'https://telegra.ph/file/f01bdcdf8394d1cb101e6.jpg', 'contoh.jpg', `*Contoh Mengirim Bukti Transfer*`, m)
            }
       }
    } else if (pendings && m.sender === pendings.buyer && pendings.status == 'pending' && /^(transaksi)/i.test(m.text)) {
            let q = m.quoted ? m.quoted : m
            let mime = (q.message || q).mimetype || ''
            if (!mime) return m.reply(`Kirim Dahulu Bukti Transaksinya, Lalu Reply Fotonya Dan Ketik *Transaksi*`);

            let img = await q.download();
            let image = await uploadImage(img);
            let nuy = '31616482629@s.whatsapp.net'
            this.loading[nuy] = {
                status: 'pending',
                buyer: pendings.buyer,
                room: pendings.room,
                nominal: pendings.nominal,
                prem: pendings.prem,
                lim: pendings.lim,
            };
            wait = this.loading[nuy]
            let d = new Date(new Date + 3600000)
            let locale = 'id'
            let time = d.toLocaleTimeString(locale, { timeZone: 'Asia/Jakarta' })
            time = time.replace(/[.]/g, ':')
            if (wait.prem == 999999999999) {
            wait.prem = 'Permanen'
            }
            await conn.reply(m.chat, `[❕] *Transaksi Di pendings*\n* 🏷️ Premium: ${wait.prem < 999999999999 ? + wait.prem + ' Days' : 'Permanen'}\n* 🛒 Harga: Rp.${pendings.nominal.toLocaleString()}\n* 🕓 Status: PENDING\n\`Tunggu Respon Dari Owner, Jika Owner Tidak Merespon, Anda Bisa Chat Owner\``, m);
            let nuyy = `Hai Renza👋🏻❤️\nAda Transaksi Premium Yang Pending Nihh, Yuu Konfirmasi\n\n\`Pembelian:\`\n* 👑 Premium: ${wait.prem < 999999999999 ? + wait.prem + ' Days' : 'Permanen'}\n* 🛒 Harga: Rp.${wait.nominal.toLocaleString()}\n* 🕓 Status: PENDING\n\n\`Waktu Transaksi\`\n* ⏰ Pada Jam: ${time}`;
            let msg = generateWAMessageFromContent(m.chat, {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: {
                            deviceListMetadata: {},
                            deviceListMetadataVersion: 2
                        },
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body: proto.Message.InteractiveMessage.Body.create({
                                text: nuyy,
                            }),
                            footer: proto.Message.InteractiveMessage.Footer.create({
                                text: "© Renza!"
                            }),
                            header: proto.Message.InteractiveMessage.Header.create({
                                title: '\t*🛍️ TRANSAKSI PENDING*\n',
                                subtitle: "",
                                hasMediaAttachment: true,
                                ...(await prepareWAMessageMedia({ image: { url: image } }, { upload: conn.waUploadToServer }))
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: [
                                    {
                                        name: "quick_reply",
                                        buttonParamsJson: "{\"display_text\":\"✅ Terima Transaksi\",\"id\":\"sukses\"}"
                                    },
                                    {
                                        name: "quick_reply",
                                        buttonParamsJson: "{\"display_text\":\"❌ Tolak Transaksi\",\"id\":\"tidak\"}"
                                    },
                                ],
                            })
                        })
                    },
                }
            }, {});
            await conn.relayMessage(nuy, msg.message, { messageId: msg.key.id });
            delete conn.prem[m.chat];
    }
}


handler.limit = true
export default handler;