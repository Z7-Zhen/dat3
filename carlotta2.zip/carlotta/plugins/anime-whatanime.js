import axios from "axios";
import FormData from "form-data";

let handler = async (m, { conn }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";

  if (!mime) throw "Kirim atau reply gambar anime-nya dulu~";
  if (!/image\/(jpe?g|png)/.test(mime)) throw `Mime ${mime} nggak bisa dipakai ya ><`;

  let img = await q.download();
  await m.reply("Tunggu bentar yaa~ nyariin dulu... (⁄ ⁄>⁄ ▽ ⁄<⁄ ⁄)");

  try {
    const form = new FormData();
    form.append("image", img, {
      filename: "anime.jpg",
      contentType: "image/jpeg",
    });

    const response = await axios.post("https://www.animefinder.xyz/api/identify", form, {
      headers: form.getHeaders(),
    });

    const result = response.data;

    const genres = Array.isArray(result.genres) ? result.genres.join(", ") : result.genres || "-";

    let text = `
> Title: ${result.animeTitle || "-"}
> Character: ${result.character || "-"}
> Genres: ${genres}
> Synopsis: ${result.synopsis || "Nggak ada sinopsis~"}
> Links: ${result.references?.map(ref => `${ref.site}: ${ref.url}`).join("\n") || "-"}
「 ${result.description || "Nggak ada deskripsinya~"} 」
`.trim();

    await conn.sendFile(m.chat, img, "anime.jpg", text, m, false, { asThumbnail: true });
  } catch (err) {
    await m.reply(`Gagal mengidentifikasi anime: ${err.response?.data?.message || err.message}`);
  }
};

handler.help = ["whatanime"];
handler.tags = ["anime"];
handler.command = /^(whatanime)$/i;
handler.limit = true;
handler.register = true;

export default handler;