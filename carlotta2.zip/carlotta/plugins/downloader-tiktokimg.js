import { ttImage } from '../scraper/nuyTtImage.js';

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

let handler = async (m, { text, conn, usedPrefix, command }) => {
  try {
    if (!text) return m.reply(`Urlnya mana?\n*Contoh:* ${usedPrefix + command} https://vt.tiktok.com/xxxx`);

    conn.sendMessage(m.chat, { react: { text: "☘️", key: m.key }});

    let { image, error } = await ttImage(text);
    if (image && Array.isArray(image)) {
      for (let img of image) {
        await delay(3000);
        conn.sendFile(m.chat, img.links, '', `\`Image Result\``, m);
      }
    } else {
      m.reply(error);
    }
  } catch (error) {
    console.error(error);
    return m.reply('Terjadi kesalahan saat memproses permintaan Anda.');
  }
};
handler.tags = ['downloader']
handler.help = ['ttimg <url>','tiktokimg <url>']
handler.command = /^(ttimg|tiktokimg)$/i;
handler.limit = true

export default handler;