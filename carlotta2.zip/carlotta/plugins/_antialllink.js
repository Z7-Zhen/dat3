const linkAllRegex = /https?:\/\/[^\s]+/i;

export async function before(m, { isAdmin, isBotAdmin }) {
    if (m.isBaileys && m.fromMe) return;

    let chat = global.db.data.chats[m.chat] || {};
    let users = chat.users = chat.users || {};
    let sender = m.sender;

    if (!users[sender]) users[sender] = { warn: 0 };

    if (chat.antiLinkAll && m.isGroup) {
        let foundLink = linkAllRegex.exec(m.text);
        if (foundLink && !isAdmin) {
            users[sender].warn += 1;

            await m.reply(
                `*「 ANTI SEMUA LINK 」*\n\n` +
                `Terdeteksi link dari @${sender.split('@')[0]}\n` +
                `Warn Kamu: *${users[sender].warn}/3*\n\n` +
                `> Jangan kirim link apa pun di grup ini!`,
                null,
                { mentions: [sender] }
            );

            if (isBotAdmin) await this.sendMessage(m.chat, { delete: m.key });

            if (users[sender].warn >= 3 && isBotAdmin) {
                await m.reply(`@${sender.split('@')[0]} sudah 3x kirim link. Bye!`, null, { mentions: [sender] });
                await this.groupParticipantsUpdate(m.chat, [sender], 'remove');
                users[sender].warn = 0;
            }

            return true;
        }
    }

    return;
}