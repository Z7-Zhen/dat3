//File ini untuk merename otomatis module ke import * as cheerio (default) 
// Created by Renza

import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const pluginDir = path.join(__dirname, '../node_modules/@bochilteam')

const getAllJsFiles = dir => {
  let results = []
  let list = fs.readdirSync(dir)
  for (let file of list) {
    let filePath = path.join(dir, file)
    let stat = fs.statSync(filePath)
    if (stat && stat.isDirectory()) {
      results = results.concat(getAllJsFiles(filePath))
    } else if (filePath.endsWith('.js')) {
      results.push(filePath)
    }
  }
  return results
}

const autoPatchCheerio = () => {
  try {
    let files = getAllJsFiles(pluginDir)
    let totalReplaced = 0

    for (let filePath of files) {
      let isi = fs.readFileSync(filePath, 'utf-8')
      let regex = /^import\s+cheerio\s+from\s+['"]cheerio['"]/gm

      if (regex.test(isi)) {
        let baru = isi.replace(regex, `import * as cheerio from 'cheerio'`)
        fs.writeFileSync(filePath, baru)
        totalReplaced++
        console.log(`[AUTO PATCH] cheerio import fixed in: ${filePath.replace(pluginDir + '/', '')}`)
      }
    }

    if (totalReplaced) {
      console.log(`[AUTO PATCH] Sukses patch ${totalReplaced} file dengan impor cheerio yang benar.`)

      if (process.send) {
        console.log('[AUTO PATCH] Mengirim sinyal restart ke proses utama...')
        process.send('reset')
      } else {
        console.log('[AUTO PATCH] Tidak dapat merestart otomatis. Jalankan via "node index.js" untuk mendukung restart otomatis.')
      }
    }
  } catch (e) {
    console.error('[AUTO PATCH] Gagal patch cheerio:', e)
  }
}

autoPatchCheerio()

const handler = () => {}
handler.limit = true
export default handler