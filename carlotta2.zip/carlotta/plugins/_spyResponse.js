const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = (await import('@adiwajshing/baileys')).default;
import fs from 'fs';

const spyFile = './database/spy_data.json';

const loadSpyData = () => {
    return fs.existsSync(spyFile) ? JSON.parse(fs.readFileSync(spyFile)) : {};
};

let handler = async (m, { conn }) => {
    let spyData = loadSpyData();
    let user = spyData[m.sender] || { spyLevel: 1, spyExp: 0 };

    let missionList = [
        { name: "Penyusupan Markas", level: 1 },
        { name: "Peretasan Data", level: 5 },
        { name: "Penyadapan Percakapan", level: 10 },
        { name: "Misi Penyamaran", level: 15 },
        { name: "Sabotase Target", level: 20 },
        { name: "Pembebasan Sandera", level: 30 },
        { name: "Penyusupan Keamanan Tinggi", level: 40 },
        { name: "Ekstraksi VIP", level: 50 },
        { name: "Pembunuhan Rahasia", level: 60 },
        { name: "Infiltrasi Bunker Musuh", level: 70 },
        { name: "Operasi Final", level: 100 }
    ];

    let availableMissions = missionList.filter(mission => user.spyLevel >= mission.level).slice(-5);

    let sections = [
        {
            title: '🎯 Misi yang Tersedia',
            rows: availableMissions.map(mission => ({
                title: `🕵️ ${mission.name}`,
                description: `🔹 Level ${mission.level} diperlukan`,
                id: `.spy${mission.name.replace(/\s+/g, '').toLowerCase()}`
            }))
        },
        {
            title: '👤 Profil Spy',
            rows: [{
                title: "🔍 Cek Profil Spy",
                description: "Lihat statistik dan level Spy kamu",
                id: ".spyprofil"
            }]
        },
        {
            title: '📋 Daftar Nama Misi',
            rows: [{
                title: "📜 Lihat Semua Misi",
                description: "Cek daftar semua misi dan level minimalnya",
                id: ".spynamemissions"
            }]
        }
    ];

    let listMessage = { title: "Pilih Misi atau Cek Profil", sections };

    let msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: proto.Message.InteractiveMessage.Body.create({ text: "🎖️ *Spy Mission Center*\n\nPilih Misi atau Cek Profil Spy" }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        title: "🔥 *Pusat Misi Spy* 🕵️",
                        hasMediaAttachment: true,
                        ...(await prepareWAMessageMedia({ image: { url: `https://files.catbox.moe/8gpk0l.jpg` } }, { upload: conn.waUploadToServer }))
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [{
                            "name": "single_select",
                            "buttonParamsJson": JSON.stringify(listMessage)
                        }]
                    })
                })
            }
        }
    }, {});

    return conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
};

handler.help = ['spy'];
handler.tags = ['rpg'];
handler.command = /^spy$/i;

handler.register = true;
handler.group = true;
export default handler;