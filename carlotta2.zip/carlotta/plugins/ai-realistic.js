// plugins/realistic.js
import axios from 'axios';
import FormData from 'form-data';

const styleMap = {
  photorealistic: 'photorealistic style image',
  cinematic: 'cinematic style image',
  hyperreal: 'hyperrealistic style image',
  portrait: 'portrait style image'
};

const resolutionMap = {
  '512x512': { width: 512, height: 512 },
  '768x768': { width: 768, height: 768 },
  '1024x1024': { width: 1024, height: 1024 },
  '1920x1080': { width: 1920, height: 1080 }
};

async function generateRealisticImage(prompt, style = 'portrait', resolution = '768x768') {
  const selectedStyle = styleMap[style.toLowerCase()] || styleMap.portrait;
  const selectedRes = resolutionMap[resolution] || resolutionMap['768x768'];

  const fullPrompt = `${selectedStyle}: ${prompt}`;
  const form = new FormData();
  form.append('action', 'generate_realistic_ai_image');
  form.append('prompt', fullPrompt);
  form.append('seed', Math.floor(Math.random() * 100000).toString());
  form.append('width', selectedRes.width.toString());
  form.append('height', selectedRes.height.toString());

  const { data } = await axios.post('https://realisticaiimagegenerator.com/wp-admin/admin-ajax.php', form, {
    headers: {
      ...form.getHeaders(),
      'origin': 'https://realisticaiimagegenerator.com',
      'referer': 'https://realisticaiimagegenerator.com/',
      'user-agent': 'Mozilla/5.0',
      'accept': '*/*'
    }
  });

  if (data?.success && data.data?.imageUrl) {
    return data.data.imageUrl;
  }

  throw new Error('Gagal mengambil gambar dari API');
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    return m.reply(`📌 Contoh: ${usedPrefix + command} cewek anime di taman\n(Default: style = portrait, resolusi = 768x768)`);
  }

  const [promptRaw, styleRaw, resRaw] = text.split('|').map(v => v.trim());
  const prompt = promptRaw || 'potret wanita';
  const style = styleRaw || 'portrait';
  const resolution = resRaw || '768x768';

  await m.reply('⏳ Sedang membuat gambar Realistic AI...');

  try {
    const imageUrl = await generateRealisticImage(prompt, style, resolution);
    await conn.sendMessage(m.chat, {
      image: { url: imageUrl },
      caption: `✅ *Gambar berhasil dibuat!*\n🎨 Gaya: *${style}*\n📏 Resolusi: *${resolution}*`
    }, { quoted: m });
  } catch (e) {
    console.error(e);
    m.reply('❌ Gagal membuat gambar Realistic AI. Coba lagi nanti.');
  }
};

handler.help = ['realistic <prompt>|<style>|<resolusi>'];
handler.tags = ['ai'];
handler.command = /^realistic$/i;
handler.limit = true;

export default handler;