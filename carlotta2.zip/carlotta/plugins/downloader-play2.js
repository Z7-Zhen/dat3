/* 
• Plugins Youtube Play
• Source: https://whatsapp.com/channel/0029VakezCJDp2Q68C61RH2C
• Api: https://api.nekorinn.my.id
*/


import fetch from 'node-fetch';

const handler = async (m, { conn, args, command }) => {
  const query = args.join(' ');
  if (!query) throw `Contoh penggunaan: .${command} faded`;

  await conn.sendMessage(m.chat, { react: { text: '🎀', key: m.key } });

  try {
    const api = `https://api.nekorinn.my.id/downloader/ytplay-savetube?q=${encodeURIComponent(query)}`;
    const res = await fetch(api);
    const json = await res.json();

    if (!json?.status || !json?.result) throw 'Gagal mengambil data video.';

    const {
      title = 'Tanpa Judul',
      channel = 'Tidak diketahui',
      duration = '-',
      imageUrl = '',
      link = ''
    } = json.result.metadata || {};

    const audioUrl = json.result.downloadUrl;
    if (!audioUrl) throw 'Audio tidak tersedia untuk video ini.';

    const caption = `
\`Y O U T U B E - P L A Y\`

• Judul: ${title}
• Channel: ${channel}
• Durasi: ${duration}
• Link: ${link}
• Format: Audio
`.trim();

    await conn.sendMessage(m.chat, {
      text: caption,
      contextInfo: {
        externalAdReply: {
          title: title,
          body: 'Play Music 🧸',
          thumbnailUrl: imageUrl,
          sourceUrl: link,
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m });

    const checkAudio = await fetch(audioUrl, { method: 'HEAD' });
    if (!checkAudio.ok) throw 'Audio tidak dapat diakses atau link mati.';

    await conn.sendMessage(m.chat, {
      audio: { url: audioUrl },
      mimetype: 'audio/mp4',
      ptt: false
    }, { quoted: m });

  } catch (e) {
    console.error('Error kak!', e);
    throw 'Terjadi kesalahan saat mengambil atau mengirim audio.';
  }
};

handler.help = ['play2 <judul>'];
handler.tags = ['downloader'];
handler.command = ['ytplay2','play2'];

handler.limit = true
export default handler;