import similarity from 'similarity'
const threshold = 0.72

export async function before(m, { conn }) {
  let id = m.chat
  const quotedId = m.quoted?.id || m.quoted?.key?.id
  const quotedText = m.quoted?.text || m.quoted?.caption || ''
  if (!quotedId || !quotedText || !/Ketik.*hcha/i.test(quotedText) || /hcha/i.test(m.text)) return true

  this.tebakchara = this.tebakchara || {}
  if (!(id in this.tebakchara)) return conn.reply(m.chat, '❗Soal Itu Telah Berakhir', m)

  if (quotedId === (this.tebakchara[id][0]?.key?.id || this.tebakchara[id][0]?.id)) {
    let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(m.text)
    if (isSurrender) {
      clearTimeout(this.tebakchara[id][3])
      delete this.tebakchara[id]
      return conn.reply(m.chat, '*🗿Yah Menyerah!*', m)
    }

    let json = JSON.parse(JSON.stringify(this.tebakchara[id][1]))
    const jawaban = json.name.toLowerCase().trim()
    const userAns = m.text.toLowerCase().trim()

    if (userAns === jawaban) {
      global.db.data.users[m.sender].exp += this.tebakchara[id][2]
      conn.reply(m.chat, `*🎉Benar!*\n+${this.tebakchara[id][2]} XP`, m)
      clearTimeout(this.tebakchara[id][3])
      delete this.tebakchara[id]
    } else if (similarity(userAns, jawaban) >= threshold) {
      m.reply(`*💢Dikit Lagi!*`)
    } else {
      conn.reply(m.chat, `*🚫Salah!*`, m)
    }
  }
  return true
}

export const exp = 0

const buttontebakchara = [
  ['Main Lagi', '/tebakchara']
]
