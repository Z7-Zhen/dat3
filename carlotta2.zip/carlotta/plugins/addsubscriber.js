let handler = async (m, { conn, command, text, args }) => {
    if (!text) throw 'Format salah!\n\nTambah subscriber: .addsubscriber <tag orang / nomor> <jumlah subscriber>\nKurangi subscriber: .removesubscriber <tag orang / nomor> <jumlah subscriber>'

    // Pisahkan input menjadi target (who) dan nilai subscriber (subsValue)
    let [who, subsValue] = text.split(' ')
    if (!who) throw 'Tag orang atau ketik nomornya!'
    if (isNaN(subsValue)) throw 'Jumlah subscriber harus berupa angka!'

    subsValue = parseInt(subsValue)
    let user

    // Cek apakah ada mention
    if (m.mentionedJid && m.mentionedJid.length > 0) {
        user = m.mentionedJid[0]
    } else if (/^\d+$/.test(who)) {
        // Jika input adalah nomor telepon (tanpa tag), ubah menjadi JID WhatsApp
        user = who + '@s.whatsapp.net'
    } else {
        // Jika tidak ada yang disebut, fallback ke pengirim
        user = m.sender
    }

    // Ambil database pengguna
    let users = global.db.data.users

    // Inisialisasi jika belum ada datanya
    if (!users[user]) users[user] = { subscriber: 0 }

    // Tambah atau kurangi subscriber
    if (command === 'addsubscriber') {
        users[user].subscriber += subsValue
        conn.reply(m.chat, `✅ Berhasil menambahkan ${subsValue} subscriber untuk @${user.split('@')[0]}!`, m, {
            mentions: [user]
        })
    } else if (command === 'removesubscriber') {
        if (subsValue > users[user].subscriber) {
            users[user].subscriber = 0
            conn.reply(m.chat, `⚠️ Subscriber @${user.split('@')[0]} dikurangi hingga 0 karena jumlah yang diminta melebihi total saat ini.`, m, {
                mentions: [user]
            })
        } else {
            users[user].subscriber -= subsValue
            conn.reply(m.chat, `✅ Berhasil mengurangi ${subsValue} subscriber dari @${user.split('@')[0]}!`, m, {
                mentions: [user]
            })
        }
    }
}

handler.help = ['addsubscriber', 'removesubscriber']
handler.tags = ['owner']
handler.command = /^(add|rem)subscriber$/i
handler.rowner = true

handler.limit = true
export default handler