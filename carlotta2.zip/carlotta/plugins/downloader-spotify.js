import { spotifyDown } from '../scraper/nuy-spotifyDown.js'
import { spotifySearch } from '../scraper/nuy-spotifySearch.js'

let linkRegex = /https:\/\/open\.spotify\.com\/track\/[0-9A-Za-z]+/i;
let handler = async(m, { text, conn, usedPrefix, command }) => {
try {
  switch (command) {
      case 'spotify':
      case 'spotifydl': 
      case 'spotifymp3':
      case 'spotidl':
      case 'spotimp3':
  if (!text) return m.reply(`Urlnya mana?\n*Contoh:* ${usedPrefix + command} https://open.spotify.com/track/xxxxxx`)
  conn.sendMessage(m.chat, { react: { text: '👒', key: m.key }})
  let urlSpo = linkRegex.test(text)
  if (!urlSpo) return m.reply(`Hanya Support Url Track *(music)*\n*Contoh Url:* https://open.spotify.com/track/xxxxxx`)
  let response = await spotifyDown(text)
  let { nama, title, durasi, thumb, url } = response
  
  if (response) {
  let cap = `*© 𝖲𝗉𝗈𝗍𝗂𝖿𝗒 𝖬𝗎𝗌𝗂𝖼*

*[🏷️] Info Music*
* *Title:* ${title}
* *Durasi:* ${durasi}
* *Artis:* ${nama}
* *Spotify:* ${text}

\`You can searching Music Spotify\`\n*Example:* ${usedPrefix}spotisearch <music name>`
  await conn.sendMessage(m.chat, { text: cap, contextInfo: { mentionedJid: [m.sender], externalAdReply: { mediaUrl: '', mediaType: 1, title: title, body: '© Owen Skyler', thumbnailUrl: thumb, sourceUrl: '', renderLargerThumbnail: true, showAdAttribution: false } } }, { quoted: flok });
  conn.sendFile(m.chat, url, 'enuyyy.mp3', '', m, null, { mimetype: 'audio/mp4' });
  } else {
     m.reply(eror)
    }
  break
  case 'spotidyplay':
  case 'playspotify':
  case 'spotiplay':
  case 'playspoti':
     if (!text) return m.reply(`Lagu apa yang ingin kamu cari?\n*Contoh:* ${usedPrefix + command} Guitar, Loneliness and Blue Planet`)
    conn.sendMessage(m.chat, { react: { text: '🧶', key: m.key }})
        let { data } = await spotifySearch(text);
        if (data) {
        let spotify = data.length
        let random = Math.floor(Math.random() * spotify);
        let { title, durasi, populer, image, rilis, artis, url_artis, preview, urls } = data[0]
        let getMusic = await spotifyDown(urls)
        let music = getMusic.url
          if (music) {
          let caps = `*© 𝖲𝗉𝗈𝗍𝗂𝖿𝗒 𝖯𝗅𝖺𝗒*

*𝖨𝗇𝖿𝗈 𝖬𝗎𝗌𝗂𝖼*
* *𝖳𝗂𝗍𝗅𝖾:* ${title}
* *𝖣𝗎𝗋𝖺𝗌𝗂:* ${durasi}
* *𝖯𝗈𝗉𝗎𝗅𝖺𝗋:* ${populer}
* *𝖱𝗂𝗅𝗂𝗌:* ${rilis}
* *𝖬𝗎𝗌𝗂𝖼:* ${urls}

*𝖨𝗇𝖿𝗈 𝖠𝗋𝗍𝗂𝗌*
* *𝖭𝖺𝗆𝖺:* ${artis}
* *𝖲𝗉𝗈𝗍𝗂𝖿𝗒:* ${url_artis}

*[🧶]* Salah Lagu? Kamu bisa menggunakan fitur *${usedPrefix}spotisearch* untuk mencari lagu yang kamu suka.`
          await conn.sendMessage(m.chat, { text: caps, contextInfo: { mentionedJid: [m.sender], externalAdReply: { mediaUrl: '', mediaType: 1, title: title, body: '© Owen Skyler', thumbnailUrl: image, sourceUrl: '', renderLargerThumbnail: true, showAdAttribution: false } } }, { quoted: flok });
  conn.sendFile(m.chat, music, 'enuyyy.mp3', '', m, null, { mimetype: 'audio/mp4' });
      } else {
        m.reply(eror)
        }
  } else {
    m.reply(eror)
      }
          break
          default:
          return;
         }
    } catch(error) {
      console.log(error)
      m.reply('error')
   }
}
handler.tags = ['downloader']
handler.help = ['spotifymp3','spotifyplay']
handler.command = /^(spotifydownload|spotifydl|spotifymp3|spotidl|spotimp3|spotifyplay|playspotify|spotiplay|playspoti)$/i
handler.limit = true;

export default handler