import fs from 'fs'
import fetch from 'node-fetch'
import axios from 'axios'
import * as cheerio from 'cheerio'
import { generateWAMessageFromContent, generateWAMessage } from "@adiwajshing/baileys"
import yts from "yt-search"
import qs from "qs"

const dbPath = './src/autodl.json'
let autodlDB = fs.existsSync(dbPath) ? JSON.parse(fs.readFileSync(dbPath)) : {}
function saveDB() { fs.writeFileSync(dbPath, JSON.stringify(autodlDB, null, 2)) }

const regexes = {
  tiktok: /https?:\/\/(?:www\.)?(?:tiktok\.com|vt\.tiktok\.com|vm\.tiktok\.com)\/[^\s]+/i,
  instagram: /https?:\/\/(?:www\.)?instagram\.com\/(?:reel|p|tv|stories)\/[^\s]+/i,
  facebook: /https?:\/\/(?:www\.|m\.)?(?:facebook|fb)\.(?:com|watch|share\/v)\/[^\s]+/i,
  youtube: /https?:\/\/(?:www\.)?(?:youtube\.com\/(?:watch\?v=|shorts\/)|youtu\.be\/)[^\s]+/i,
}

function formatDuration(sec = 0) {
  sec = Number(sec) || 0
  const h = Math.floor(sec / 3600).toString().padStart(2, "0")
  const m = Math.floor((sec % 3600) / 60).toString().padStart(2, "0")
  const s = Math.floor(sec % 60).toString().padStart(2, "0")
  return h !== "00" ? `${h}:${m}:${s}` : `${m}:${s}`
}

async function downloadTiktok(url) {
  const { data } = await axios.post(`https://tikwm.com/api/?url=${url}`, null, { timeout: 50000 })
  const tikwm = data.data
  return {
    title: tikwm.title || "",
    author: tikwm.author?.unique_id || "",
    type: tikwm.images ? "image" : "video",
    images: tikwm.images || [],
    video: tikwm.play || "",
    music: tikwm.music || "",
    duration: tikwm.duration || "",
  }
}

async function downloadInstagram(urlIgPost) {
  const headers = { "content-type": "application/x-www-form-urlencoded" }
  const response = await fetch("https://snapins.ai/action.php", {
    headers,
    body: "url=" + encodeURIComponent(urlIgPost),
    method: "POST"
  })
  if (!response.ok) throw Error(`Gagal ngambil data IG! Status: ${response.status} ${response.statusText}`)
  const json = await response.json()
  const name = json.data?.[0]?.author?.name || "(no name)"
  const username = json.data?.[0]?.author?.username || "(no username)"
  let images = [], videos = []
  json.data.map(v => { if (v.type == "image") images.push(v.imageUrl); else if (v.type == "video") videos.push(v.videoUrl) })
  return { name, username, images, videos }
}

async function downloadFacebook(url) {
  const data = {
    k_exp: "1719382502",
    k_token: "caff0706549d24c12d4e8a6ba2f350b3785d3cff2864c26b25007513146eb455",
    q: url, lang: "id", web: "fdownloader.net", v: "v2", w: ""
  }
  const response = await axios('https://v3.fdownloader.net/api/ajaxSearch?lang=id', { method: "POST", data, headers: { "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", "Origin": "https://fdownloader.net", "Referer": "https://fdownloader.net/", "User-Agent": "Mozilla/5.0" }})
  const html = response.data.data
  const $ = cheerio.load(html)
  const link = $('.download-link-fb')
  const durasi = $('p').text()
  const vid = []
  link.each((_, el) => vid.push({ links: $(el).attr('href'), resolusi: $(el).attr('title') }))
  if (!vid[0]?.links) throw 'Gagal fetch Facebook'
  return { url: vid[0].links, caption: `✅ Auto-download dari *Facebook* (${vid[0].resolusi})\n${durasi}`, mimetype: 'video/mp4' }
}

const yt1s = {
  formatAudio: ["mp3"],
  download: async (url, format) => {
    if (!yt1s.formatAudio.includes(format)) throw new Error("Format tidak didukung.");
    const videoId = yt1s.extractVideoId(url)
    const thumbnail = videoId ? `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg` : null

    try {
      const form = new URLSearchParams()
      form.append("q", url)
      form.append("type", "mp3")
      const res = await axios.post("https://yt1s.click/search", form.toString(), {
        headers: { "Content-Type": "application/x-www-form-urlencoded", Origin: "https://yt1s.click", Referer: "https://yt1s.click/", "User-Agent": "Mozilla/5.0" }
      })
      const $ = cheerio.load(res.data)
      const link = $('a[href*="download"]').attr("href")
      const title = $("title").text().trim() || "Unknown Title"
      if (link) return { title, image: thumbnail, downloadUrl: link }
    } catch (e) { console.warn("[yt1s.click] Gagal:", e.message || e.toString()) }

    try {
      if (!videoId) throw new Error("Video ID tidak valid")
      const payload = { fileType: "MP3", id: videoId }
      const res = await axios.post("https://ht.flvto.online/converter", payload, {
        headers: { "Content-Type": "application/json", Origin: "https://ht.flvto.online", Referer: `https://ht.flvto.online/widget?url=https://www.youtube.com/watch?v=${videoId}`, "User-Agent": "Mozilla/5.0 (Linux; Android 13)" }
      })
      const data = res?.data
      if (!data || data.status !== "ok" || !data.link) throw new Error(data.msg || "Gagal mengonversi video.")
      return { title: data.title, image: thumbnail, downloadUrl: data.link }
    } catch (e) { console.warn("[flvto.online] Gagal:", e.message || e.toString()) }
    throw new Error("❌ Tidak dapat mengambil link audio.")
  },
  extractVideoId: (url) => {
    const match = url.match(/(?:v=|\/)([0-9A-Za-z_-]{11})/)
    return match ? match[1] : null
  }
}

async function ytmp4Zen(url) {
  const api = `https://api.zenzxz.my.id/downloader/ytmp4?url=${encodeURIComponent(url)}`
  const { data } = await axios.get(api, { timeout: 90000 })
  if (!data?.status) throw new Error("❌ Gagal mengambil video (status false).")
  if (!data.download_url) throw new Error("❌ Link unduhan tidak tersedia.")
  return {
    title: data.title || "-",
    thumbnail: data.thumbnail || "",
    type: data.type || "video",
    format: data.format || "-",
    duration: data.duration || 0,    
    download: data.download_url
  }
}

const handler = async (m, { conn, text, command }) => {
  const lower = (text || '').toLowerCase()
  if (command === 'autodl') {
    if (lower === 'on') { autodlDB[m.chat] = true; saveDB(); return m.reply('✅ Auto-download *diaktifkan* di chat ini.') }
    else if (lower === 'off') { autodlDB[m.chat] = false; saveDB(); return m.reply('❌ Auto-download *dimatikan* di chat ini.') }
    else return m.reply(`Penggunaan:\n.autodl on - Aktifkan auto-download\n.autodl off - Nonaktifkan auto-download`)
  }
}

handler.tags = ['downloader']
handler.help = ['autodl'].map(v => v + '  [on/off]')
handler.command = ['autodl']
handler.register = true
handler.disabled = false
handler.admin = true
handler.group = true

handler.all = async function (m) {
  const conn = this
  if (!autodlDB[m.chat]) return
  if (global.db.data.users[m.sender]?.banned) return

  const text = m.text || ''
  let url = null, type = null
  for (const [key, regex] of Object.entries(regexes)) {
    const match = text.match(regex)
    if (match) { url = match[0]; type = key; break }
  }

  if (url && type) {
    try {
      await conn.sendMessage(m.chat, { react: { text: '🎀', key: m.key } })
  
      if (type === 'youtube') {
        const videoDl = await ytmp4Zen(url)
        if (videoDl?.download) {
          const captionVid = `${videoDl.title}
Resolusi: ${videoDl.format}
Durasi: ${formatDuration(videoDl.duration)}`
          await conn.sendMessage(
            m.chat,
            { video: { url: videoDl.download }, mimetype: "video/mp4", fileName: `${videoDl.title}.mp4`, caption: captionVid },
            { quoted: m }
          )
        }

        const audioDl = await yt1s.download(url, "mp3")
        if (audioDl?.downloadUrl) {
          await conn.sendMessage(
            m.chat,
            { audio: { url: audioDl.downloadUrl }, mimetype: "audio/mpeg", fileName: `${audioDl.title}.mp3` },
            { quoted: m }
          )
        }

      } else if (type === 'tiktok') {
        const tiktok = await downloadTiktok(url)
        let caption = `✨ *TIKTOK DOWNLOADER* ✨
🔗 *Link:* ${url}
🎵 *Title:* ${tiktok.title}
✍️ *Author:* ${tiktok.author}
⏱️ *Duration:* ${tiktok.duration} detik`.trim();
        if (tiktok.type === "image" && tiktok.images.length) {
          let images = []
          for (let i = 0; i < tiktok.images.length; i++) images.push({ image: { url: tiktok.images[i] }, caption: `Slide ${i + 1} dari ${tiktok.images.length}\n\n${caption}` })
          if (images.length === 1) await conn.sendMessage(m.chat, images[0], { quoted: m })
          else await sendAlbum(conn, m.chat, images, { quoted: m })
          conn.reply(m.chat, "✅ Slide gambar sudah dikirim!", m)
        } else if (tiktok.type === "video" && tiktok.video) {
          await conn.sendFile(m.chat, tiktok.video, "tiktok.mp4", caption, m)
          if (tiktok.music) await conn.sendMessage(m.chat, { audio: { url: tiktok.music }, mimetype: 'audio/mpeg', ptt: false }, { quoted: m })
        } else conn.reply(m.chat, "Gagal ambil video, coba link lain ya!", m)

      } else if (type === 'instagram') {
        const ig = await downloadInstagram(url)
        let caption = `\`I N S T A G R A M  D O W N L O A D E D\`

👤 Author: ${ig.name} (@${ig.username})
🔗 Link: ${url}
📸 Images: ${ig.images.length}
🎥 Videos: ${ig.videos.length}`
        if (ig.videos.length) for (let video of ig.videos) await conn.sendMessage(m.chat, { video: { url: video }, caption, quoted: m })
        if (ig.images.length) for (let image of ig.images) await conn.sendMessage(m.chat, { image: { url: image }, caption, quoted: m })
        if (!ig.videos.length && !ig.images.length) conn.reply(m.chat, "Gak ada media yang bisa dikirim, Sensei! Post-nya kosong kah?", m)

      } else {
        const media = await downloadFacebook(url)
        await conn.sendMessage(m.chat, { video: { url: media.url }, caption: media.caption, mimetype: media.mimetype }, { quoted: m })
      }

    } catch (e) {
      console.error(e)
      m.reply(`❌ Gagal auto-download: ${e}`)
    }
  }
}

export default handler

async function sendAlbum(conn, jid, medias, options = {}) {
  const userJid = conn.user?.id || conn.authState?.creds?.me?.id
  if (!Array.isArray(medias) || medias.length < 1) throw new Error("Album minimal berisi 1 media (gambar/video).")
  const time = options.delay || 500
  delete options.delay

  const album = await generateWAMessageFromContent(jid, { albumMessage: { expectedImageCount: medias.filter(m => m.image).length, expectedVideoCount: medias.filter(m => m.video).length } }, { userJid, ...options })
  await conn.relayMessage(jid, album.message, { messageId: album.key.id })

  for (const media of medias) {
    if (!(media.image || media.video)) continue
    const msg = await generateWAMessage(jid, { ...(media.image ? { image: media.image } : {}), ...(media.video ? { video: media.video } : {}), caption: media.caption || "", ...options }, { userJid, upload: async (readStream, opts) => await conn.waUploadToServer(readStream, opts), ...options })
    msg.message.messageContextInfo = { messageAssociation: { associationType: 1, parentMessageKey: album.key } }
    await conn.relayMessage(jid, msg.message, { messageId: msg.key.id })
    await new Promise(res => setTimeout(res, time))
  }
  return album
}