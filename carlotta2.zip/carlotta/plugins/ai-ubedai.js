// ubedai-handler.mjs
import fetch from "node-fetch";

let handler = async (m, { conn, args }) => {
  try {
    if (!args[0]) {
      return conn.sendMessage(m.chat, { text: "⚠️ Tulis teks setelah command, contoh: `.ubedai Halo`" });
    }

    const textInput = args.join(" ");
    const url = `https://apiku.ubed.my.id/api/aiubed?text=${encodeURIComponent(textInput)}`;
    const res = await fetch(url);
    const json = await res.json();

    if (!json || !json.response) {
      return conn.sendMessage(m.chat, { text: "⚠️ API tidak mengembalikan response" });
    }

    await conn.sendMessage(m.chat, { text: json.response });
  } catch (e) {
    console.error("Error fetch ubedai:", e);
    await conn.sendMessage(m.chat, { text: "⚠️ Gagal ambil jawaban dari UbedAI." });
  }
};

handler.command = ["ubedai", "ubed"];
handler.tags = ["ai"];
handler.help = ["ubedai <teks>", "ubed <teks>"];
handler.register = true;
handler.limit = true;

export default handler;