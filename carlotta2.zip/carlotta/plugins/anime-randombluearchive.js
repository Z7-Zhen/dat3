let handler = async (m, { conn }) => {

  await conn.sendMessage(m.chat, {
    image: { url: 'https://anisa.biz.id/api/random/ba/' },
    caption: '*Random Blue Archive*'
  }, { quoted: m });
};

handler.help = ['bluearchive'];
handler.command = ['randomba','bluearchive','randombluearchive'];
handler.tags = ['anime'];

handler.limit = true
export default handler;