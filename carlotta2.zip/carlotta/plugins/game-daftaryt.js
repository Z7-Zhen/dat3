import axios from 'axios'

// Regex ini tidak digunakan dalam handler, bisa dihapus jika tidak dipakai di tempat lain
let Reg = /\|?(.*)([.|] *?)([0-9]*)$/i

let handler = async (m, { isOwner, conn, text, args }) => {
  // Ambil data pengguna
  let user = global.db.data.users[m.sender]

  // Cek apakah user sudah memiliki akun YouTube
  if (user.subscriber > 0) return m.reply(`❎ kamu sudah memiliki akun YouTube`)

  // Cek apakah ada nama yang diberikan
  if (!text) return m.reply(`Mau buat akun YouTube dengan nama apa?\nContoh: .createyt Nur Kholifah`)

  // Batasi panjang nama maksimum 20 karakter
  if (text.length > 20) return m.reply('⚠️ Nama maksimal 20 karakter')

  // Set nama dan tambah subscriber
  user.nameyt = text.trim()
  user.subscriber += 2

  // Ambil data nama & subscriber untuk respon
  let ytname = user.nameyt
  let subs = user.subscriber

  // Kirim pesan sukses
  m.reply(`*✅ Sukses membuat akun YouTube*\nNama YT: ${ytname}\nSubscriber: ${subs}`)
}

handler.tags = ['rpg', 'game']
handler.help = ['createyt']
handler.command = /^(createyt|buatyt)/i
handler.register = true

export default handler
