import axios from 'axios'

const handler = async (m, { text, conn }) => {
    if (!text) throw 'Masukkan pertanyaanmu, contoh: Who is Jesus Christ'

    try {
        const url = `https://zelapioffciall.koyeb.app/ai/bible?q=${encodeURIComponent(text)}`
        const res = await axios.get(url)
        const data = res.data

        if (!data.status || !data.result) {
            throw data.message || 'Tidak ada hasil ditemukan.'
        }

        const hasil = `${data.result.answer}`

        await conn.sendMessage(m.chat, { text: hasil.trim() }, { quoted: m })

    } catch (error) {
        await conn.sendMessage(m.chat, { 
            text: `Terjadi kesalahan: ${error.response?.data?.message || error.message || error}` 
        }, { quoted: m })
    }
}

handler.help = ['bible']
handler.tags = ['ai']
handler.command = /^(bible)$/i
handler.limit = true
handler.register = true

export default handler