let handler = async (m, { conn, participants }) => {
  // ambil semua user di grup
  let users = participants.map(p => p.id).filter(v => v !== conn.user.jid)
  if (users.length < 3) return m.reply("🌸 Grupnya sepi, ga cukup buat 3 Lady Companion~")

  // acak 3 user
  let picked = users.sort(() => Math.random() - 0.5).slice(0, 3)

  // bikin teks aesthetic
  let teks = `🌷🎀 *Top Lady Companion* 🎀🌷\n\n`
  teks += `👑 1. @${picked[0].split('@')[0]} 💕\n`
  teks += `💎 2. @${picked[1].split('@')[0]} ${randomEmoji()}\n`
  teks += `🌹 3. @${picked[2].split('@')[0]} ${randomEmoji()}\n`
  teks += `\n💌 Mereka para *Lady Companion* suka pargoy sama om om ˚₊‧꒰ა 🍓 ໒꒱ ‧₊˚`

  await conn.sendMessage(m.chat, { text: teks, mentions: picked }, { quoted: m })
}

function randomEmoji() {
  let emojis = ["🌸", "🦋", "🍓", "🎀", "🌷", "🐰", "💖"]
  return emojis[Math.floor(Math.random() * emojis.length)]
}

handler.help = ['toplc']
handler.tags = ['fun']
handler.command = /^toplc$/i
handler.group = true

export default handler