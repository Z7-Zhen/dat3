import axios from 'axios'
 
async function generatePollinations(prompt, model = 'flux', opts = {}) {
  let {
    width = 960,
    height = 1280,
    seed = Math.floor(Math.random() * 999999),
    nologo = true,
    enhance = true,
    hidewatermark = true
  } = opts
  try {
    let query = new URLSearchParams({ model, width, height, seed })
    if (nologo) query.set('nologo', 'true')
    if (enhance) query.set('enhance', 'true')
    if (hidewatermark) query.set('hidewatermark', 'true')
    let url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?${query.toString()}`
    let { data } = await axios.get(url, { responseType: 'arraybuffer' })
    return Buffer.from(data, 'binary')
  } catch (e) {
    throw new Error(e.message)
  }
}
 
let handler = async (m, { conn, args }) => {
  try {
    let input = args.join(' ')
    if (!input.includes(',')) return m.reply(
      '*Example :* .genai Fuji Mountain,turbo\n\n' +
      '*Available Models :*\n' +
      '- flux\n' +
      '- sdxl\n' +
      '- midjourney\n' +
      '- anime\n' +
      '- realistic\n' +
      '- turbo'
    )
    let [prompt, model] = input.split(',').map(v => v.trim())
    if (!prompt || !model) return m.reply(
      '*Example :* .genai Fuji Mountain,turbo\n\n' +
      '*Available Models :*\n' +
      '- flux\n' +
      '- sdxl\n' +
      '- midjourney\n' +
      '- anime\n' +
      '- realistic\n' +
      '- turbo'
    )
    let img = await generatePollinations(prompt, model, {
      width: 960,
      height: 1280,
      enhance: true,
      hidewatermark: true,
      nologo: true
    })
    await conn.sendMessage(m.chat, { image: img }, { quoted: m })
  } catch (e) {
    m.reply(e.message)
  }
}
 
handler.help = ['genai']
handler.command = ['genai']
handler.tags = ['tools']
handler.premium = true
 
export default handler