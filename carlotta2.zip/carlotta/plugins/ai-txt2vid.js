/*
 * Nama Fitur : Text to Video (aivideogenerator)
 * Tipe       : Plugin ESM
 * Sumber     : https://whatsapp.com/channel/0029Vb6Zs8yEgGfRQWWWp639
 * Author     : ZenzXD
 */

import axios from 'axios'
import crypto from 'crypto'

async function veo3(prompt, { model = 'veo-3-fast', auto_sound = false, auto_speech = false } = {}) {
  try {
    const supportedModels = ['veo-3-fast', 'veo-3']

    if (!prompt) throw new Error('Prompt tidak boleh kosong')
    if (!supportedModels.includes(model)) throw new Error(`Model tidak valid. Model tersedia: ${supportedModels.join(', ')}`)
    if (typeof auto_sound !== 'boolean') throw new Error('auto_sound harus berupa boolean')
    if (typeof auto_speech !== 'boolean') throw new Error('auto_speech harus berupa boolean')

    // Ambil token verifikasi Turnstile
    const { data: cf } = await axios.get('https://api.nekorinn.my.id/tools/rynn-stuff', {
      params: {
        mode: 'turnstile-min',
        siteKey: '0x4AAAAAAANuFg_hYO9YJZqo',
        url: 'https://aivideogenerator.me/features/g-ai-video-generator',
        accessKey: 'e2ddc8d3ce8a8fceb9943e60e722018cb23523499b9ac14a8823242e689eefed'
      }
    })

    const uid = crypto.createHash('md5').update(Date.now().toString()).digest('hex')

    // Kirim permintaan pembuatan video
    const { data: task } = await axios.post('https://aiarticle.erweima.ai/api/v1/secondary-page/api/create', {
      prompt,
      imgUrls: [],
      quality: '720p',
      duration: 8,
      autoSoundFlag: auto_sound,
      soundPrompt: '',
      autoSpeechFlag: auto_speech,
      speechPrompt: '',
      speakerId: 'Auto',
      aspectRatio: '16:9',
      secondaryPageId: 1811,
      channel: 'VEO3',
      source: 'aivideogenerator.me',
      type: 'features',
      watermarkFlag: true,
      privateFlag: true,
      isTemp: true,
      vipFlag: true,
      model
    }, {
      headers: {
        uniqueid: uid,
        verify: cf.result.token
      }
    })

    // Loop cek status video
    while (true) {
      const { data } = await axios.get(`https://aiarticle.erweima.ai/api/v1/secondary-page/api/${task.data.recordId}`, {
        headers: {
          uniqueid: uid,
          verify: cf.result.token
        }
      })

      if (data.data.state === 'success') return JSON.parse(data.data.completeData)
      await new Promise(res => setTimeout(res, 1000))
    }
  } catch (err) {
    throw new Error(err.message || 'Gagal memproses permintaan')
  }
}

const handler = async (m, { text, conn }) => {
  if (!text) {
    return m.reply('⚠️ Masukkan *prompt* untuk membuat video.\nContoh:\n`.txt2vid a beautiful sunset over a mountain`')
  }

  try {
    await m.reply('⏳ Sedang membuat video, mohon tunggu...')
    const result = await veo3(text)

    if (!result?.data?.video_url) {
      return m.reply('❌ Gagal mendapatkan URL video, coba lagi nanti.')
    }

    await conn.sendFile(m.chat, result.data.video_url, 'video.mp4', `🎬 Video dari prompt:\n${text}`, m)
  } catch (e) {
    m.reply(`🚫 Terjadi kesalahan:\n${e?.message || e}`)
  }
}

handler.command = ['txt2vid']
handler.tags = ['ai']
handler.help = ['txt2vid <prompt>']
handler.premium = true
handler.register = true

export default handler