let handler = async (m, { conn }) => {
    conn.siapakahaku = conn.siapakahaku || {}
    let id = m.chat

    // Pastikan game aktif
    if (!(id in conn.siapakahaku)) throw false

    const ans = (conn.siapakahaku[id][1]?.jawaban || '').trim()
    const clue = ans.replace(/[bcdfghjklmnpqrstvwxyz]/ig, '_')

    conn.reply(
        m.chat,
        '```' + clue + '```',
        conn.siapakahaku[id][0] // quoted ke pesan soal
    )
}

handler.command = /^who$/i

export default handler
