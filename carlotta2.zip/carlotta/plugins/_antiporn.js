import axios from "axios";
import uploadImage from "../lib/uploadImage.js";

// sharp opsional (buat ekstrak frame pertama animated webp)
let sharp = null;
try {
  sharp = (await import("sharp")).default;
} catch {
  // sharp tidak wajib; kalau tidak ada, kita fallback ke media asli
}

let handler = m => m;

/* ===========================
   Util & Cache (global)
=========================== */

// ❗️JANGAN pakai ??= (tidak didukung di runtime kamu)
if (!global._antiPornBannedIds) global._antiPornBannedIds = new Map(); // auto-delete reply ke pesan NSFW
if (!global._antiPornProcessed)  global._antiPornProcessed  = new Set(); // cegah notifikasi dobel

function _apPrune() {
  const now = Date.now();
  for (const [id, exp] of global._antiPornBannedIds) {
    if (exp <= now) global._antiPornBannedIds.delete(id);
  }
}

/** Hapus pesan dengan dua cara (kompatibel berbagai versi baileys) */
async function tryDelete(conn, m, keyLike) {
  if (!keyLike) return false;
  try {
    await conn.sendMessage(m.chat, { delete: keyLike });
    return true;
  } catch {
    try {
      await conn.sendMessage(m.chat, {
        delete: {
          remoteJid: (keyLike && keyLike.remoteJid) || m.chat,
          id: keyLike && keyLike.id,
          fromMe: (keyLike && Object.prototype.hasOwnProperty.call(keyLike, "fromMe")) ? keyLike.fromMe : false,
          participant: (keyLike && keyLike.participant) || m.sender,
        },
      });
      return true;
    } catch (e2) {
      console.error("ANTI-PORN: gagal hapus pesan:", e2?.message || e2);
      return false;
    }
  }
}

/** Deteksi apakah mime/type termasuk image atau stiker */
function detectMediaType(q, m) {
  const mime = (q.msg || q).mimetype || "";
  const mtype = q.mtype || m.mtype || "";
  const isImage = /^image\//i.test(mime);
  const isSticker = /stickerMessage/i.test(mtype) || /webp/i.test(mime);
  return { mime, mtype, isImage, isSticker };
}

/** Jika webp (stiker), ekstrak frame pertama ke PNG buffer (butuh sharp). Fallback ke buffer asli. */
async function normalizeStickerBufferIfNeeded(buf, mime) {
  try {
    if (!buf || !buf.length) return buf;
    if (!/webp/i.test(mime)) return buf;
    if (!sharp) return buf; // sharp tidak terpasang
    // sharp support animated webp → ambil frame pertama
    const out = await sharp(buf, { animated: true }).extractFrame(0).png().toBuffer();
    return out && out.length ? out : buf;
  } catch (e) {
    console.error("ANTI-PORN: gagal konversi webp → png (pakai buffer asli):", e?.message || e);
    return buf;
  }
}

handler.before = async function (m, { conn, isBotAdmin, isAdmin }) {
  try {
    // 0) guards dasar
    if (m.fromMe) return true;
    if (!m.isGroup) return true;
    if (isAdmin) return true;

    _apPrune();

    const chatId = m.chat;
    const groupData = (global.db?.data?.chats?.[chatId]) || {};
    if (!groupData.antiPornStatus) return false;

    // 0.1) jika pesan ini reply ke pesan yang sudah “blacklist”, hapus langsung
    if (isBotAdmin && m.quoted?.key?.id && global._antiPornBannedIds.has(m.quoted.key.id)) {
      await tryDelete(conn, m, m.key);
      return true;
    }

    // 1) identifikasi media: quoted > current
    const q = m.quoted ? m.quoted : m;
    const { mime, isImage, isSticker } = detectMediaType(q, m);

    // hanya proses image/sticker
    if (!isImage && !isSticker) return true;

    if (!isBotAdmin) {
      // tidak bisa hapus pesan kalau bot bukan admin
      return true;
    }

    // 2) unduh media
    let media = await q.download();
    if (!media || !media.length) {
      console.error("ANTI-PORN: download media gagal / kosong");
      return true;
    }

    // 3) polyfill Buffer.toArrayBuffer() supaya cocok dengan uploadImage()
    if (typeof media.toArrayBuffer !== "function") {
      Object.defineProperty(media, "toArrayBuffer", {
        value() {
          return this.buffer.slice(this.byteOffset, this.byteOffset + this.byteLength);
        },
        enumerable: false,
      });
    }

    // 3.1) kalau stiker webp, ubah ke PNG frame pertama (lebih akurat untuk animasi)
    if (isSticker || /webp/i.test(mime)) {
      media = await normalizeStickerBufferIfNeeded(media, mime);
      if (typeof media.toArrayBuffer !== "function") {
        // re-attach polyfill karena buffer bisa berubah
        Object.defineProperty(media, "toArrayBuffer", {
          value() {
            return this.buffer.slice(this.byteOffset, this.byteOffset + this.byteLength);
          },
          enumerable: false,
        });
      }
    }

    // 4) upload -> dapat URL
    let imageUrl;
    try {
      const urlRaw = await uploadImage(media);
      imageUrl = String(urlRaw || "").trim();
    } catch (e) {
      console.error("ANTI-PORN: uploadImage error:", e?.message || e);
      return true;
    }

    if (!/^https?:\/\//i.test(imageUrl)) {
      console.error("ANTI-PORN: uploadImage tidak mengembalikan URL valid:", imageUrl);
      return true;
    }

    // 5) panggil API nsfw-checker (GET + imageUrl)
    let data;
    try {
      const res = await axios.get("https://api.nekoo.qzz.io/tools/nsfw-checker", {
        params: { imageUrl },
        timeout: 15000,
      });
      data = res?.data;
    } catch (e) {
      console.error("ANTI-PORN: nsfw-checker error:", e?.response?.data || e?.message || e);
      return true;
    }

    const label = data?.result?.labelName || "Unknown";
    const confidence = Number(data?.result?.confidence || 0);

    // default 60% (0.6), bisa override lewat db chat setting
    const threshold = typeof groupData.antiPornThreshold === "number" ? groupData.antiPornThreshold : 0.6;

    // 6) aksi —> hapus hanya jika label "Porn" dan confidence >= threshold
    if (label === "Porn" && confidence >= threshold) {
      const keyJudged = (m.quoted ? m.quoted.key : m.key); // pesan yang dinilai (bisa quoted atau current)
      const judgedId = keyJudged?.id;

      // kirim notifikasi sekali per id pesan
      if (judgedId && !global._antiPornProcessed.has(judgedId)) {
        global._antiPornProcessed.add(judgedId);
        const sender = m.sender;
        const tag = "@" + sender.split("@")[0];
        await conn.sendMessage(m.chat, {
          text: `*「 ANTI PORN 」*\n\nTerdeteksi *${tag}* mengirim konten pornografi! Pesan telah dihapus.\n\nConfidence: ${(confidence * 100).toFixed(2)}%`,
          mentions: [sender],
        });
      }

      // 6.1) hapus pesan sumber NSFW
      await tryDelete(conn, m, keyJudged);

      // 6.2) tandai ID ini → selama 5 menit, semua reply ke ID ini akan otomatis dihapus
      const ttlMs = 5 * 60 * 1000;
      if (judgedId) global._antiPornBannedIds.set(judgedId, Date.now() + ttlMs);

      // 6.3) jika ini kasus reply (kamu sedang membalas foto), hapus juga pesan balasannya
      if (m.quoted && m.key?.id !== judgedId) {
        await tryDelete(conn, m, m.key);
      }
    } else {
      // aman (bukan "Porn" atau confidence < threshold)
    }
  } catch (err) {
    console.error("ANTI-PORN: fatal error:", err?.message || err);
  }

  return true;
};

handler.group = true;
handler.botAdmin = true;

handler.limit = true
export default handler;