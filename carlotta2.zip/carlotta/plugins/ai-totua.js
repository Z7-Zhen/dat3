import axios from 'axios'
import uploadImage from '../lib/uploadImage.js'

const handler = async (m, { conn }) => {
  const q = m.quoted ? m.quoted : m
  const mime = (q.msg || q).mimetype || ''

  if (!/image\/(jpe?g|png|webp)/.test(mime)) {
    return m.reply('❌ Kirim atau balas gambar dengan caption *.totua*')
  }

  const buffer = await q.download()
  if (!buffer) return m.reply('❌ Gagal mengunduh gambar')

  await conn.sendMessage(m.chat, {
    react: { text: '🔄', key: m.key }
  })

  try {
    const imageUrl = await uploadImage(buffer)
    const endpoint = `https://api-faa.my.id/faa/totua?url=${encodeURIComponent(imageUrl)}`

    let resultUrl = null

    // coba dulu ambil JSON
    try {
      const { data } = await axios.get(endpoint)
      resultUrl =
        data?.result ||
        data?.result?.img ||
        data?.result?.url ||
        data?.img ||
        data?.url ||
        data?.image ||
        data?.data?.url ||
        null

      if (resultUrl) {
        await conn.sendMessage(
          m.chat,
          { image: { url: resultUrl }, caption: '✅ *Berhasil ubah ke Tua*' },
          { quoted: m }
        )
        return
      }
    } catch (e) {
      // kalau gagal parse JSON, lanjut ke binary
      console.log('JSON parse gagal, fallback ke binary...')
    }

    // fallback: ambil langsung sebagai buffer
    const response = await axios.get(endpoint, { responseType: 'arraybuffer' })
    await conn.sendMessage(
      m.chat,
      { image: response.data, caption: '✅ *Berhasil ubah ke Tua*' },
      { quoted: m }
    )
  } catch (e) {
    console.error('API Error:', e.response?.data || e.message)
    m.reply('❌ Terjadi kesalahan saat menghubungi server.')
  }
}

handler.command = /^totua$/i
handler.tags = ['ai', 'tools', 'premium']
handler.help = ['totua']
handler.premium = true
handler.register = true

export default hand