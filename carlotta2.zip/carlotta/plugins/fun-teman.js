import fs from 'fs'
import path from 'path'

let handler = async (m, { conn, command, args, participants }) => {
  const sender = m.sender
  const mention = m.mentionedJid?.[0]
  const today = new Date().toLocaleDateString('en-CA')
  const dbPath = path.join('./database', 'streak.json')

  let db = {}
  if (fs.existsSync(dbPath)) {
    db = JSON.parse(fs.readFileSync(dbPath))
  }
  if (!db.friendRequests) db.friendRequests = {}
  if (!db.friendList) db.friendList = {}
  if (!db.streaks) db.streaks = {}

  const requests = db.friendRequests
  const friends = db.friendList
  const streaks = db.streaks
  let users = global.db.data.users

  const resolveJid = (jid) => {
    return (
      participants.find(p =>
        p?.id === jid || p?.jid === jid || p?.lid === jid
      )?.jid || jid
    )
  }

  const resolvedSender = resolveJid(sender)
  const resolvedMention = resolveJid(mention)
  const saveDB = () => fs.writeFileSync(dbPath, JSON.stringify(db, null, 2))

  switch (command) {
    case 'berteman': {
      const sub = args[0]?.toLowerCase()

      if (sub === 'terima') {
        const pending = requests[resolvedSender]
        if (!pending) return m.reply('❌ Tidak ada permintaan berteman.')
        const from = pending.from
        if (!friends[resolvedSender]) friends[resolvedSender] = []
        if (!friends[from]) friends[from] = []
        if (!friends[resolvedSender].includes(from)) friends[resolvedSender].push(from)
        if (!friends[from].includes(resolvedSender)) friends[from].push(resolvedSender)
        delete requests[resolvedSender]
        saveDB()
        return m.reply(`🎉 Kamu sekarang berteman dengan @${from.split('@')[0]}`, null, { mentions: [from] })
      }

      if (sub === 'tolak') {
        const pending = requests[resolvedSender]
        if (!pending) return m.reply('❌ Tidak ada permintaan berteman.')
        const from = pending.from
        delete requests[resolvedSender]
        saveDB()
        return m.reply(`❌ Kamu menolak permintaan dari @${from.split('@')[0]}`, null, { mentions: [from] })
      }

      if (resolvedMention) {
        if (resolvedMention === resolvedSender) return m.reply('❌ Tidak bisa berteman dengan diri sendiri.')

        if (friends[resolvedSender]?.includes(resolvedMention)) {
          return m.reply(`✅ Kamu sudah berteman dengan @${resolvedMention.split('@')[0]}`, null, { mentions: [resolvedMention] })
        }

        const existingRequest = requests[resolvedMention]
        if (existingRequest && existingRequest.from === resolvedSender) {
          return m.reply(`❌ Kamu sudah mengirim permintaan berteman ke @${resolvedMention.split('@')[0]}`, null, { mentions: [resolvedMention] })
        }

        requests[resolvedMention] = { from: resolvedSender, timestamp: Date.now() }
        saveDB()
        return m.reply(`📨 Permintaan berteman dikirim ke @${resolvedMention.split('@')[0]}\n\n✅ Terima: *.berteman terima*\n❌ Tolak: *.berteman tolak*`, null, { mentions: [resolvedMention] })
      }

      return m.reply('❌ Format salah.\nGunakan: .berteman @user / .berteman terima / .berteman tolak')
    }

    case 'teman': {
      const daftar = friends[resolvedSender] || []
      if (daftar.length === 0) return m.reply('👥 Kamu belum memiliki teman.')

      let teks = `👥 *Temanmu:*\n\n`
      for (let i = 0; i < daftar.length; i++) {
        const partner = daftar[i]
        const key = [resolvedSender, partner].sort().join('-')
        const streak = streaks[key]?.count || 0

        const userPinged = streaks[key]?.pings?.[resolvedSender] === today
        const partnerPinged = streaks[key]?.pings?.[partner] === today
        const status = (userPinged && partnerPinged) ? '✅' : ''

        teks += `${i + 1}. @${partner.split('@')[0]} ${status} — 🔥 ${streak} hari\n`
      }

      teks += `\n📍 *Menu Terkait:*\n• .berteman @user\n• .streak @user\n• .putuspertemanan @user\n• .topstreak`
      return conn.reply(m.chat, teks, m, { mentions: daftar })
    }

    case 'streak': {
      if (!resolvedMention) return m.reply('📌 Gunakan .streak @user')
      if (resolvedMention === resolvedSender) return m.reply('❌ Tidak bisa streak dengan diri sendiri.')
      if (!friends[resolvedSender] || !friends[resolvedSender].includes(resolvedMention)) {
        return m.reply('❌ Kalian belum berteman. Gunakan .berteman @user terlebih dahulu.')
      }

      const key = [resolvedSender, resolvedMention].sort().join('-')
      if (!streaks[key]) {
        streaks[key] = { count: 0, lastDate: '', pings: {}, participants: [resolvedSender, resolvedMention] }
      }

      const data = streaks[key]
      const partnerPinged = data.pings[resolvedMention] === today
      const userPinged = data.pings[resolvedSender] === today

      if (userPinged) {
        return m.reply(`🔥 Kamu sudah streak hari ini dengan @${resolvedMention.split('@')[0]}\n📅 Coba lagi besok.`, null, { mentions: [resolvedMention] })
      }

      data.pings[resolvedSender] = today
      let reward = 0
      if (partnerPinged && data.lastDate !== today) {
        data.count += 1
        data.lastDate = today
        if (!users[resolvedSender]) users[resolvedSender] = {}
        if (!users[resolvedSender].money) users[resolvedSender].money = 0
        if (data.count >= 3) {
          const bonus = 1000000 + Math.floor((data.count - 3) / 2) * 250000
          users[resolvedSender].money += bonus
          reward = bonus
        }
      }

      saveDB()
      let teks = `🔥 *Streak dengan @${resolvedMention.split('@')[0]}:*\n`
      teks += `Statusmu hari ini: ✅\n`
      teks += `Status mereka: ${partnerPinged ? '✅' : '❌'}\n`
      teks += `\n🔥 Total streak: *${data.count} hari*`
      if (reward) teks += `\n🎁 Bonus: +${reward.toLocaleString()} money`
      return conn.reply(m.chat, teks, m, { mentions: [resolvedMention] })
    }

    case 'putuspertemanan': {
      if (!resolvedMention) return m.reply('📌 Tag teman yang ingin kamu hapus.')
      if (!friends[resolvedSender]) friends[resolvedSender] = []
      if (!friends[resolvedMention]) friends[resolvedMention] = []
      if (!friends[resolvedSender].includes(resolvedMention)) return m.reply('❌ Kamu tidak berteman dengan orang ini.')
      friends[resolvedSender] = friends[resolvedSender].filter(x => x !== resolvedMention)
      friends[resolvedMention] = friends[resolvedMention].filter(x => x !== resolvedSender)
      saveDB()
      return m.reply(`💔 Kamu dan @${resolvedMention.split('@')[0]} tidak lagi berteman.`, null, { mentions: [resolvedMention] })
    }

    case 'topstreak': {
      const entries = Object.entries(streaks)
        .filter(([key, d]) => {
          const [a, b] = key.split('-')
          return a !== b && d.count > 0
        })
        .sort((a, b) => b[1].count - a[1].count)
        .slice(0, 10)

      if (entries.length === 0) return m.reply('🔥 Belum ada streak aktif.')

      let teks = `🔥 *Top Streak Terbanyak:*\n\n`
      let mentions = []
      for (let i = 0; i < entries.length; i++) {
        const { participants, count } = entries[i][1]
        const [a, b] = participants
        teks += `${i + 1}. @${a.split('@')[0]} 🤝 @${b.split('@')[0]} — *${count} hari*\n`
        mentions.push(a, b)
      }
      return conn.reply(m.chat, teks, m, { mentions })
    }
  }
}

handler.help = ['berteman @user', 'berteman terima', 'berteman tolak', 'teman', 'streak @user', 'putuspertemanan @user', 'topstreak']
handler.tags = ['fun']
handler.command = /^berteman|teman|streak|putuspertemanan|topstreak$/i
handler.group = true
handler.register = true
handler.limit = true

export default handler