import similarity from 'similarity'
const threshold = 0.72

export async function before(m, { conn }) {
    let id = m.chat

    // Ambil ID dan teks quoted aman
    const quotedId = m.quoted?.id || m.quoted?.key?.id
    const quotedText = m.quoted?.text || m.quoted?.caption || ''
    if (!quotedId || !quotedText || !/Ketik.*hben/i.test(quotedText) || /hben/i.test(m.text)) return true

    this.tebakbendera = this.tebakbendera || {}
    if (!(id in this.tebakbendera)) {
        return conn.reply(m.chat, 'Soal itu telah berakhir', m)
    }

    // Pastikan reply ke pesan soal yang benar
    if (quotedId === (this.tebakbendera[id][0]?.key?.id || this.tebakbendera[id][0]?.id)) {
        let isSurrender = /^((me)?nyerah|surr?ender)$/i.test(m.text)
        if (isSurrender) {
            clearTimeout(this.tebakbendera[id][3])
            delete this.tebakbendera[id]
            return conn.reply(m.chat, '*Yah Menyerah :( !*', m)
        }

        let json = JSON.parse(JSON.stringify(this.tebakbendera[id][1]))
        const jawaban = json.name.toLowerCase().trim()
        const userAns = m.text.toLowerCase().trim()

        if (userAns === jawaban) {
            global.db.data.users[m.sender].exp += this.tebakbendera[id][2]
            conn.reply(m.chat, `*Benar!*\n+${this.tebakbendera[id][2]} XP`, m)
            clearTimeout(this.tebakbendera[id][3])
            delete this.tebakbendera[id]
        } else if (similarity(userAns, jawaban) >= threshold) {
            m.reply(`*Dikit Lagi!*`)
        } else {
            conn.reply(m.chat, `*Salah!*`, m)
        }
    }
    return true
}

export const exp = 0
