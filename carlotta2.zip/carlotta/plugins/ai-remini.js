import uploadImage from '../lib/uploadImage.js'
import axios from 'axios'

const handler = async (m, { conn }) => {
  await conn.sendMessage(m.chat, { react: { text: '✨', key: m.key } })

  const quoted = m.quoted || m
  if (!quoted.mimetype && !quoted.msg?.mimetype) {
    return m.reply('❌ Kirim atau reply gambar untuk diproses.')
  }

  try {
    const media = await quoted.download()
    const imageUrl = await uploadImage(media)
    if (!imageUrl) throw '❌ Upload gambar gagal.'

    const apiUrl = `https://api.betabotz.eu.org/api/tools/remini-v4?apikey=agasndul&url=${encodeURIComponent(imageUrl)}&resolusi=16`
    const { data: result } = await axios.get(apiUrl)

    if (!result.status || !result.url) throw `❌ API Error: ${JSON.stringify(result)}`

    const { data: buffer } = await axios.get(result.url, { responseType: 'arraybuffer' })
    const size = formatSize(buffer.length)

    const caption = `✨ *Photo Remini*\n📁 Size: ${size}`
    await conn.sendMessage(m.chat, {
      image: buffer,
      caption
    }, { quoted: m })

  } catch (err) {
    console.error(err)
    m.reply('❌ Terjadi kesalahan saat memproses gambar.')
  }
}

handler.help = ['upscaler', 'remini']
handler.tags = ['ai']
handler.command = ['upscaler', 'remini']
handler.limit = 3
handler.register = true

export default handler

function formatSize(size) {
  const round = (v, p = 1) => Math.round(v * 10 ** p) / 10 ** p
  const KB = 1024, MB = KB ** 2, GB = KB ** 3, TB = KB ** 4
  if (size < KB) return size + 'B'
  if (size < MB) return round(size / KB) + 'KB'
  if (size < GB) return round(size / MB) + 'MB'
  if (size < TB) return round(size / GB) + 'GB'
  return round(size / TB) + 'TB'
}
