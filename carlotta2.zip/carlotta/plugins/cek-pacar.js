import { areJidsSameUser } from '@adiwajshing/baileys'

function resolveJidFromParticipants(input, participants = []) {
  return (
    participants.find(p =>
      areJidsSameUser(p?.id, input) ||
      areJidsSameUser(p?.jid, input) ||
      areJidsSameUser(p?.lid, input)
    )?.jid || input
  )
}

let handler = async (m, { conn, usedPrefix, text, participants }) => {
  function no(number) {
    return number.replace(/\s/g, '').replace(/([@+-])/g, '')
  }

  text = no(text)

  let number = ''
  if (isNaN(text)) {
    number = text.split`@`[1]
  } else if (!isNaN(text)) {
    number = text
  }

  if (number.length > 15 || (number.length < 9 && number.length > 0))
    return conn.reply(m.chat, `Maaf, Nomor yang anda masukan salah!`, m)

  let user, orang

  if (!text && !m.quoted) {
    user = m.sender
    orang = 'Kamu'
  } else if (text) {
    user = number + '@s.whatsapp.net'
    orang = 'Orang yang kamu tag'
  } else if (m.quoted?.sender) {
    user = m.quoted.sender
    orang = 'Orang yang kamu balas'
  } else {
    user = m.sender
    orang = 'User'
  }

  // ✅ FIX HERE: Konversi dari LID → JID
  let realJid = resolveJidFromParticipants(user, participants)
  const users = global.db.data.users

  if (!users[realJid])
    return m.reply('Target tidak terdaftar di dalam database!')

  let pasanganId = users[realJid].pasangan || ''
  if (pasanganId && !users[pasanganId])
    return m.reply('Pasangannya tidak terdaftar di database!')

  if (!pasanganId) {
    return conn.reply(
      m.chat,
      `${orang} tidak memiliki pasangan dan tidak sedang menembak siapapun\n\n*Ketik .tembak @user untuk menembak seseorang*`,
      m
    )
  }

  if (users[pasanganId].pasangan !== realJid) {
    return conn.reply(
      m.chat,
      `${orang} sedang menunggu jawaban dari @${pasanganId.split('@')[0]} karena sedang tidak diterima atau ditolak\n\nKetik *${usedPrefix}ikhlasin* untuk mengikhlaskan!`,
      m,
      { mentions: [pasanganId] }
    )
  } else {
    return conn.reply(
      m.chat,
      `${orang} sedang menjalani hubungan dengan @${pasanganId.split('@')[0]} 💓💓💓`,
      m,
      { mentions: [pasanganId] }
    )
  }
}

handler.help = ['cekpacar']
handler.tags = ['fun']
handler.command = /^cekpacar$/i

handler.limit = true
export default handler