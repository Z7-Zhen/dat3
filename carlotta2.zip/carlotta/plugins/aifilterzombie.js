import axios from 'axios';
import { fileTypeFromBuffer } from 'file-type';
import uploadImage from '../lib/uploadImage.js';
import { animeFilter } from '../scraper/animeFilter.js';

async function ToZombi(imageBuffer) {
    try {
        const imageUrl = await uploadImage(imageBuffer); // Upload ke telegra.ph
        const apiKey = 'agasndul';

        const { data } = await axios.get('https://api.neoxr.my.id/api/tozombie', {
            params: {
                image: imageUrl,
                apikey: apiKey
            }
        });

        if (!data.status || !data.data?.url) return null;

        const response = await axios.get(data.data.url, { responseType: 'arraybuffer' });
        return Buffer.from(response.data);
    } catch (error) {
        console.error(error);
        return null;
    }
}

let handler = async (m, { conn, usedPrefix, command }) => {
    const q = m.quoted || m;
    const mime = (q.msg || q).mimetype || '';
    const isImage = /image\/(jpe?g|png)/.test(mime);

    if (!mime || !isImage) throw `Kirim/Reply Gambar Dengan Caption ${usedPrefix + command}`;

    const media = await q.download();
    const react = { react: { text: "⏳", key: m.key } };
    const reactdone = { react: { text: "✔️", key: m.key } };

    const reload = () => conn.sendMessage(m.chat, react);
    const done = () => conn.sendMessage(m.chat, reactdone);

    await reload();

    const caption = '*Result from* : ' + usedPrefix + command;

    switch (command) {
        case 'aifilter':
        case 'filteranime':
            try {
                const res = await animeFilter(media);
                const buff = Buffer.from(res[0].split(",")[1], "base64");
                await conn.sendMessage(m.chat, { image: buff, caption }, { quoted: m });
            } catch (e) {
                console.error(e);
                m.reply('Gagal menerapkan filter anime. Coba lagi nanti.');
            }
            break;

        case 'jadizombie':
        case 'makezombie':
            try {
                const result = await ToZombi(media);
                if (!result) throw 'Gagal mengubah gambar ke zombie.';
                await conn.sendMessage(m.chat, { image: result, caption, mentions: [m.sender] }, { quoted: m });
            } catch (e) {
                console.error(e);
                m.reply('Terjadi kesalahan saat mengonversi gambar ke zombie.');
            }
            break;
    }

    await done();
};

handler.tags = ["ai", "premium"];
handler.limit = true;
handler.register = true;
handler.premium = true;
handler.command = handler.help = ["makezombie", "jadizombie", "aifilter", "filteranime"];

export default handler;