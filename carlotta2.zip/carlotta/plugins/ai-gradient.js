import axios from 'axios';

async function chatGradient(options = {}) {
  const {
    model = 'Qwen3 235B',
    clusterMode = 'hybrid',
    messages = [],
    enableThinking = true,
    stream = true,
    debug = false,
    onMessage = null,
    onClusterInfo = null,
    onBlockUpdate = null,
    onJobInfo = null
  } = options;

  const log = (...args) => {
    if (debug) console.log('[DEBUG]', ...args);
  };

  log('Starting request with options:', { model, clusterMode, messagesCount: messages.length, stream });

  try {
    const response = await axios({
      method: 'post',
      url: 'https://chat.gradient.network/api/generate',
      headers: {
        'authority': 'chat.gradient.network',
        'accept': '*/*',
        'accept-language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
        'content-type': 'application/json',
        'origin': 'https://chat.gradient.network',
        'referer': 'https://chat.gradient.network/',
        'sec-ch-ua': '"Not A(Brand";v="8", "Chromium";v="132"',
        'sec-ch-ua-mobile': '?1',
        'sec-ch-ua-platform': '"Android"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36'
      },
      data: {
        model,
        clusterMode,
        messages,
        enableThinking
      },
      responseType: stream ? 'stream' : 'text'
    });

    log('Stream mode enabled');
    let fullContent = '';
    let reasoningContent = '';
    let buffer = '';
    let clusterInfo = null;
    let jobInfo = null;

    response.data.on('data', (chunk) => {
      buffer += chunk.toString();
      const lines = buffer.split('\n');
      buffer = lines.pop();

      for (const line of lines) {
        if (line.trim()) {
          try {
            const data = JSON.parse(line);
            log('Stream event:', data.type);
            
            if (data.type === 'reply') {
              const content = data.data.content || '';
              fullContent += content;
              if (onMessage) onMessage(content, fullContent);
            } else if (data.type === 'clusterInfo') {
              clusterInfo = data.data;
              if (onClusterInfo) onClusterInfo(data.data);
            } else if (data.type === 'blockUpdate') {
              if (onBlockUpdate) onBlockUpdate(data.data);
            } else if (data.type === 'jobInfo') {
              jobInfo = data.data;
              if (onJobInfo) onJobInfo(data.data);
            } else if (data.type === 'reasoning') {
              reasoningContent += data.data.content || '';
            }
          } catch (e) {
            log('Stream parse error:', e.message);
          }
        }
      }
    });

    return new Promise((resolve, reject) => {
      response.data.on('end', () => {
        log('Stream ended, content length:', fullContent.length);
        resolve({
          content: fullContent,
          reasoningContent: reasoningContent,
          clusterInfo: clusterInfo,
          jobInfo: jobInfo,
          messages: [
            ...messages,
            {
              role: 'assistant',
              content: fullContent,
              ...(reasoningContent && { reasoningContent })
            }
          ]
        });
      });

      response.data.on('error', (error) => {
        log('Stream error:', error.message);
        reject(error);
      });
    });

  } catch (error) {
    log('Request error:', error.message);
    throw error;
  }
}
const chatHistories = new Map();

let handler = async (m, { conn, text, usedPrefix, command }) => {
    const helpMessage = `
*Penggunaan:*
 ${usedPrefix + command} <pertanyaan>
 ${usedPrefix + command} reset - untuk menghapus riwayat obrolan.

*Contoh:*
 ${usedPrefix + command} Siapa presiden Indonesia pertama?
`;

    if (!text) return m.reply(helpMessage);

    const args = text.trim().split(' ');
    const subCommand = args[0].toLowerCase();

    if (subCommand === 'reset' || subCommand === 'clear') {
        if (chatHistories.has(m.chat)) {
            chatHistories.delete(m.chat);
            return m.reply('✅ Riwayat obrolan telah dihapus.');
        } else {
            return m.reply('ℹ️ Tidak ada riwayat obrolan untuk dihapus.');
        }
    }
    if (!chatHistories.has(m.chat)) {
        chatHistories.set(m.chat, []);
    }
    let messages = chatHistories.get(m.chat);
    messages.push({ role: 'user', content: text });

    try {
        await conn.sendMessage(m.chat, { text: '🤔 Berpikir...' }, { quoted: m });
        const result = await chatGradient({
            messages: messages,
            stream: true
        });

        await m.reply(result.content);

        chatHistories.set(m.chat, result.messages);

    } catch (e) {
        console.error('Error during chat:', e);
        m.reply('🚨 Terjadi kesalahan. Coba lagi nanti.');
    }
}

handler.help = ['gradient']
handler.tags = ['ai']
handler.command = /^(gradient)$/i
handler.limit = true
handler.register = true

export default handler