import axios from 'axios';
import { characterAi } from '../scraper/nuy-characterAi.js';

let handler = m => m;

handler.before = async (m, { isOwner, conn, text}) => {
    conn.ryou = conn.ryou || {};
    let chatDb = conn.ryou[m.sender]
    if (chatDb) {
      if (chatDb.ryo == 'aktif') {
        if (m.sender !== chatDb.sender) return;
        if (!m.text) return;
     //   if (m.isBaileys == false) return
        if (!m.quoted || !m.quoted.fromMe) return;
        try {
        let user = global.db.data.users[m.sender]
        let result = await characterAi(m.text, user.sessionId)
        let message = result.text
        let { sessionId } = result

        if (message.split('').length > 1) {
            m.reply(message)
            user.sessionId = sessionId
        } else {
            return m.reply(`Ada masalah dalam mengambil jawaban.`);
        }
    } catch (error) {
        console.error(error);
        return m.reply(`Terjadi kesalahan dalam komunikasi dengan server.`);
          }
       }
    }
    return true;
}

handler.limit = true
export default handler;