import axios from 'axios'
import yts from 'yt-search'

const handler = async (m, { conn, usedPrefix, text, command }) => {
  if (!text) {
    return m.reply(`Ketikkan judul lagu!\nContoh: *${usedPrefix + command} dj angklung*`)
  }

  await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

  try {
    const search = await yts(text)
    const video = search.videos[0]
    if (!video) return m.reply('Video tidak ditemukan.')

    const ytUrl = video.url
    const info = `🎵 *Judul:* ${video.title}
👤 *Channel:* ${video.author.name}
🕒 *Durasi:* ${video.timestamp}
🔗 *Link:* ${ytUrl}
_Proses pengunduhan video dan audio..._`

    await conn.sendMessage(m.chat, {
      text: info,
      contextInfo: {
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: '120363422936053862@newsletter',
          newsletterName: 'Owen Skyler By Renza',
          serverMessageId: -2222
        },
        externalAdReply: {
          title: video.title,
          body: video.author.name,
          thumbnailUrl: video.thumbnail,
          mediaType: 1,
          renderLargerThumbnail: true,
          mediaUrl: ytUrl,
          sourceUrl: video.author.url
        }
      }
    }, { quoted: m })

    const apiMp4 = `https://api.deline.web.id/downloader/ytmp4?url=${encodeURIComponent(ytUrl)}&quality=720p`
    const apiMp3 = `https://api.deline.web.id/downloader/ytmp3?url=${encodeURIComponent(ytUrl)}`

    const [resMp4, resMp3] = await Promise.all([
      axios.get(apiMp4, { timeout: 90000 }),
      axios.get(apiMp3, { timeout: 90000 })
    ])

    const pickUrl = (obj) =>
      obj?.result?.download ||
      obj?.result?.download_url ||
      obj?.result?.url ||
      obj?.download_url ||
      obj?.url ||
      obj

    const vidTitle = resMp4.data?.result?.title || video.title
    const videoUrl = pickUrl(resMp4.data)
    const audioUrl = pickUrl(resMp3.data)

    if (!videoUrl) throw new Error('Gagal ambil URL video dari ytmp4.')
    if (!audioUrl) throw new Error('Gagal ambil URL audio dari ytmp3.')

    await conn.sendMessage(m.chat, {
      video: { url: videoUrl },
      mimetype: 'video/mp4',
      fileName: `${vidTitle}.mp4`,
      caption: vidTitle
    }, { quoted: m })

    await conn.sendMessage(m.chat, {
      audio: { url: audioUrl },
      mimetype: 'audio/mpeg',
      fileName: `${vidTitle}.mp3`
    }, { quoted: m })

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

  } catch (e) {
    console.error(e)
    m.reply(`❌ Terjadi kesalahan saat mengambil lagu.\n${e.message || e}`)
  }
}

handler.help = ['play']
handler.tags = ['downloader']
handler.command = /^play$/i
handler.limit = 3
handler.register = true

export default handler