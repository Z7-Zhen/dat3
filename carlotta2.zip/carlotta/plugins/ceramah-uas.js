import { ttSearch } from '../scraper/nuyTtSearch.js'

let handler = async(m, { text, conn, usedPrefix, command }) => {
   m.reply(wait)
   
   let response = await ttSearch('ceramah ustad abdul somad')
   let { result } = response;
   
   if (result) {
   let { video_id, region, title, author, nickname, play, music } = result;
   let caption = `*Mohon Di Dengarkan*\n✧ *Wm Creator:* ${author}`
    await conn.sendFile(m.chat, play, 'zaell-ofc.mp4', caption, m)
    } else {
    m.reply(eror)
    }
}
handler.help = ['ustadabdulsomad']
handler.tags = ['ceramah']
handler.command = /^(uas|ustadabdulsomad)$/i

handler.limit = true
export default handler