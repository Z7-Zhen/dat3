import axios from 'axios'

async function SoundCloud(trackUrl) {
  try {
    const response = await axios.post(
      'https://api.downloadsound.cloud/track',
      { url: trackUrl },
      {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
          'Accept': 'application/json, text/plain, */*',
          'Referer': 'https://downloadsound.cloud/',
          'Origin': 'https://downloadsound.cloud/',
          'Content-Type': 'application/json',
        }
      }
    )

    const data = response.data

    return {
      url: data?.url || null,
      title: data?.title || null,
      author: {
        id: data?.author?.id,
        username: data?.author?.username,
        first_name: data?.author?.first_name,
        last_name: data?.author?.last_name,
        avatar_url: data?.author?.avatar_url,
        city: data?.author?.city,
        country_code: data?.author?.country_code,
        description: data?.author?.description,
        followers_count: data?.author?.followers_count,
        followings_count: data?.author?.followings_count,
        likes_count: data?.author?.likes_count,
        playlist_likes_count: data?.author?.playlist_likes_count,
        permalink_url: data?.author?.permalink_url,
        uri: data?.author?.uri,
        verified: data?.author?.verified,
        kind: data?.author?.kind,
        created_at: data?.author?.created_at,
        comments_count: data?.author?.comments_count
      },
      thumbnail: data?.imageURL
    }
  } catch (error) {
    throw `❌ Gagal mengambil data!\n${error?.response?.status || ''} ${error?.response?.data?.message || error.message}`
  }
}

let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) throw `📻 *Contoh:* ${usedPrefix + command} https://soundcloud.com/...`
  if (!args[0].includes('soundcloud.com')) throw '❌ Link tidak valid! Harus dari soundcloud.com'

  await conn.sendMessage(m.chat, { react: { text: '🎧', key: m.key } })

  const res = await SoundCloud(args[0])
  if (!res?.url) throw '❌ Gagal mendapatkan link download.'

  const author = res.author
  const caption = `\`SoundCloud - Downloader\`
  
🎧 *Judul:* ${res.title}
🧑‍🎤 *Author:* ${author?.username || '-'}
🌐 *Kota:* ${author?.city || '-'}, ${author?.country_code || '-'}
✅ *Verified:* ${author?.verified ? 'Ya' : 'Tidak'}
👥 *Followers:* ${author?.followers_count || 0}
📥 *Likes:* ${author?.likes_count || 0}
🗨️ *Komentar:* ${author?.comments_count || 0}
🔗 *Profil:* ${author?.permalink_url || '-'}

🎵 *Link Lagu:* ${args[0]}
`.trim()

  await conn.sendMessage(m.chat, {
    image: { url: res.thumbnail },
    caption
  }, { quoted: m })

  await conn.sendMessage(m.chat, {
    audio: { url: res.url },
    mimetype: 'audio/mpeg',
    ptt: false,
    fileName: `${res.title}.mp3`
  }, { quoted: m })

  await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
}

handler.help = ['soundcloud <link>']
handler.tags = ['downloader']
handler.command = /^((sound)?cloud)$/i
handler.limit = true

export default handler