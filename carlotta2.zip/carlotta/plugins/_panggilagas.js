let handler = async (m, { conn }) => {
    if (!m.isGroup) return;
    if (m.sender === '31616482629@s.whatsapp.net') return;

    // Ambil metadata grup & peserta
    let groupMetadata = await conn.groupMetadata(m.chat);
    let participants = groupMetadata.participants.map(p => p.id);

    // Nomor target (tanpa @)
    let nomorDipanggil = global.nomorwa;

    // Cek apakah dia ada di grup
    let adaDiGrup = participants.some(id => id.split('@')[0] === nomorDipanggil);
    if (!adaDiGrup) return;

    // Format JID yang bener buat mention
    let jidMention = nomorDipanggil + '@s.whatsapp.net';

    // Kirim reply dengan mention asli
    conn.reply(
        m.chat,
        `@${nomorDipanggil} Sayang ada yang nyariin kamu ni`,
        m,
        { mentions: [jidMention] }
    );
};

handler.customPrefix = /^(renza|enja)$/i;
handler.command = new RegExp();
handler.limit = true
export default handler;