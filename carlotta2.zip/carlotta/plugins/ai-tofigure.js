import axios from 'axios'
import FormData from 'form-data'

let handler = async (m, { conn }) => {
  try {
    const q = m.quoted ? m.quoted : m
    const mime = (q.msg || q).mimetype || ''
    if (!mime.startsWith('image/')) return m.reply('Gambarnya Mna')

    m.reply('Wait...')
    const buffer = await q.download()

    const form = new FormData()
    form.append('files[]', buffer, { filename: 'image.jpg' })

    const url = encodeURIComponent((await axios.post('https://uguu.se/upload.php', form, { headers: form.getHeaders() })).data.files[0].url)
    const result = (await axios.get(`https://api.nekolabs.my.id/tools/convert/tofigure?imageUrl=${url}`)).data.result

    await conn.sendMessage(m.chat, { image: { url: result } }, { quoted: m })

  } catch (e) {
    m.reply(e.message)
  }
}

handler.help = ['tofigure']
handler.command = ['tofigure']
handler.tags = ['ai']
handler.premium = true

export default handler