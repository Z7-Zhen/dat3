const isToxicRegex = /wa.me|anjing|anjg|ajg|anj|lonte|lont|pantek|pntk|ptk|puki|kontol|kont|kntl|memek|mmk|memk|yatim|yatm|ytm|puki|pukimak|puqimak|asu|asw|bajingan|tempek|ngentod|ngntd|penis|peler|pepek|tolol|goblok|gblk|anjim|entod|entd|ngewe/i;

let handler = msg => msg;

handler.before = async function (msg, { conn: connection, isBotAdmin: botIsAdmin, isAdmin: senderIsAdmin }) {
    if (msg.isBaileys && msg.fromMe) return true;
    if (!msg.isGroup) return true;

    const chatId = msg.chat;
    const groupSettings = global.db.data.chats[chatId];
    const senderName = await connection.getName(msg.sender);
    const toxicMatch = isToxicRegex.exec(msg.text);

    if (senderIsAdmin) return true;

    if (groupSettings.antiToxic && toxicMatch) {
        await msg.reply(`*Terdeteksi* ${senderName} telah mengirim kata-kata tidak sopan: "${toxicMatch[0]}"!`);

        if (!botIsAdmin) {
            return await msg.reply('*_Bot bukan admin, tidak bisa menghapus pesan_*');
        }

        await connection.sendMessage(msg.chat, { delete: msg.key });
        return true;
    }

    return false;
};

handler.limit = true
export default handler;