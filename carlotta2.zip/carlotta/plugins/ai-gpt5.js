// gpt5.js
import fetch from "node-fetch"

let handler = async (m, { text }) => {
  if (!text) throw `⚠️ Gunakan perintah:\n.gpt5 <pertanyaan / prompt>`
  try {
    let res = await fetch(`https://api.nekolabs.my.id/ai/gpt/5?text=${encodeURIComponent(text)}`)
    let raw = await res.text()

    let reply
    try {
      let json = JSON.parse(raw)
      reply =
        json.result?.text ||
        json.result ||
        json.data?.text ||
        json.answer ||
        null
    } catch {
      reply = raw // fallback kalau bukan JSON
    }

    if (!reply || reply.includes('<html')) throw '❌ API tidak balikin jawaban valid'

    await m.reply(reply)
  } catch (e) {
    console.error('Error gpt5:', e)
    m.reply('❌ Gagal ambil jawaban, coba lagi nanti.')
  }
}

handler.help = ['gpt5 <teks>']
handler.tags = ['ai']
handler.command = /^gpt5$/i
handler.limit = true
handler.register = true

export default handler