import axios from "axios"
import FormData from "form-data"
import Jimp from "jimp"
import fakeUserAgent from "fake-useragent"
 
const PROMPT_LOCK = `Buatlah gambar yang diambil dengan kamera polaroid. Buatlah seperti photobooth 3 grid. Foto tersebut harus terlihat seperti foto biasa, tanpa subyek atau properti yang jelas. Foto tersebut harus memiliki sedikit efek blur dan sumber cahaya yang konsisten, seperti lampu kilat dari ruangan gelap, yang tersebar di seluruh foto. Jangan ubah wajah. Ganti latar belakang dibelakang tersebut dengan tirai putih dengan orang pertama itu memegang kepala si orang kedua, orang keduanya menunjuk orang pertama itu, dan pose imut lainnya`
 
if (!global.polaroidSessions) global.polaroidSessions = {}
 
async function uploadUguu(buffer, filename = "file.jpg") {
  const form = new FormData()
  form.append("files[]", buffer, { filename, contentType: "application/octet-stream" })
 
  const { data } = await axios.post("https://uguu.se/upload.php", form, {
    headers: {
      ...form.getHeaders(),
      "User-Agent": fakeUserAgent()
    },
    maxBodyLength: Infinity,
    timeout: 60000
  })
 
  const url = data?.files?.[0]?.url
  if (!url) throw new Error("Upload ke Uguu gagal")
  return url
}
 
async function mergePhotos(buf1, buf2) {
  const img1 = await Jimp.read(buf1)
  const img2 = await Jimp.read(buf2)
  const size = 700
 
  img1.cover(size, size)
  img2.cover(size, size)
 
  const gap = 20
  const canvas = new Jimp(size * 2 + gap, size, 0xffffffff)
  canvas.composite(img1, 0, 0)
  canvas.composite(img2, size + gap, 0)
 
  return await canvas.getBufferAsync(Jimp.MIME_JPEG)
}
 
const handler = async (m, { conn, command, usedPrefix }) => {
  const key = `${m.chat}:${m.sender}`
  const q = m.quoted ? m.quoted : m
  const mime = (q.msg || q).mimetype || ""
 
  if (/^batalpolaroid$/i.test(command)) {
    delete global.polaroidSessions[key]
    return m.reply("✅ Sesi polaroid dibatalkan.")
  }
 
  if (/^polaroid$/i.test(command)) {
    if (!global.polaroidSessions[key]) {
      if (!/image\//i.test(mime)) {
        return m.reply(`❌ Balas *gambar pertama* dengan caption *${usedPrefix}polaroid*`)
      }
      const buf1 = await q.download()
      if (!buf1) return m.reply("Gagal download gambar pertama.")
      global.polaroidSessions[key] = { buf1 }
      return m.reply(
        "✅ Foto pertama disimpan!\n" +
        `Sekarang balas *gambar kedua* pakai caption *${usedPrefix}polaroid* lagi.`
      )
    }
 
    const sess = global.polaroidSessions[key]
    if (!/image\//i.test(mime)) {
      return m.reply(`❌ Balas *gambar kedua* dengan caption *${usedPrefix}polaroid*`)
    }
    const buf2 = await q.download()
    if (!buf2) return m.reply("Gagal download gambar kedua.")
 
    try {
      await conn.sendMessage(m.chat, { react: { text: "🔄", key: m.key } })
 
      const merged = await mergePhotos(sess.buf1, buf2)
 
      const mergedUrl = await uploadUguu(merged, "merged.jpg")
 
      const { data } = await axios.get(
        `https://api.deline.web.id/ai/editimg?url=${encodeURIComponent(mergedUrl)}&prompt=${encodeURIComponent(PROMPT_LOCK)}&apikey=agasndul`,
        { timeout: 180000 }
      )
 
      if (!data?.status || !data?.result?.url) throw new Error("API Deline gagal respon")
 
      await conn.sendMessage(
        m.chat,
        { image: { url: data.result.url }, caption: "📸 *Polaroid jadi!*" },
        { quoted: m }
      )
    } catch (e) {
      await m.reply("❌ Error: " + e.message)
    } finally {
      delete global.polaroidSessions[key]
      await conn.sendMessage(m.chat, { react: { text: "", key: m.key } })
    }
  }
}
 
handler.help = ["polaroid", "batalpolaroid"]
handler.tags = ["ai"]
handler.command = /^(polaroid|batalpolaroid)$/i
handler.register = true
handler.premium = true
 
export default handler