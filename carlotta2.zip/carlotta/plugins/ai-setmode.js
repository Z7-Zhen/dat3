import fs from 'fs';
import path from 'path';

const SESSIONS_FILE = path.resolve(process.cwd(), './database/AI.json');

const loadSessions = () => {
    if (!fs.existsSync(SESSIONS_FILE)) return {};
    try { return JSON.parse(fs.readFileSync(SESSIONS_FILE, 'utf-8')); } catch { return {}; }
};

const saveSessions = (sessions) => {
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions, null, 2), 'utf-8');
};

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
    let isOwner = global.owner.some(v => v[0] + '@s.whatsapp.net' === m.sender);
    const [mode, target] = args.map(arg => arg ? arg.toLowerCase() : '');

    if (!['assistant', 'Owen'].includes(mode)) {
        return m.reply(
`Mode tidak valid. Gunakan:
- *${usedPrefix + command} Owen* (ubah mode di chat ini)
- *${usedPrefix + command} assistant* (ubah mode di chat ini)
- *${usedPrefix + command} <mode> --global* (ubah mode default, *Khusus Owner*)`
        );
    }

    let sessions = loadSessions();

    if (target === '--global') {
        if (!isOwner) return m.reply("Perintah --global hanya untuk Owner.");

        Object.keys(sessions).forEach(sessionId => {
            if (sessions[sessionId]) {
                sessions[sessionId].currentMode = mode;
            }
        });
        saveSessions(sessions);
        return m.reply(`✅ Mode global berhasil diubah ke *${mode.toUpperCase()}* untuk semua sesi AI.`);
    } else {
        const sessionId = `${m.chat}:${m.sender}`;
        if (!sessions[sessionId]) {
            sessions[sessionId] = {
                currentMode: mode,
                hasBeenWelcomed: false,
                modes: {
                    Owen: { history: [] },
                    assistant: { history: [] }
                }
            };
        } else {
            sessions[sessionId].currentMode = mode;
        }
        saveSessions(sessions);
        return m.reply(`✅ Mode AI untuk chat ini berhasil diubah menjadi *${mode.charAt(0).toUpperCase() + mode.slice(1)}*`);
    }
};

handler.help = ['setmode <Owen/assistant>'];
handler.tags = ['ai'];
handler.command = /^(setmode)$/i;

handler.limit = true
export default handler;