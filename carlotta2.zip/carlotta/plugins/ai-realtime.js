// plugins/realtime.js
import fetch from "node-fetch";

const handler = async (m, { conn, text, usedPrefix, command }) => {
  // Cek register
  if (!global.db.data.users[m.sender]?.registered) {
    return conn.reply(
      m.chat,
      `⚠️ Kamu belum terdaftar!\n\nKetik *${usedPrefix}daftar nama.umur* untuk register.`,
      m
    );
  }

  if (!text) {
    return conn.reply(
      m.chat,
      `⚠️ Format: ${usedPrefix + command} <teks>\nContoh: ${usedPrefix + command} halo dunia`,
      m
    );
  }

  try {
    // Kasih reaksi loading
    await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

    // Fetch API
    const res = await fetch(
      `https://api-faa.my.id/faa/ai-realtime?text=${encodeURIComponent(text)}`
    );

    if (!res.ok) throw new Error(`HTTP ${res.status}`);

    const json = await res.json().catch(() => null);

    // Ambil hasil
    const result = json?.result || json?.message || json?.text || json;
    const output =
      typeof result === "string"
        ? result
        : JSON.stringify(result, null, 2);

    // Kirim hasil
    await conn.sendMessage(
      m.chat,
      { text: `🤖 *RealtimeAI*\n\n${output}` },
      { quoted: m }
    );

  } catch (e) {
    console.error("realtimeai error:", e);
    m.reply(`❌ Gagal RealtimeAI: ${e.message}`);
  }
};

// Metadata handler
handler.help = ["realtimeai <teks>", "realtime <teks>"];
handler.tags = ["ai"];
handler.command = /^(realtimeai|realtime)$/i;

// Tambahin limit & register
handler.limit = true;
handler.register = true;

export default handler;