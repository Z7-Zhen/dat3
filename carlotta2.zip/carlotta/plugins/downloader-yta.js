import axios from "axios"

function formatDuration(sec = 0) {
  sec = Number(sec) || 0
  const h = Math.floor(sec / 3600).toString().padStart(2, "0")
  const m = Math.floor((sec % 3600) / 60).toString().padStart(2, "0")
  const s = Math.floor(sec % 60).toString().padStart(2, "0")
  return h !== "00" ? `${h}:${m}:${s}` : `${m}:${s}`
}

async function ytmp3(url) {
  const api = `https://api.deline.web.id/downloader/ytmp3?url=${encodeURIComponent(url)}`
  const { data } = await axios.get(api, { timeout: 90_000 })

  if (!data?.status) throw "❌ Gagal mengambil audio"
  if (!data?.result?.download) throw "❌ Link unduhan tidak tersedia"

  const r = data.result
  return {
    title: r.title || "-",
    thumbnail: r.thumbnail || "",
    format: r.format || "mp3",
    duration: Number(r.duration) || 0,
    download: r.download
  }
}

let handler = async (m, { conn, text, command }) => {
  if (!text) throw `⚠️ Contoh: *${command} https://youtu.be/xxxxx*`

  try {
    await conn.sendMessage(m.chat, { react: { text: "🎵", key: m.key } })

    const result = await ytmp3(text.trim())
    const caption = `🎶 *YouTube Downloader MP3*

📌 Judul: ${result.title}
⏱️ Durasi: ${formatDuration(result.duration)}
`

    await conn.sendMessage(
      m.chat,
      {
        text: caption,
        contextInfo: {
          externalAdReply: {
            title: result.title,
            body: "YouTube Audio Downloader",
            thumbnailUrl: result.thumbnail,
            mediaType: 1,
            renderLargerThumbnail: true,
            sourceUrl: text.trim()
          }
        }
      },
      { quoted: m }
    )

    await conn.sendMessage(
      m.chat,
      {
        audio: { url: result.download },
        mimetype: "audio/mpeg",
        fileName: `${result.title}.mp3`
      },
      { quoted: m }
    )

    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } })
  } catch (e) {
    await conn.sendMessage(m.chat, { react: { text: "❌", key: m.key } })
    throw e?.toString?.() || e
  }
}

handler.help = ['ytmp3']
handler.tags = ['downloader']
handler.command = /^(yt(mp3|audio|musik|a)?)$/i
handler.limit = 3
handler.register = true

export default handler