// plugins/clearsesichat.js
import fs from 'fs'
import path from 'path'

const SESSIONS_FILE = path.resolve(process.cwd(), './database/AI.json')

function loadSessions () {
  if (!fs.existsSync(SESSIONS_FILE)) return {}
  try { return JSON.parse(fs.readFileSync(SESSIONS_FILE, 'utf-8')) } catch { return {} }
}
function saveSessions (sessions) {
  try { fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions, null, 2), 'utf-8') } catch {}
}

let handler = async (m, { text }) => {
  const isOwner =
    Array.isArray(global.owner)
      ? global.owner.some(v => (v[0] || v) + '@s.whatsapp.net' === m.sender)
      : false

  const sessions = loadSessions()
  const args = (text || '').trim()
  const isGlobalReset = args.toLowerCase() === '--global'

  if (isGlobalReset) {
    if (!isOwner) return m.reply('❌ Hanya Owner yang dapat mereset sesi global.')

    // reset semua history, simpan msgIds, dan bikin tutorial muncul lagi
    for (const sid in sessions) {
      const s = sessions[sid]
      if (s?.modes) {
        for (const mode in s.modes) {
          if (Array.isArray(s.modes[mode]?.history)) {
            s.modes[mode].history = []
          }
        }
      }
      s.hasBeenWelcomed = false
    }
    saveSessions(sessions)
    return m.reply('✅ Semua history sesi AI direset. Tutorial akan muncul lagi.')
  }

  const sid = `${m.chat}:${m.sender}`
  const s = sessions[sid]
  if (s) {
    if (s?.modes) {
      for (const mode in s.modes) {
        if (Array.isArray(s.modes[mode]?.history)) {
          s.modes[mode].history = []
        }
      }
      s.hasBeenWelcomed = false
      saveSessions(sessions)
      return m.reply('✅ History sesi AI kamu direset. Tutorial akan muncul lagi.')
    } else {
      return m.reply('💤 Sesi ada, tapi tidak ada history untuk direset.')
    }
  } else {
    return m.reply('💤 Tidak ada sesi aktif untuk direset.')
  }
}

handler.help = ['clearsesichat [--global]']
handler.tags = ['ai']
handler.command = /^clearsesichat$/i

handler.limit = true
export default handler