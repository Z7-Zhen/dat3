import { fbDown } from '../scraper/nuy-fbDown.js';

let handler = async(m, { text, conn, usedPrefix, command }) => {
  if (!text) return m.reply(`Urlnya mana?\n*Contoh:* ${usedPrefix + command} https://facebook.com/xxxxx`)
  conn.sendMessage(m.chat, {
          react: {
              text: "🚀",
              key: m.key
             }
         })
  let response = await fbDown(text)
  let { vid_SD, durasi } = response
  
  if (vid_SD && durasi) {
     await conn.sendFile(m.chat, vid_SD.links, '', `\`Sukses Download Facebook Video ✓\`\n*Resolusi:* \`360 (SD)\`\n*Durasi:* \`${durasi}\`\nJika Kurang Suka Dengan Hasilnya, Coba Gunakan Fitur *!fbhd*`, m)
      conn.sendMessage(m.chat, {
          react: {
              text: "✅",
              key: m.key
             }
         })
      } else {
       m.reply(eror)
       conn.sendMessage(m.chat, {
          react: {
              text: "❌",
              key: m.key
             }
         })
     }
}
handler.tags = ['downloader']
handler.help = ['fbhd','facebookhd']
handler.command = /^(fb|facebook|fbdl)$/i
handler.premium = false

handler.limit = true
export default handler