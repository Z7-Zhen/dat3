import similarity from 'similarity'
const threshold = 0.72

let handler = m => m

handler.before = async function (m, { conn }) {
    let id = m.chat

    // Pastikan ada quoted & teksnya sesuai
    const quotedId = m.quoted?.id || m.quoted?.key?.id
    const quotedText = m.quoted?.text || m.quoted?.caption || ''
    if (!quotedId || !quotedText || !/Ketik.*(who|hint)/i.test(quotedText) || /(who|hint)/i.test(m.text)) return true

    this.siapakahaku = this.siapakahaku || {}
    if (!(id in this.siapakahaku)) {
        return conn.sendMessage(m.chat, { text: '❗Soal itu telah berakhir' }, { quoted: m })
    }

    // Cek apakah reply ke pesan soal yang benar
    if (quotedId === (this.siapakahaku[id][0]?.key?.id || this.siapakahaku[id][0]?.id)) {
        let json = JSON.parse(JSON.stringify(this.siapakahaku[id][1]))
        const jawaban = json.jawaban.toLowerCase().trim()
        const userAns = m.text.toLowerCase().trim()

        if (userAns === jawaban) {
            global.db.data.users[m.sender].exp += this.siapakahaku[id][2]
            conn.reply(m.chat, `*🎉Benar!*\n\n💥+${this.siapakahaku[id][2]} XP`, m)
            clearTimeout(this.siapakahaku[id][3])
            delete this.siapakahaku[id]
        } else if (similarity(userAns, jawaban) >= threshold) {
            m.reply(`*💢Dikit Lagi!*`)
        } else {
            m.reply(`*🚫Salah!*`)
        }
    }

    return true
}

handler.exp = 0

export default handler
