import util from 'util';
import path from 'path';

const user = (a) => '@' + a.split('@')[0];

function handler(m, { groupMetadata, command, conn, text, usedPrefix }) {
  if (!text) throw `Contoh penggunaan:\n.top 5 orang terganteng`;

  const ps = groupMetadata.participants.map((v) => v.id);

  // Ambil angka dan label dari text
  const match = text.match(/^(\d+)\s+(.+)/);
  if (!match) throw `Format salah!\nContoh: .top 5 orang terganteng`;

  const requestedCount = parseInt(match[1]);
  const label = match[2];

  if (requestedCount > 10) {
    return m.reply('Maksimal  10 orang!');
  }

  const count = Math.min(requestedCount, ps.length);

  // Acak peserta dan ambil sebanyak count
  const shuffled = [...ps].sort(() => 0.5 - Math.random()).slice(0, count);

  const x = pickRandom(['🤓', '😅', '😂', '😳', '😎', '🥵', '😱', '🤑', '🙄', '💩', '🍑', '🤨', '🥴', '🔥', '👇🏻', '😔', '👀', '🌚']);
  const topList = shuffled.map((id, i) => `${i + 1}. ${user(id)}`).join('\n');
  const top = `*${x} Top ${count} ${label} ${x}*\n\n${topList}`;

  m.reply(top, null, { mentions: shuffled });
}

handler.help = handler.command = ['top'];
handler.tags = ['fun'];
handler.group = true;
handler.register = true;
handler.premium = true;

export default handler;

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}