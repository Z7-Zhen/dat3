import axios from 'axios'

const handler = async (m, { conn }) => {
  await conn.sendMessage(m.chat, {
    react: { text: '😳', key: m.key }
  })

  try {
    const url = `https://api.botcahx.eu.org/api/nsfw/ahegao?apikey=${global.btc}`
    const { data } = await axios.get(url)

    // coba ambil link gambar
    const imageUrl = data?.result || data?.url || data?.data?.url || null

    if (imageUrl) {
      await conn.sendMessage(
        m.chat,
        { image: { url: imageUrl }, caption: '😳 *NSFW Ahegao*' },
        { quoted: m }
      )
    } else {
      // fallback: kalau API langsung gambar binary
      const buffer = await axios.get(url, { responseType: 'arraybuffer' })
      await conn.sendMessage(
        m.chat,
        { image: buffer.data, caption: '😳 *NSFW Ahegao*' },
        { quoted: m }
      )
    }
  } catch (e) {
    console.error('API Error:', e.response?.data || e.message)
    m.reply('❌ Terjadi kesalahan saat menghubungi server.')
  }
}

handler.command = /^ahegao$/i
handler.tags = ['nsfw']
handler.help = ['ahegao']
handler.premium = true

export default handler