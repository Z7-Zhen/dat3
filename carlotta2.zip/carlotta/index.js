import { createRequire } from "module";
import { fileURLToPath } from "url";
import { join, dirname } from "path";
import { fork } from "child_process";
import { createInterface } from "readline";

const __dirname = dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);
const { name, author } = require(join(__dirname, "./package.json"));

function colorText(text, color = "36") {
  return `\x1b[${color}m${text}\x1b[0m`;
}

// ASCII banner
const asciiLines = [
  "⢕⢕⢕⢕⢕⣽⣿⣿⣿⣿",
  "⠣⡁⠹⡪⡪⡪⡪⣪⣾⣿",
  "⣿⣿⣿⣿⣿⡵⢁⣤⣶",
  "⣿⣿⣿⣿⣿⣿⣿⣿⣿⠃",
  "⣦⣬⣙⣻⣿⣿⣷⣿⣿⢟",
  "⡘⣿⣿⣿⣿⣿⣿⠏⠠⠈",
  "⣦⣅⡑⠕⠡⠐⢿⠿⣛⠟",
  "⣿⣿⣿⣿⣿⣿⣿⣿⣷⣿",
  "⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿",
  "⠟⣡⣾⣿⣿⣿⣿⣦⣑⠝"
];

asciiLines.forEach(line => console.log(colorText(line, "31")));
console.log(colorText("🚀 Siap digunakan. Selamat datang di " + name, "36"));
console.log(colorText("📌 Dibuat oleh " + author, "34"));

let isRunning = false;
let childProcess = null;

const rl = createInterface(process.stdin, process.stdout);

let attempt = 0;
const maxAttempt = 3;

// Username & password custom
const credentials = {
  kimak: "yoi"
};

// Prompt login
function promptLogin() {
  console.log(colorText("[ ? ] Masukkan Username:", "33"));
  rl.question("", username => {
    console.log(colorText("[ ? ] Masukkan Password:", "33"));
    rl.question("", password => {
      console.log(colorText("✨ Username: " + username, "35"));
      console.log(colorText("🔐 Password: " + password, "35"));

      if (credentials[username] && credentials[username] === password) {
        console.log(colorText("[ √ ] Login berhasil! 🌟", "32"));
        start("main.js");
      } else {
        console.log(colorText("[ x ] Username atau password salah!", "31"));
        attempt++;
        if (attempt >= maxAttempt) {
          console.log(colorText("[ ! ] Terlalu banyak percobaan. Keluar.", "31"));
          rl.close();
          process.exit(1);
        } else {
          promptLogin();
        }
      }
    });
  });
}

// Start child process
function start(file) {
  if (isRunning) return;
  isRunning = true;

  const args = [join(__dirname, file), ...process.argv.slice(2)];
  childProcess = fork(args[0], args.slice(1));

  childProcess.on("message", handleMessage);
  childProcess.on("exit", handleExit.bind(null, args));

  rl.on("line", line => childProcess.send(line.trim()));
}

// Handle pesan dari child
function handleMessage(msg) {
  console.log(colorText("[Message]", "32"), msg);
  if (msg === "restart") restart();
  if (msg === "exitProcess") childProcess.send(process.uptime());
}

// Handle exit child
function handleExit(args, code) {
  isRunning = false;
  console.log(colorText(`Child Process exited with code ${code}`, "31"));
  if (code !== 0) {
    setTimeout(() => restart(), 1000);
  } else {
    restart();
  }
}

// Restart ulang
function restart() {
  if (childProcess) {
    childProcess.kill();
    childProcess = null;
  }
  start("main.js");
}

promptLogin();